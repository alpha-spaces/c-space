from xml.sax.saxutils import escape, quoteattr
from email.Utils import formatdate as rfc2822Time
from SvnReporter import inetTime

var = 1

class Counter:
    def __init__(self):
        self.count = 0
        
    def __call__(self):
        self.count += 1
        return self.count
    
counter = Counter()
