from xml.sax.saxutils import escape, quoteattr
from email.Utils import formatdate as rfc2822Time
from SvnReporter import inetTime, viewCvsObjectLink, viewCvsDiffLink
