#!/usr/bin/env python2
"""\
sync2cd.py   Synchronization to CD-R
Copyright 2004 Remy Blank

Split a filesystem tree into multiple media (e.g. CD-R) and keep a list
of what has already been archived.

Basic idea:
  sync2cd.py -c -g config_file | mkisofs -J -r -graft-points -path-list - -quiet | cdrecord -v -waiti -data -

(...wow ;-)
"""

# Module imports
import sys
import os
import stat
import glob
import re
import md5
import sha
import time
import getopt
import traceback

# Constants
ProgramName = "sync2cd.py"
ProgramVersion = "0.7"
DescriptorFormatVersion = 2
SuffixSize = 4
BlockSize = 2048
DescriptorDir = ".sync2cd"
HashFunctions = {
        "md5": md5,
        "sha": sha,
        "sha1": sha
}


# Generic exception
class Error(Exception): pass
                

# Python script parser
class ParseError(Exception): pass

class ScriptParser(object):
        "Python script parser."
        def __init__(self):
                self.Globals = {}

        def AddGlobal(self, **kwargs):
                """Add symbols to globals."""
                self.Globals.update(kwargs)

        def Parse(self, Input):
                """Parse python script input."""
                if type(Input) not in (str, file, type(self.Parse.func_code)):
                        Input = Input.read()
                try:
                        exec Input in self.Globals
                except:
                        (Type, Value, Traceback) = sys.exc_info()
                        Traceback = Traceback.tb_next
                        ExcText =   str(traceback.tb_lineno(Traceback)) + ": "                  \
                                  + "".join(traceback.format_exception_only(Type, Value))
                        del Traceback
                        raise ParseError, ExcText[:-1]


# Helpers
def QuoteString(s):
        """Quote all occurences of double quotes in a string."""
        return s.replace('"', '\\"')


def HumanReadable(Value, Kilo = 1024):
        """Convert a value to a human-readable format."""
        def ToDec(Value, Exp):
                if Value < 10 * Exp:
                        (Div, Mod) = divmod(Value, Exp)
                        return "%d.%d" % (Div, (Mod * 10) / Exp)
                else:
                        return "%d" % (Value / Exp)
        
        if Value < Kilo:
                return str(Value)
        if Value < Kilo * Kilo:
                return ToDec(Value, Kilo) + "k"
        if Value < Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo) + "M"
        if Value < Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo) + "G"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo) + "T"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo) + "P"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo * Kilo) + "E"

                
# Directory entries
class DirEntInfo(object):
        """Directory entry information holder."""
        def __init__(self, Name, Mode, Owner, Group, MTime):
                self.Name = os.path.normpath(Name)
                self.SetStat(Mode, Owner, Group, MTime)

        def SetStat(self, Mode, Owner, Group, MTime):
                self.Mode = stat.S_IMODE(Mode)
                self.Owner = Owner
                self.Group = Group
                self.MTime = MTime

        def __eq__(self, Other):
                return    (self.Mode, self.Owner, self.Group, self.MTime)       \
                       == (Other.Mode, Other.Owner, Other.Group, Other.MTime)
                       
        def __ne__(self, Other):
                return not self.__eq__(Other)


class DirInfo(DirEntInfo):
        """Directory information holder."""
        def __str__(self):
                Values = ('"' + QuoteString(self.Name) + '"',
                          oct(self.Mode), self.Owner, self.Group, self.MTime)
                return "D(" + ", ".join([str(x) for x in Values]) + ")"


class LinkInfo(DirEntInfo):
        """Symbolic link information holder."""
        def __init__(self, Name, Mode, Owner, Group, MTime, Target):
                super(LinkInfo, self).__init__(Name, Mode, Owner, Group, MTime)
                self.Target = Target

        def __eq__(self, Other):
                return super(LinkInfo, self).__eq__(Other) and (self.Target == Other.Target)
                
        def __str__(self):
                Values = ('"' + QuoteString(self.Name) + '"',
                          oct(self.Mode), self.Owner, self.Group, self.MTime,
                          '"' + QuoteString(self.Target) + '"')
                return "L(" + ", ".join([str(x) for x in Values]) + ")"

                        
class FileInfo(DirEntInfo):
        """File information holder."""
        CmpSame = 0
        CmpStatChanged = 1
        CmpChanged = 2

        HashFunction = md5

        def __init__(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive = 0):
                super(FileInfo, self).__init__(Name, Mode, Owner, Group, MTime)
                self.Size = Size
                self._Hash = Hash
                self.Archive = Archive

        def PaddedSize(self, BlockSize):
                return (self.Size + (BlockSize - 1)) & ~(BlockSize - 1)
                
        def Hash(self):
                return self._Hash

        def SetHash(self, Hash):
                if Hash and (len(Hash) != 2 * FileInfo.HashFunction.digest_size):
                        raise Error, "Hash function mismatch"
                self._Hash = Hash

        def __eq__(self, Other):
                return super(FileInfo, self).__eq__(Other) and (self.Size == Other.Size)
                
        def Compare(self, Other):
                if self.Size != Other.Size:
                        return FileInfo.CmpChanged
                if self.MTime != Other.MTime:
                        if self.Hash() != Other.Hash():
                                return FileInfo.CmpChanged
                        return FileInfo.CmpStatChanged
                if (self.Mode, self.Owner, self.Group) == (Other.Mode, Other.Owner, Other.Group):
                        return FileInfo.CmpSame
                return FileInfo.CmpStatChanged

        def __str__(self):
                        Values = ('"' + QuoteString(self.Name) + '"',
                                  oct(self.Mode), self.Owner, self.Group, self.MTime,
                                  self.Size, '"' + self.Hash() + '"', self.Archive)
                        return "F(" + ", ".join([str(x) for x in Values]) + ")"

                
class LoadedFileInfo(FileInfo):
        """File info holder, with lazy MD5 evaluation."""
        def __init__(self, Name, Mode, Owner, Group, MTime, Size):
                super(LoadedFileInfo, self).__init__(Name, Mode, Owner, Group, MTime, Size, "")

        def Hash(self):
                if not self._Hash:
                        m = FileInfo.HashFunction.new()
                        File = open(self.Name, "r")
                        try:
                                while 1:
                                        Data = File.read(64 * 1024)
                                        if not Data:
                                                break
                                        m.update(Data)
                        finally:
                                File.close()
                        self._Hash = m.hexdigest()
                return super(LoadedFileInfo, self).Hash()

                
def LoadFileInfo(Name):
        """Create a DirEntInfo child and populate with info loaded from filesystem."""
        Name = os.path.normpath(Name)
        Stat = os.lstat(Name)
        Mode = Stat[stat.ST_MODE]
        if stat.S_ISDIR(Mode):
                return DirInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                               Stat[stat.ST_MTIME])
        elif stat.S_ISLNK(Mode):
                return LinkInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                               Stat[stat.ST_MTIME], os.readlink(Name))
        elif stat.S_ISREG(Mode):
                return LoadedFileInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                      Stat[stat.ST_MTIME], Stat[stat.ST_SIZE])
        print >> sys.stderr, "Omitting " + Name


# Filesystem tree
class FsTree(ScriptParser):
        """Filesystem tree container."""
        def __init__(self, Other = None):
                super(FsTree, self).__init__()
                self.AddGlobal(Sync2cd = self.Sync2cd,
                               D = self.Dir,
                               L = self.Link,
                               F = self.File)
                
                self.Archive = 0
                self.Time = 0
                self.Version = 0
                if Other is not None:
                        self.Dirs = Other.Dirs.copy()
                        self.Links = Other.Links.copy()
                        self.Files = Other.Files.copy()
                else:
                        self.Dirs = {}
                        self.Links = {}
                        self.Files = {}

        def SetMeta(self, Archive, Time = None):
                self.Archive = Archive
                if Time:
                        self.Time = int(Time)
                else:
                        self.Time = int(time.time())

        def TimeStr(self):
                return time.strftime("%Y.%m.%d %H:%M:%S UTC", time.gmtime(self.Time))
                
        def Add(self, Entry):
                if isinstance(Entry, DirInfo):
                        self.Dirs[Entry.Name] = Entry
                elif isinstance(Entry, LinkInfo):
                        self.Links[Entry.Name] = Entry
                elif isinstance(Entry, FileInfo):
                        self.Files[Entry.Name] = Entry

        def Sync2cd(self, Archive, Time, Version):
                self.Archive = Archive
                self.Time = int(Time)
                self.Version = Version
                if Version > DescriptorFormatVersion:
                        print >> sys.stderr, "Warning: descriptor format version higher than current"

        def Dir(self, Name, Mode, Owner, Group, MTime):
                Mode = stat.S_IMODE(Mode) | stat.S_IFDIR
                self.Dirs[Name] = DirInfo(Name, Mode, Owner, Group, MTime)

        def Link(self, Name, Mode, Owner, Group, MTime, Target):
                Mode = stat.S_IMODE(Mode) | stat.S_IFLNK
                self.Links[Name] = LinkInfo(Name, Mode, Owner, Group, MTime, Target)

        def File(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive):
                Mode = stat.S_IMODE(Mode) | stat.S_IFREG
                self.Files[Name] = FileInfo(Name, Mode, Owner, Group, MTime, Size, Hash, Archive)

        def MakeDescriptor(self):
                Meta = ""
                if self.Archive != 0:
                        Meta =   'Sync2cd(Archive = ' + str(self.Archive)       \
                               + ', Time = ' + str(self.Time)                   \
                               + ', Version = ' + str(DescriptorFormatVersion)  \
                               + ') # ' + self.TimeStr() + '\n'
                Items = self.Dirs.copy()
                Items.update(self.Links)
                Items.update(self.Files)
                Names = Items.keys()
                Names.sort()
                Lines = [str(Items[Name]) for Name in Names]
                return Meta + "\n".join(Lines) + "\n"

        def CreateStatus(self, Archive, ShowContent):
                TotalSize = 0
                PaddedSize = 0
                Content = []
                for Item in self.Files.itervalues():
                        if Item.Archive != Archive:
                                continue
                        TotalSize += Item.Size
                        PaddedSize += Item.PaddedSize(BlockSize)
                        Content.append(Item.Name)

                Output = []
                if self.Archive != 0:
                        Output.append("Archive: %d" % self.Archive)
                if self.Time:
                        Output.append("Created: %s (%d)" % (time.strftime("%d.%m.%Y, %H:%M:%S UTC", time.gmtime(self.Time)),
                                                            self.Time))
                if self.Version:
                        Output.append("Version: %d" % self.Version)
                Output.append("Size:    %s (%d bytes)" % (HumanReadable(TotalSize), TotalSize))
                Output.append("Padded:  %s (%d bytes)" % (HumanReadable(PaddedSize), PaddedSize))
                if ShowContent:
                        Output.append("Content:")
                        Content.sort()
                        Output.extend(Content)
                return "\n".join(Output) + "\n"
        

def DictDiff(From, To):
        """Compute the difference between two dictionaries."""
        Added = To.copy()
        Changed = []
        Removed = From.copy()

        for (k, v) in From.iteritems():
                if k not in To:
                        continue
                del Added[k]
                del Removed[k]
                if v != To[k]:
                        Changed.append(k)
                        
        return ([Item for Item in Added.iterkeys()],
                Changed,
                [Item for Item in Removed.iterkeys()])
        

def TreeDiff(OldTree, NewTree):
        """Compute the difference between two trees."""
        Dirs = DictDiff(OldTree.Dirs, NewTree.Dirs)
        Links = DictDiff(OldTree.Links, NewTree.Links)
        Files = DictDiff(OldTree.Files, NewTree.Files)
        return (Dirs, Links, Files)

        
def BackupTreeMerge(OldTree, PhysTree, NewArchiveNum, ExistingArchives, MaxTotalSize = 0):
        """Merge two trees for backup purposes"""
        NewTree = FsTree(PhysTree)
        FileDiff = DictDiff(OldTree.Files, PhysTree.Files)

        # Tag added files
        Stored = FileDiff[0]
        for Name in FileDiff[0]:
                NewTree.Files[Name].Archive = NewArchiveNum

        # Tag changed files
        for Name in FileDiff[1]:
                OldItem = OldTree.Files[Name]
                NewItem = NewTree.Files[Name]

                Cmp = NewItem.Compare(OldItem)
                if Cmp == FileInfo.CmpChanged:
                        Stored.append(Name)
                        NewTree.Files[Name].Archive = NewArchiveNum

        # Copy existing info from old tree, provided archive still exists
        ArchiveDict = {}
        for n in ExistingArchives:
                ArchiveDict[n] = 1
        
        for (k, Item) in NewTree.Files.iteritems():
                if Item.Archive != 0:
                        continue
                OldItem = OldTree.Files[k]
                if OldItem.Archive in ArchiveDict:
                        Item.SetHash(OldItem.Hash())
                        Item.Archive = OldItem.Archive
                else:
                        Stored.append(Item.Name)
                        Item.Archive = NewArchiveNum

        # Limit total size to specified value
        if MaxTotalSize > 0:
                # Keep only oldest entries
                List = [(NewTree.Files[k].MTime, NewTree.Files[k].Name, NewTree.Files[k]) for k in Stored]
                List.sort()
                CurSize = 0
                for i in range(len(List)):
                        Item = List[i][2]
                        CurSize += Item.PaddedSize(BlockSize)
                        if CurSize > MaxTotalSize:
                                if i == 0:
                                        raise Error, "Not enough room on medium for first file"
                                for (MTime, Name, Item) in List[i:]:
                                        del NewTree.Files[Item.Name]
                                break
                        Item.SetHash("")
                        Item.Archive = NewArchiveNum
                
        return NewTree
        

# Archive descriptor
def ListArchives(DescriptorBase):
        """Return the list of available archive descriptors."""
        Files = glob.glob(DescriptorBase + "." + SuffixSize * "[0-9]")
        Archives = [int(File[-SuffixSize:]) for File in Files]
        Archives.sort()
        if Archives and Archives[0] == 0:
                del Archives[0]
        return Archives


def ArchiveDescriptorName(DescriptorBase, ArchiveNum):
        """Generate the name of an archive descriptor from the base name and the archive number."""
        Suffix = ".%0*d" % (SuffixSize, ArchiveNum)
        return DescriptorBase + Suffix
        
        
def ReadArchiveDescriptor(DescriptorBase, ArchiveNum):
        """Read a complete archive descriptor."""
        Tree = FsTree()
        FileName = ArchiveDescriptorName(DescriptorBase, ArchiveNum)
        Input = open(FileName, "r")
        try:
                try:
                        Tree.Parse(Input)
                except ParseError, e:
                        raise ParseError, os.path.basename(FileName) + ":" + str(e)
                return Tree
        finally:
                Input.close()
        

# Filesystem walking
def WalkPath(Path, Tree):
        """Walk the filesystem and add entries to an FsTree."""
        def ProcessEntry(Arg, DirName, Names):
                for Entry in Names:
                        EntryName = os.path.join(DirName, Entry)
                        Item = LoadFileInfo(EntryName)
                        Arg.Add(Item)

        TopEntry = LoadFileInfo(Path)
        Tree.Add(TopEntry)
        os.path.walk(Path, ProcessEntry, Tree)


def WalkPaths(Paths, Filter = None):
        """Construct an FsTree by walking multiple paths of the filesystem."""
        Tree = FsTree()
        for Path in Paths:
                WalkPath(Path, Tree)
        if Filter is not None:
                Filter(Tree.Links)
                Filter(Tree.Files)
        return Tree


# Descriptor creation
def CreateDescriptor(DescriptorBase, Paths, Filter, MaxTotalSize = 0):
        """Produce a new backup archive descriptor."""
        Archives = ListArchives(DescriptorBase)
        if not Archives:
                Archive = 1
                OldTree = FsTree()
        else:
                Archive = Archives[-1] + 1
                OldTree = ReadArchiveDescriptor(DescriptorBase, Archive - 1)

        PhysicalTree = WalkPaths(Paths, Filter)
        NewTree = BackupTreeMerge(OldTree, PhysicalTree, Archive, Archives, MaxTotalSize)
        NewTree.SetMeta(Archive)
        Descriptor = NewTree.MakeDescriptor()
        return (Archive, Descriptor)                


# Status creation
def CreateStatus(DescriptorBase, Archive, ShowContent):
        """Produce a status output for a specific archive."""
        Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
        Status = Tree.CreateStatus(Archive, ShowContent)
        return Status
        

def CreateSyncStatus(DescriptorBase, Paths, Filter, ShowContent):
        """Produce a synchronization status ouptut of the current state of the filesystem."""
        Archives = ListArchives(DescriptorBase)
        if not Archives:
                OldTree = FsTree()
        else:
                OldTree = ReadArchiveDescriptor(DescriptorBase, Archives[-1])

        PhysicalTree = WalkPaths(Paths, Filter)
        NewTree = BackupTreeMerge(OldTree, PhysicalTree, -1, Archives)
        Status = NewTree.CreateStatus(-1, ShowContent)
        return Status
        

# Graft list creation
def GraftEscape(s):
        """Escape a file name to be used as a graft point."""
        s = s.replace("\\", "\\\\")
        s = s.replace("=", "\\=")
        return s


def GraftEntry(Src, Dst):
        """Generate a graft list entry."""
        while Dst.startswith("/"):
                Dst = Dst[1:]
        return GraftEscape(Dst) + "=" + GraftEscape(Src)

                
def CreateGraftList(DescriptorBase, Archive):
        """Produce a graft list that can be fed to mkisofs."""
        DescName = ArchiveDescriptorName(DescriptorBase, Archive)
        Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
        Content = []
        for Item in Tree.Files.itervalues():
                if Item.Archive != Archive:
                        continue
                Content.append(GraftEntry(os.path.abspath(Item.Name), Item.Name))
        Content.sort()
        Content.insert(0, GraftEntry(DescriptorBase, os.path.join(DescriptorDir, os.path.basename(DescriptorBase))))
        Content.insert(1, GraftEntry(DescName, os.path.join(DescriptorDir, os.path.basename(DescName))))
        return "\n".join(Content) + "\n"


# Dictionary filter
class DictFilter:
        "Dictionary filter."
        def __init__(self):
                self.ExclDict = None
                self.ExclGlobs = []
                self.ExclRegEx = []
                
        def AddExcludeGlob(self, Pattern):
                self.ExclDict = None
                self.ExclGlobs.append(Pattern)

        def AddExcludeRegEx(self, Pattern):
                self.ExclRegEx.append(re.compile(Pattern))

        def MakeExclDict(self):
                if self.ExclDict is not None:
                        return
                self.ExclDict = {}
                for Glob in self.ExclGlobs:
                        for Item in glob.glob(Glob):
                                self.ExclDict[Item] = 0
        
        def __call__(self, Dict):
                self.MakeExclDict()
                for k in Dict.keys():
                        if k in self.ExclDict:
                                del Dict[k]
                                continue
                        for Pattern in self.ExclRegEx:
                                if Pattern.match(k):
                                        del Dict[k]

        
# Configuration parser
class ConfigParser(ScriptParser):
        "Configuration parser."
        Archive = 0
        Create = 0
        GraftList = 0
        Help = 0
        Print = 0
        Status = 0
        Verbose = 0
        Descriptor = ""

        ArchiveSize = 0
        BaseDir = ""

        def __init__(self, Argv):
                super(ConfigParser, self).__init__()
                self.AddGlobal(ArchiveSize = self.SetArchiveSize,
                               BaseDir = self.SetBaseDir,
                               ExcludeGlob = self.AddExcludeGlob,
                               ExcludeRegEx = self.AddExcludeRegEx,
                               HashFunction = self.SetHashFunction,
                               Input = self.AddInput)

                self.InputGlobs = []
                self.Filter = DictFilter()

                (Options, Arguments) = getopt.getopt(Argv[1:],
                        "a:cghpsv",
                        ["archive=", "create", "graft-list", "help", "print",
                         "status", "verbose"])
                for (Opt, Param) in Options:
                        if Opt in ("-a", "--archive"):
                                self.Archive = int(Param)
                        elif Opt in ("-c", "--create"):
                                self.Create = 1
                        elif Opt in ("-g", "--graft-list"):
                                self.GraftList = 1
                        elif Opt in ("-h", "--help"):
                                self.Help = 1
                        elif Opt in ("-p", "--print"):
                                self.Print = 1
                        elif Opt in ("-s", "--status"):
                                self.Status = 1
                        elif Opt in ("-v", "--verbose"):
                                self.Verbose += 1
                
                if len(Arguments) == 0:
                        if self.Help:
                                return
                        raise Error, "Missing configuration file"
                self.Descriptor = os.path.abspath(Arguments[0])
                File = open(self.Descriptor, "r")
                try:
                        try:
                                self.Parse(File)
                        except ParseError, e:
                                raise ParseError, os.path.basename(self.Descriptor) + ":" + str(e)
                finally:
                        File.close()

        def GetInputs(self):
                Inputs = []
                for Input in self.InputGlobs:
                        Entries = glob.glob(Input)
                        if not Entries:
                                Inputs.append(Input)
                        else:
                                Entries.sort()
                                Inputs.extend(Entries)
                return Inputs

        Inputs = property(GetInputs)

        def SetArchiveSize(self, Value):
                if type(Value) == type(""):
                        if Value.endswith("k"):
                                self.ArchiveSize = int(Value[:-1]) * 1024
                        elif Value.endswith("M"):
                                self.ArchiveSize = int(Value[:-1]) * 1024 * 1024
                        else:
                                self.ArchiveSize = int(Value)
                else:
                        self.ArchiveSize = Value

        def SetHashFunction(self, HashFunctionName):
                FileInfo.HashFunction = HashFunctions[HashFunctionName]
                
        def SetBaseDir(self, Value):
                self.BaseDir = Value

        def AddInput(self, Input):
                if os.path.isabs(Input):
                        raise ParseError, "Absolute path '" + Input + "'"
                self.InputGlobs.append(Input)

        def AddExcludeGlob(self, Pattern):
                self.Filter.AddExcludeGlob(Pattern)

        def AddExcludeRegEx(self, Pattern):
                self.Filter.AddExcludeRegEx(Pattern)

                                
def Usage(Argv):
        """Print program usage info."""
        #                     0         1         2         3         4         5         6         7
        #                     01234567890123456789012345678901234567890123456789012345678901234567890123456789
        print >> sys.stderr, "Usage: " + os.path.basename(Argv[0]) + " [commands] [options] ConfigFile\n"
        print >> sys.stderr, "Commands: -c, --create         Create a new archive descriptor"
        print >> sys.stderr, "          -g, --graft-list     Output a graft list for an archive"
        print >> sys.stderr, "          -h, --help           Show this text"
        print >> sys.stderr, "          -p, --print          Print archive information"
        print >> sys.stderr, "          -s, --status         Print current synchronization status\n"
        print >> sys.stderr, "Options:  -a N, --archive N    Operate on archive number N"
        print >> sys.stderr, "          -v, --verbose        Be more verbose"


# Main program
def Main(Argv):
        """Main program."""
        try:
                try:
                        Config = ConfigParser(Argv)
                except (getopt.GetoptError, ValueError, Error), e:
                        print >> sys.stderr, str(e) + "\n"
                        Usage(Argv)
                        return 2

                if Config.Help:
                        print >> sys.stderr, ProgramName + " " + ProgramVersion + "   Synchronization to CD-R"
                        print >> sys.stderr, "Copyright 2003 Remy Blank\n"
                        Usage(Argv)
                        return 2

                # Initial change of directory
                if Config.BaseDir:
                        os.chdir(Config.BaseDir)

                # Sync status printing
                if Config.Status:
                        if not Config.Inputs:
                                Usage(Argv)
                                return 2

                        Status = CreateSyncStatus(Config.Descriptor, Config.Inputs, Config.Filter, Config.Verbose > 0)
                        print Status[:-1]

                # Descriptor creation
                if Config.Create:
                        if not Config.Inputs:
                                Usage(Argv)
                                return 2

                        (Archive, Descriptor) = CreateDescriptor(Config.Descriptor, Config.Inputs,
                                                                 Config.Filter, Config.ArchiveSize)
                        File = open(ArchiveDescriptorName(Config.Descriptor, Archive), "w")
                        try:
                                File.write(Descriptor)
                        finally:
                                File.close()
                        Config.Archive = Archive

                # Status printing
                if Config.Print:
                        if Config.Archive == 0:
                                print >> sys.stderr, "No archive number specified\n"
                                Usage(Argv)
                                return 2

                        Status = CreateStatus(Config.Descriptor, Config.Archive, Config.Verbose > 0)
                        print Status[:-1]

                # Graft list output
                if Config.GraftList:
                        if Config.Archive == 0:
                                print >> sys.stderr, "No archive number specified\n"
                                Usage(Argv)
                                return 2

                        GraftList = CreateGraftList(Config.Descriptor, Config.Archive)
                        print GraftList[:-1]

                return 0

        except (ParseError, Error, EnvironmentError), e:
                print >> sys.stderr, str(e)
                return 1

        except KeyboardInterrupt, e:
                return 1

                
# Main entry point
if __name__ == "__main__":
        sys.exit(Main(sys.argv))

