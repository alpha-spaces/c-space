#!/bin/env python
"""\
Test suite runner
Copyright (C) 2006 Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

from optparse import OptionParser
import os
import sys
import unittest

__version__ = "1.3"
__author__ = "Remy Blank"


def actionDecrement(option, opt, value, parser):
    setattr(parser.values, option.dest, getattr(parser.values, option.dest) - 1)
        

def addModule(path, modules, projectDir):
    """Add module name of path to modules if it is a module."""
    if not path.startswith(projectDir):
        sys.stderr.write("Ignoring '%s'\n" % path)
        return
    name = os.path.splitext(path[len(projectDir) + 1:])[0].replace(os.sep, ".")
    modules.append(name)
        

def main(argv):
    """Parse command line and execute tests."""
    parser = OptionParser("%prog [options] [module ...]", version="%prog " + __version__)
    parser.set_defaults(verbosity=1)
    parser.add_option("-q", "--quiet", action="callback", callback=actionDecrement, dest="verbosity",
        help="be less verbose")
    parser.add_option("-v", "--verbose", action="count", dest="verbosity",
        help="be more verbose")
    (options, paths) = parser.parse_args()
    
    suite = unittest.TestSuite()
    loader = unittest.defaultTestLoader

    scriptDir = os.path.abspath(os.path.dirname(__file__))
    projectDir = os.path.dirname(scriptDir)
    
    # Generate a list of module names
    modules = []
    for path in paths or [scriptDir]:
        path = os.path.abspath(path)
        if os.path.isfile(path):
            addModule(path, modules, projectDir)
        elif os.path.isdir(path):
            for (top, dirs, nonDirs) in os.walk(path):
                for each in nonDirs:
                    if not (each.endswith("Test.py") 
                        or (each.startswith("test") and each.endswith(".py"))):
                        continue
                    modPath = os.path.join(top, each)
                    if os.path.isfile(modPath):
                        addModule(modPath, modules, projectDir)
                dirs[:] = [each for each in dirs 
                    if os.path.isfile(os.path.join(top, each, "__init__.py"))]
        else:
            sys.stderr.write("Ignoring '%s'\n" % path)
        
    sys.path.insert(0, projectDir)
    sys.path.insert(1, os.path.join(projectDir, "lib"))

    # Try to import each module name and create test objects
    for each in modules:
        try:
            module = __import__(each, None, None, ["__doc__"])
        except ImportError, e:
            sys.stderr.write(str(e) + "\n")
        else:
            suite.addTest(loader.loadTestsFromModule(module))
    
    # Run test suite
    runner = unittest.TextTestRunner(verbosity=options.verbosity)
    result = runner.run(suite)
    return not result.wasSuccessful()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
