"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import unittest
import re

import sync2cd

# Shell-style pattern to regexp converter
class GlobToRegexpTest(unittest.TestCase):
        def testNoPattern(self):
                "Path containing no pattern"
                Input = "/home/test/a file.mp3"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output, re.escape(Input) + "$")

        def testStarPattern(self):
                "Path containing a star pattern"
                Input = "/home/te*t/my * file.mp*"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[^/]*" + re.escape("t/my ")
                        + "[^/]*" + re.escape(" file.mp") + "[^/]*" + "$")

        def testDoubleStarPattern(self):
                "Path containing a double-star pattern"
                Input = "/home/te**t/my ** file.mp**"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + ".*" + re.escape("t/my ")
                        + ".*" + re.escape(" file.mp") + ".*" + "$")

                self.assertEqual(sync2cd.GlobToRegexp("test*"),
                                 "test[^/]*$")

        def testQuestionPattern(self):
                "Path containing a question-mark pattern"
                Input = "/home/te?t/my ? file.mp?"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[^/]" + re.escape("t/my ")
                        + "[^/]" + re.escape(" file.mp") + "[^/]" + "$")

        def testRangePatterns(self):
                "Path containing a character range pattern"
                Input = "/home/te[a-c]t/my [b-d0-9] file.mp[23]"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[a-c]" + re.escape("t/my ")
                        + "[b-d0-9]" + re.escape(" file.mp") + "[23]" + "$")

                self.assertEqual(sync2cd.GlobToRegexp("[!abc]"),
                                 "[^abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[a!bc]"),
                                 "[a!bc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[^abc]"),
                                 "[^abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[]abc]"),
                                 "[]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[!]abc]"),
                                 "[^]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[^]abc]"),
                                 "[^]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[abc"),
                                 "\\[abc$")
                self.assertEqual(sync2cd.GlobToRegexp("[ab\\s]"),
                                 "[ab\\\\s]$")
