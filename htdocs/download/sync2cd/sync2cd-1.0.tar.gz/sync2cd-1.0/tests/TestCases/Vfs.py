"""\
Virtual filesystem for sync2cd tests
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import unittest
import sys
import os
import stat
import StringIO
import md5

import sync2cd

# Generate file entries
if 0:
        def ProcessEntry(Arg, DirName, Names):
                print "test"
                for Entry in Names:
                        File = os.path.join(DirName, Entry)
                        s = os.lstat(File)
                        print '"' + File + '": ' + str(s)

        os.path.walk("/dev", ProcessEntry, 0)
        sys.exit(0)


# A set of test files and directories       
TestFiles = {
        "/home": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/home/test": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1/dir1.1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1/dir1.1/file5.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/home/test/dir1/file4.mp3": ((33204, 7061930L, 9L, 1, 500, 505, 542594L, 1062349591, 1056059953, 1056059953), "File 4 is also non-empty"),
        "/home/test/dir2": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir2/file6.mp3": ((33152, 377119L, 774L, 1, 500, 12, 0L, 1053379283, 1021222945, 1021222945), "Is this file 6?"),
        "/home/test/dir2/file7.mp3": ((33060, 737386L, 774L, 1, 1, 1, 124L, 1061249091, 1018928518, 1034548145), "File 7 is short"),
        "/home/test/dir3": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir3/dir3.1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir3/dir3.1/file9.mp3": ((33188, 737171L, 774L, 1, 0, 0, 492L, 1061249091, 1018927583, 1034548105), "We finish with file 9"),
        "/home/test/dir3/file8.mp3": ((33060, 737379L, 774L, 1, 1, 1, 111L, 1061249091, 1018928511, 1034548145), "In file 8 there is no data"),
        "/home/test/file1.mp3": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), "Content 1"),
        "/home/test/file2.mp3": ((33270, 1407445L, 774L, 1, 500, 600, 1280L, 1063048300, 1063048300, 1063048300), "Content 1"),
        "/home/test/file3.mp3": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 990000000, 1063048396), "Content 3"),
        "/home/test/link1.mp3": ((41471, 441542L, 774L, 1, 0, 0, 11L, 1067447134, 1034546253, 1034546253), "home/test/file1.mp3"),
        "/lost": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/lost/file1.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file2.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file3.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file4.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/test": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir/Music": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir/Pictures": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/special": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/special/gpmdata": ((4532, 98121L, 771L, 1, 0, 0, 0L, 1072821519, 1007419555, 1072821519), ),
        "/special/lircd": ((49588, 98936L, 771L, 1, 0, 500, 0L, 1072821521, 992657524, 1072821521), ),
        "/special/hda1": ((25008, 98124L, 771L, 1, 0, 6, 0L, 1072821519, 1018535114, 1072821519), 769),
        "/special/random": ((8612, 99633L, 771L, 1, 0, 0, 0L, 1074206037, 1018535114, 1072821521), 264),

        "/test_backup.0000": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), "Dummy descriptor"),
        "/test_backup.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
F('home/test/dir1/file4.mp3', 0664, 501, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 501, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018920000, 124, '433b7d897d3113a4f05f3ce50ad40000', 1)
"""),
        "/test_backup.0002": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Sync2cd(Archive = 2, Time = 12345678, Version = 1)
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991200000, 1463, '00000000000000000000000000000000', 1)
F('home/test/dir1/file4.mp3', 0664, 501, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 501, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
#F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)
#F('home/test/file3.mp3', 0770, 500, 600, 990000000, 1280, 'e514979236a3b13cd9a4e81c43595f04', 0)
F('home/test/file10.mp3', 0770, 500, 600, 1063048300, 1280, '01234567890123456789012345678901', 0)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
"""),
        "/lost_backup": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("lost/file[14].mp3")
"""),
        "/lost_backup.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D('lost', 0700, 500, 600, 1067336294)
F('lost/file1.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
"""),
        "/lost_backup.0003": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Sync2cd(Archive = 3, Time = 12340000, Version = 1)
D('lost', 0700, 500, 600, 1067336294)
F('lost/file1.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
F('lost/file2.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 2)
F('lost/file3.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
"""),
        "/bad_descriptor.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D('lost', 0700, 500, 600, 1067336294)
F('lost/file1.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
F('lost/file2.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
BadLine('This line is bad')
F('lost/file3.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
"""),
        "/empty_file": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
"""),
        "/empty_config": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
Input("Nothing")
"""),
        "/test_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
MediumSize("650M")
HashFunction("sha1")
Sort("alpha")
BaseDir("/test/dir")
Input("Music")
Input("Pictures")
"""),
        "/absolute_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
MediumSize("650M")
BaseDir("/test/dir")
Input("/home/Music")
"""),
        "/exclude_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("home/test")
Exclude("home/test/dir1/*.mp3")
ExcludeRegexp("home/test/dir2/([^/]+/)?[^/]+\\.mp3")
ExcludeRegexp("home/test/dir2/([^/]+/)?[^/]+\\.mp3")
"""),
        "/exclude_descriptor_non_root": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/home")
Input("test")
Exclude("test/dir1/*.mp3")
ExcludeRegexp("test/dir2/([^/]+/)?[^/]+\\.mp3")
"""),
        "/exclude_dir": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("home/test")
Exclude("home/test/dir1")
""")
}


# Virtual filesystem
class VfsTestCase(unittest.TestCase):
        """Setup test case for our 'virtual' filesystem."""
        def setUp(self):
                import __builtin__ as __builtins__
                self.OldOpen = __builtins__.open
                self.OldStat = os.stat
                self.OldLstat = os.lstat
                self.OldListDir = os.listdir
                self.OldReadLink = os.readlink
                self.OldGetCwd = os.getcwd
                self.OldHash = sync2cd.FileInfo.HashFunction
                __builtins__.open = self.open
                os.stat = self.stat
                os.lstat = self.lstat
                os.listdir = self.listdir
                os.readlink = self.readlink
                self.cwd = "/"
                os.getcwd = self.getcwd
                sync2cd.FileInfo.HashFunction = md5

                # Creation support
                self.Entities = {}
                self.OldCreator = sync2cd.DirEntInfo.Creator
                sync2cd.DirEntInfo.Creator = self

        def tearDown(self):
                import __builtin__ as __builtins__
                __builtins__.open = self.OldOpen
                os.stat = self.OldStat
                os.lstat = self.OldLstat
                os.listdir = self.OldListDir
                os.readlink = self.OldReadLink
                os.getcwd = self.OldGetCwd
                sync2cd.FileInfo.HashFunction = self.OldHash

                sync2cd.DirEntInfo.Creator = self.OldCreator

        def open(self, Path, Mode):
                Path = os.path.abspath(Path)
                try:
                        return StringIO.StringIO(TestFiles[Path][1])
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def stat(self, Path):
                Path = os.path.abspath(Path)
                try:
                        Data = TestFiles[Path]
                        Mode = Data[0][stat.ST_MODE]
                        RDev = 0
                        if stat.S_ISBLK(Mode) or stat.S_ISCHR(Mode):
                                RDev = Data[1]
                        return os.stat_result(Data[0], {"st_rdev": RDev})

                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def lstat(self, Path):
                Path = os.path.abspath(Path)
                try:
                        Data = TestFiles[Path]
                        Mode = Data[0][stat.ST_MODE]
                        RDev = 0
                        if stat.S_ISBLK(Mode) or stat.S_ISCHR(Mode):
                                RDev = Data[1]
                        return os.stat_result(Data[0], {"st_rdev": RDev})
                        
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def listdir(self, Path):
                Path = os.path.abspath(Path)
                if not Path.endswith("/"):
                        Path += "/"
                Entries = []
                for k in TestFiles.iterkeys():
                        if k.startswith(Path):
                                Name = k[len(Path):]
                                if "/" not in Name:
                                        Entries.append(Name)
                return Entries

        def readlink(self, Path):
                Path = os.path.abspath(Path)
                try:
                        return TestFiles[Path][1]
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"
        
        def getcwd(self):
                return self.cwd

        def SetStat(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                entry = self.Entities[Path]
                for each in ["Mode", "Uid", "Gid", "ATime", "MTime"]:
                        value = locals()[each]
                        if value is not None:
                                entry[1][each] = value

        def CreateFile(self, Path, SrcPath, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("F", {"SrcPath": SrcPath})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

        def CreateDir(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("D", {})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

        def CreateSymlink(self, Path, Target, Uid=None, Gid=None):
                self.Entities[Path] = ("L", {"Target": Target})
                self.SetStat(Path, None, Uid, Gid, None, None)

        def CreateCharDevice(self, Path, Device, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("C", {"Device": Device})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

        def CreateBlockDevice(self, Path, Device, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("B", {"Device": Device})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

        def CreatePipe(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("P", {})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

        def CreateSocket(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
                self.Entities[Path] = ("S", {})
                self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)
