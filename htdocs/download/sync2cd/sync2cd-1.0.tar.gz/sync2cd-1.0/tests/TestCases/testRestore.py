"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
from cStringIO import StringIO
import os.path
from Vfs import VfsTestCase
import sync2cd

# Generating restore information
class RestoreInfoTest(VfsTestCase):
        def setUp(self):
                super(RestoreInfoTest, self).setUp()
                self.mounter = os.path.join(os.path.dirname(__file__), "mounter.sh")
                self.Tree = sync2cd.FsTree()
                Input = StringIO('''\
Sync2cd(Archive = 3, Time = 12345678, Version = 1)
D('home', 0700, 500, 600, 1067336294)
D('home/test', 0700, 500, 600, 1067336294)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '0123456789012345', 3)
F('home/test/file2.mp3', 0770, 500, 600, 1063048395, 1280L, '0123456789012345', 2)
F('home/test/file3.mp3', 0770, 500, 600, 1063048395, 1280L, '0123456789012345', 1)
F('home/test/file4.mp3', 0770, 500, 600, 1063048395, 1280L, '0123456789012345', 2)
D('special', 0700, 500, 600, 1067336294)
P('special/gpmdata', 0664, 0, 0, 1007419555)
B('special/hda1', 0660, 0, 6, 1018535114, 769)
S('special/lircd', 0664, 0, 500, 992657524)
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
                self.Tree.Parse(Input)
                
        def testGenerateAll(self):
                """Restore info generation for all files"""
                Filter = sync2cd.FilterList()
                Filter.AddGlob("**")
                (Dirs, Files, Others) = self.Tree.MakeRestoreList(Filter)
                self.assertEqual([
                        "home",
                        "home/test",
                        "special"
                ], Dirs)
                self.assertEqual({
                        1: ["home/test/file3.mp3"],
                        2: ["home/test/file2.mp3", "home/test/file4.mp3"],
                        3: ["home/test/file1.mp3"]
                }, Files)
                self.assertEqual([
                        "home/test/link1.mp3",
                        "special/gpmdata",
                        "special/hda1",
                        "special/lircd",
                        "special/random"
                ], Others)

        def testGenerateSubset(self):
                """Restore info generation for a subset of files"""
                Filter = sync2cd.FilterList()
                Filter.AddGlob("**/file?.mp3")
                Filter.AddGlob("special/h*")
                (Dirs, Files, Others) = self.Tree.MakeRestoreList(Filter)
                self.assertEqual([
                        "home",
                        "home/test",
                        "special"
                ], Dirs)
                self.assertEqual({
                        1: ["home/test/file3.mp3"],
                        2: ["home/test/file2.mp3", "home/test/file4.mp3"],
                        3: ["home/test/file1.mp3"]
                }, Files)
                self.assertEqual([
                        "special/hda1"
                ], Others)

        def testGenerateDirMatch(self):
                """Restore info generation when matching a directory"""
                Filter = sync2cd.FilterList()
                Filter.AddGlob("**/test")
                (Dirs, Files, Others) = self.Tree.MakeRestoreList(Filter)
                self.assertEqual([
                        "home",
                        "home/test"
                ], Dirs)
                self.assertEqual({
                        1: ["home/test/file3.mp3"],
                        2: ["home/test/file2.mp3", "home/test/file4.mp3"],
                        3: ["home/test/file1.mp3"]
                }, Files)
                self.assertEqual([
                        "home/test/link1.mp3"
                ], Others)
                
        def testRestore(self):
                """Restore operation"""
                Patterns = sync2cd.FilterList()
                Patterns.AddGlob("home/test/dir1/d**")
                Patterns.AddGlob("**/file8.*")

                sync2cd.Restore("/test_backup", 0, Patterns, self.mounter + " /mnt/src", "/restore")
 
                self.assertEqual({
                        "/restore/home": ("D", {}),
                        "/restore/home/test": ("D", {"Mode": 0700, "Uid": 500, "Gid": 600, 
                                "MTime": 1067336294}),
                        "/restore/home/test/dir1": ("D", {"Mode": 0700, "Uid": 500, "Gid": 600, 
                                "MTime": 1067336294}),
                        "/restore/home/test/dir1/dir1.1": ("D", {"Mode": 0700, "Uid": 500, "Gid": 600, 
                                "MTime": 1067336294}),
                        "/restore/home/test/dir1/dir1.1/file5.mp3": ("F", {"Mode": 0644, "Uid": 0, "Gid": 0, 
                                "MTime": 991200000, "SrcPath": "/mnt/src/test_backup.0001/home/test/dir1/dir1.1/file5.mp3"}),
                        "/restore/home/test/dir3": ("D", {"Mode": 0700, "Uid": 500, "Gid": 600, 
                                "MTime": 1067336294}),
                        "/restore/home/test/dir3/file8.mp3": ("F", {"Mode": 0444, "Uid": 1, "Gid": 1, 
                                "MTime": 1018928511, "SrcPath": "/mnt/src/test_backup.0002/home/test/dir3/file8.mp3"})
                        }, self.Entities)

