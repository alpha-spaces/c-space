"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
from Vfs import VfsTestCase
import sync2cd

# Filesystem walking
class TreeWalkTest(VfsTestCase):
        def testTreeWalk(self):
                "Walk a tree"
                Tree = sync2cd.WalkPaths(["home/test"])
                self.assertEqual(len(Tree.Dirs), 6)
                self.assertEqual(len(Tree.Files), 9)
                self.assertEqual(len(Tree.Others), 1)

        def testDescriptorGeneration(self):
                "Generate a descriptor from a tree"
                Tree = sync2cd.WalkPaths(["home/test"])
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 0)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 0)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 0)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 0)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 0)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 0)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)
F('home/test/file3.mp3', 0770, 500, 600, 990000000, 1280, 'e514979236a3b13cd9a4e81c43595f04', 0)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
""")

        def testFileWalking(self):
                "Walking files instead of directories"
                Tree = sync2cd.WalkPaths(["home/test/file1.mp3", "home/test/file2.mp3"])
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)
""")

        def testExcludedWalking(self):
                "Walk a tree with exclusions"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("home/test/dir[13]/*")
                Filter.AddRegexp("home/(.)es\\1/link.\\.mp[123]")
                Tree = sync2cd.WalkPaths(["home/test"], Filter)
                self.assertEqual(len(Tree.Dirs), 4)
                self.assertEqual(len(Tree.Files), 5)
                self.assertEqual(len(Tree.Others), 0)

        def testSpecialFileWalking(self):
                "Walk a tree with special entities"
                Tree = sync2cd.WalkPaths(["special"])
                self.assertEqual(len(Tree.Dirs), 1)
                self.assertEqual(len(Tree.Files), 0)
                self.assertEqual(len(Tree.Others), 4)
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
D('special', 0700, 500, 600, 1067336294)
P('special/gpmdata', 0664, 0, 0, 1007419555)
B('special/hda1', 0660, 0, 6, 1018535114, 769)
S('special/lircd', 0664, 0, 500, 992657524)
C('special/random', 0644, 0, 0, 1018535114, 264)
""")
