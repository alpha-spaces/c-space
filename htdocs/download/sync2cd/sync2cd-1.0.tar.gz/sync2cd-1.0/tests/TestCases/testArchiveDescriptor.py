"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
from Vfs import VfsTestCase
import sync2cd

# Archive descriptors
class ArchiveDescriptorTest(VfsTestCase):
        def testListArchives(self):
                "Find archive description files"
                Archives = sync2cd.ListArchives("/test_backup")
                self.assertEqual(Archives, [1, 2])

        def testArchiveName(self):
                "Make an archive descriptor file name"
                Name = sync2cd.ArchiveDescriptorName("/test_backup", 123)
                self.assertEqual(Name, "/test_backup.0123")
                
        def testReadArchive(self):
                "Read an archive descriptor"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 1)
                self.assertEqual(len(Tree.Dirs), 4)
                self.assertEqual(len(Tree.Files), 4)
                self.assertEqual(len(Tree.Others), 0)

                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                self.assertEqual(len(Tree.Dirs), 6)
                self.assertEqual(len(Tree.Files), 8)
                self.assertEqual(len(Tree.Others), 1)
