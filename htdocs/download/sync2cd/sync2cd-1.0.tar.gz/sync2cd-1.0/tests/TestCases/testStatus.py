"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
from Vfs import VfsTestCase
import sync2cd

# Status printing
class StatusTest(VfsTestCase):
        def testHumanReadable(self):
                "Conversion of a size to a human-readable format"
                self.assertEqual(sync2cd.HumanReadable(0), "0")
                self.assertEqual(sync2cd.HumanReadable(1023), "1023")
                self.assertEqual(sync2cd.HumanReadable(1024), "1.0k")
                self.assertEqual(sync2cd.HumanReadable(5678), "5.5k")
                self.assertEqual(sync2cd.HumanReadable(10230), "9.9k")
                self.assertEqual(sync2cd.HumanReadable(10240), "10k")
                self.assertEqual(sync2cd.HumanReadable(23456), "22k")
                self.assertEqual(sync2cd.HumanReadable(1048575), "1023k")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024), "1.0M")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024), "1.0G")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024), "1.0T")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024 * 1024), "1.0P")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024 * 1024 * 1024), "1.0E")
        
        def testToBytes(self):
                "Conversion from a human-readable format to bytes"
                self.assertEqual(sync2cd.ToBytes(0), 0)
                self.assertEqual(sync2cd.ToBytes(123), 123)
                self.assertEqual(sync2cd.ToBytes(456.789), 456)
                self.assertEqual(sync2cd.ToBytes("0"), 0)
                self.assertEqual(sync2cd.ToBytes("1023"), 1023)
                self.assertEqual(sync2cd.ToBytes("723.6"), 723)
                self.assertEqual(sync2cd.ToBytes("5k"), 5 * 1024)
                self.assertEqual(sync2cd.ToBytes("3.2k"), int(3.2 * 1024))
                self.assertEqual(sync2cd.ToBytes("72M"), 72 * 1024 * 1024)
                self.assertEqual(sync2cd.ToBytes("72.56M"), int(72.56 * 1024 * 1024))
                self.assertEqual(sync2cd.ToBytes("4G"), 4 * 1024 * 1024 * 1024)
                self.assertEqual(sync2cd.ToBytes("4.3G"), int(4.3 * 1024 * 1024 * 1024))
                self.assertEqual(sync2cd.ToBytes("2T"), 2 * 1024 * 1024 * 1024 * 1024)
                self.assertEqual(sync2cd.ToBytes("2.5T"), int(2.5 * 1024 * 1024 * 1024 * 1024))
                self.assertEqual(sync2cd.ToBytes("3P"), 3 * 1024 * 1024 * 1024 * 1024 * 1024)
                self.assertEqual(sync2cd.ToBytes("3.8P"), int(3.8 * 1024 * 1024 * 1024 * 1024 * 1024))
                self.assertEqual(sync2cd.ToBytes("6E"), 6 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
                self.assertEqual(sync2cd.ToBytes("6.7E"), int(6.7 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024))

        def testArchiveStatus(self):
                "Print status for a specific archive"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                Status = Tree.CreateStatus(2, 0)
                self.assertEqual(Status, '''\
Archive:   2
Created:   23.05.1970, 21:21:18 UTC (12345678)
Version:   1
Size:      1.9k (2007 bytes)
Padded:    8.0k (8192 bytes)
''')

        def testArchiveStatusContent(self):
                "Print status for a specific archive with archive content"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                Status = Tree.CreateStatus(2, 1)
                self.assertEqual(Status, '''\
Archive:   2
Created:   23.05.1970, 21:21:18 UTC (12345678)
Version:   1
Size:      1.9k (2007 bytes)
Padded:    8.0k (8192 bytes)
Content:
home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3
home/test/file1.mp3
''')

        def testTreeStatus(self):
                "Print status of current tree"
                Status = sync2cd.CreateSyncStatus("/test_backup", ["home/test"], None, 1, 4096)
                self.assertEqual(Status, '''\
Size:      3.9k (4023 bytes)
Padded:    6.0k (6144 bytes)
Remaining: 2 archives, last one will have 2.0k free
Content:
home/test/dir1/dir1.1/file5.mp3
home/test/file2.mp3
home/test/file3.mp3
''')

        def testFilteredTreeStatus(self):
                "Print status of current tree with filter"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("home/test/dir1/*/*.mp3")
                Status = sync2cd.CreateSyncStatus("/test_backup", ["home/test"], Filter, 1)
                self.assertEqual(Status, '''\
Size:      2.5k (2560 bytes)
Padded:    4.0k (4096 bytes)
Content:
home/test/file2.mp3
home/test/file3.mp3
''')
