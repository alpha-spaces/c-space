"""\
testCreation.py   Test cases for sync2cd.py
Copyright (C) 2005  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

# Module imports
import time

from Vfs import VfsTestCase
import sync2cd

# Descriptor creation
class CreationTest(VfsTestCase):
        def setUp(self):
                VfsTestCase.setUp(self)
                self.OldTime = time.time
                time.time = self.time

        def tearDown(self):
                VfsTestCase.tearDown(self)
                time.time = self.OldTime
        
        def time(self):
                return 12345678

        def testCreation(self):
                "Archive descriptor creation"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None)

                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 3)
F('home/test/file3.mp3', 0770, 500, 600, 1063048300, 1280, 'e514979236a3b13cd9a4e81c43595f04', 3)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')
                
        def testBigEnoughSizedCreation(self):
                "Sized archive descriptor creation, with enough room on the medium"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None, 10000)

                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 3)
F('home/test/file3.mp3', 0770, 500, 600, 1063048300, 1280, 'e514979236a3b13cd9a4e81c43595f04', 3)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')

        def testSizedCreation(self):
                "Sized archive descriptor creation, with truncation"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None, 2048)

                # Only file5.mp3 should be in archive 3
                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')

        def testMissingDescriptor(self):
                "Creation of an archive with one descriptor missing"
                Archives = sync2cd.ListArchives("/lost_backup")
                self.assertEqual(Archives, [1, 3])

                (Archive, Descriptor) = sync2cd.CreateDescriptor("/lost_backup", ["lost"], None)

                self.assertEqual(Archive, 4)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 4, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('lost', 0700, 500, 600, 1067336294)
F('lost/file1.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
F('lost/file2.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 4)
F('lost/file3.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('lost/file4.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 4)
''')

        def testExcludes(self):
                "Config file with exclude patterns"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_descriptor"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_descriptor", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 1)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 1)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('home/test/file3.mp3', 0770, 500, 600, 1063048300, 1280, 'e514979236a3b13cd9a4e81c43595f04', 1)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')

        def testExcludesNonRoot(self):
                "Config file with exclude patterns and non-root base"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_descriptor_non_root"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_descriptor_non_root", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('test', 0700, 500, 600, 1067336294)
D('test/dir1', 0700, 500, 600, 1067336294)
D('test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 1)
D('test/dir2', 0700, 500, 600, 1067336294)
D('test/dir3', 0700, 500, 600, 1067336294)
D('test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 1)
F('test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 1)
F('test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('test/file3.mp3', 0770, 500, 600, 1063048300, 1280, 'e514979236a3b13cd9a4e81c43595f04', 1)
L('test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')

        def testExcludeDir(self):
                "Config file with exclude patterns matching a directory"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_dir"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_dir", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 1)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 1)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 1)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 1)
F('home/test/file3.mp3', 0770, 500, 600, 1063048300, 1280, 'e514979236a3b13cd9a4e81c43595f04', 1)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')
