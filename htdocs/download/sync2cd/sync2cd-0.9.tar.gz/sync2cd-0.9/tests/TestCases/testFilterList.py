"""\
testFilterList.py   Test cases for sync2cd.py
Copyright (C) 2005  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

# Module imports
import unittest

import sync2cd

# Filter list
class FilterListTest(unittest.TestCase):
        def testNoPattern(self):
                "Filter list with no pattern"
                Filter = sync2cd.FilterList()
                self.assert_(not Filter.Match("Test pattern"))

        def testOnePattern(self):
                "Filter list with one pattern"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("Test *")
                self.assert_(Filter.Match("Test pattern"))
                self.assert_(not Filter.Match("Other test pattern"))
        
        def testTwoPatterns(self):
                "Filter list with two patterns"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("Test *")
                Filter.AddRegexp(".* test .*")
                self.assert_(Filter.Match("Test pattern"))
                self.assert_(Filter.Match("Other test pattern"))
                self.assert_(not Filter.Match("Not matched"))
