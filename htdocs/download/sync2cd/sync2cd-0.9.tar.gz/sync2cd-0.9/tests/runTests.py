#!/usr/bin/python
"""\
runTests.py   Test runner for sync2cd tests
Copyright (C) 2005  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

from optparse import OptionParser
import os
import sys
import TestCases
import unittest

__version__ = "1.0"
__author__ = "Remy Blank"


def actionDecrement(option, opt, value, parser):
        setattr(parser.values, option.dest, getattr(parser.values, option.dest) - 1)
        

def main(argv=sys.argv):
        """Script execution function"""
        parser = OptionParser("%prog [options] [module ...]", version="%prog " + __version__)
        parser.set_defaults(verbosity=1)
        parser.add_option("-q", "--quiet", action="callback", callback=actionDecrement, dest="verbosity",
                help="be less verbose")
        parser.add_option("-v", "--verbose", action="count", dest="verbosity",
                help="be more verbose")
        (options, modules) = parser.parse_args()
        
        suite = unittest.TestSuite()
        loader = unittest.defaultTestLoader
        testCases = ["test" + each for each in modules]
        try:
                sys.path.append(os.path.join(os.path.dirname(argv[0]), os.path.pardir, "lib"))
                for each in testCases or TestCases.__all__:
                        module = getattr(__import__("TestCases." + each), each)
                        suite.addTest(loader.loadTestsFromModule(module))
        except ImportError, e:
                parser.error(e.__class__.__name__ + ": " + str(e))
        
        runner = unittest.TextTestRunner(verbosity=options.verbosity)
        result = runner.run(suite)
        return not result.wasSuccessful()


if __name__ == "__main__":
        sys.exit(main())
