#!/usr/bin/env python
"""\
setup.py   Installation script for sync2cd.py
Copyright (C) 2005  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

import sys
from distutils.core import setup

Version = "0.9"

if sys.version_info[:2] < (2, 2):
        print "sync2cd.py requires version 2.2 or later of python"
        sys.exit(1)
        
setup(name = "sync2cd",
      version = Version,
      author = "Remy Blank",
      author_email = "sync2cd@calins.ch",
      url = "http://www.calins.ch/software/sync2cd.html",
      license = "GPL",
      description = "Incremental archiving tool to CD/DVD",
      long_description = """\
sync2cd is an incremental archiving tool. It allows backing up complete
filesystem hierarchies to multiple backup media (e.g. CD-R). Files are archived
incrementally, i.e. only new or changed files are stored during an archive
operation.

All entity types are supported: directories, files, symlinks, named pipes,
sockets, block and character devices.
""",
      package_dir = {"": "lib"},
      py_modules = ["sync2cd"],
      scripts = [
              "bin/sync2cd",
              "bin/sync2cd_mounter.sh",
              "bin/sync2cd_mkcd.sh",
              "bin/sync2cd_mkdvd.sh"],
      data_files = [("share/doc/sync2cd-%s" % Version,
                        ["ChangeLog",
                         "COPYING",
                         "README",
                         "doc/sync2cd.html"])]
      )
