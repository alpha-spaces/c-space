"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import os
from Vfs import VfsTestCase
import sync2cd

# Configuration parsing
class ConfigParserTest(VfsTestCase):
    def testCommandLineArgs(self):
        "Command line arguments"
        Args = ["sync2cd.py",
                "--archive", "1",
                "--create",
                "--graft-list",
                "--medium-size", "10M",
                "--print",
                "--sort", "alpha",
                "--status",
                "--verbose",
                "-v",
                "/empty_config"]
        Config = sync2cd.ConfigParser(Args)
        self.assertEqual(Config.Archive, 1)
        self.assert_(Config.Create)
        self.assertEqual(Config.Destination, "")
        self.assert_(Config.GraftList)
        self.assert_(not Config.Help)
        self.assertEqual(Config.MediumSize, 10 * 1024 * 1024)
        self.assertEqual(Config.Mounter, "")
        self.assert_(Config.Print)
        self.assert_(not Config.Restore)
        self.assertEqual(Config.Sort, "alpha")
        self.assert_(Config.Status)
        self.assertEqual(Config.Verbose, 2)
        self.assertEqual(os.path.abspath(sync2cd.__file__.strip("co")), Config.ScriptPath.strip("co"))
            
    def testRestoreCommandLine(self):
        "Command line arguments for restore"
        Args = ["sync2cd.py",
                "--archive", "1",
                "--destination", "/restore",
                "--glob", "home/**",
                "--mount", "/bin/my_script",
                "--regexp", "home/.*",
                "--restore",
                "/empty_config"]
        Config = sync2cd.ConfigParser(Args)
        self.assertEqual(Config.Archive, 1)
        self.assert_(not Config.Create)
        self.assertEqual("/restore", Config.Destination)
        self.assertEqual(Config.Mounter, "/bin/my_script")
        self.assertEqual(2, Config.Patterns.Count())
        self.assert_(Config.Restore)

    def testCommandLineHelp(self):
        "Command line arguments with help and no config file"
        Args = ["sync2cd.py", "--help"]
        Config = sync2cd.ConfigParser(Args)
        self.assert_(Config.Help)

    def testTooManyConfigFiles(self):
        "More than one config file"
        Args = ["sync2cd.py", "/empty_config", "/test_descriptor"]
        self.assertRaises(sync2cd.Error, sync2cd.ConfigParser, Args)

    def testParsing(self):
        "Parsing of a config file"
        Config = sync2cd.ConfigParser(["sync2cd.py", "/test_descriptor"])
        self.assertEqual(Config.MediumSize, 650 * 1024 * 1024)
        self.assertEqual(sync2cd.FileInfo.HashFunction, sync2cd.sha)
        self.assertEqual(Config.Sort, "alpha")
        self.assertEqual(Config.BaseDir, "/test/dir")
        self.assertEqual(len(Config.Inputs), 2)
        self.assertEqual(Config.Inputs[0], "Music")
        self.assertEqual(Config.Inputs[1], "Pictures")

    def testMediumSizeOverride(self):
        "Overriding of medium size on command line"
        Config = sync2cd.ConfigParser(["sync2cd.py", "--medium-size", "700M", "/test_descriptor"])
        self.assertEqual(Config.MediumSize, 700 * 1024 * 1024)

    def testAbsoluteInput(self):
        "Config file with absolute input specification"
        try:
            Config = sync2cd.ConfigParser(["sync2cd.py", "/absolute_descriptor"])
            self.fail()
        except sync2cd.ParseError, e:
            self.assert_(str(e).startswith("absolute_descriptor:4: ParseError: "))

    def testGlobInput(self):
        "Input specification with wildcards"
        Config = sync2cd.ConfigParser(["sync2cd.py", "/lost_backup"])
        self.assertEqual(Config.BaseDir, "/")
        self.assertEqual(len(Config.Inputs), 2)
        self.assertEqual(Config.Inputs[0], "lost/file1.mp3")
        self.assertEqual(Config.Inputs[1], "lost/file4.mp3")
