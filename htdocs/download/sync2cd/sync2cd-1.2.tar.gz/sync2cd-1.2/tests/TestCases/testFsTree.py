# -*- coding: iso-8859-1 -*-

"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import StringIO

from Vfs import VfsTestCase
import sync2cd

# Filesystem tree
class FsTreeTest(VfsTestCase):
    def testEmptyList(self):
        "Loading an empty list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO("")
        Tree.Parse(Input)
        self.assertEqual({}, Tree.items)

    def testSingleDir(self):
        "Loading a single-dir list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
D('home/test', 0700, 500, 600, 1067336294)
''')
        Tree.Parse(Input)
        Ent = Tree.items["home/test"]
        self.assertEqual(Ent.Mode, 0700)
        self.assertEqual(Ent.Owner, 500)
        self.assertEqual(Ent.Group, 600)
        self.assertEqual(Ent.MTime, 1067336294)

    def testSingleFile(self):
        "Loading a single-file list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 42)
''')
        Tree.Parse(Input)
        Ent = Tree.items["home/test/file1.mp3"]
        self.assertEqual(Ent.Mode, 0770)
        self.assertEqual(Ent.Owner, 500)
        self.assertEqual(Ent.Group, 600)
        self.assertEqual(Ent.MTime, 1063048395)
        self.assertEqual(Ent.Size, 1280)
        self.assertEqual(Ent.Hash(), sync2cd.FromHex("01234567890123456789012345678901"))
        self.assertEqual(Ent.Archive, 42)

    def testSingleLink(self):
        "Loading a single-link list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')
        Tree.Parse(Input)
        Ent = Tree.items["home/test/link1.mp3"]
        self.assertEqual(Ent.Mode, 0777)
        self.assertEqual(Ent.Owner, 0)
        self.assertEqual(Ent.Group, 0)
        self.assertEqual(Ent.MTime, 1034546253)
        self.assertEqual(Ent.Target, "home/test/file1.mp3")

    def testSinglePipe(self):
        "Loading a single-pipe list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
P('special/gpmdata', 0664, 0, 0, 1007419555)
''')
        Tree.Parse(Input)
        Ent = Tree.items["special/gpmdata"]
        self.assertEqual(Ent.Mode, 0664)
        self.assertEqual(Ent.Owner, 0)
        self.assertEqual(Ent.Group, 0)
        self.assertEqual(Ent.MTime, 1007419555)

    def testSingleSocket(self):
        "Loading a single-socket list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
S('special/lircd', 0664, 0, 500, 992657524)
''')
        Tree.Parse(Input)
        Ent = Tree.items["special/lircd"]
        self.assertEqual(Ent.Mode, 0664)
        self.assertEqual(Ent.Owner, 0)
        self.assertEqual(Ent.Group, 500)
        self.assertEqual(Ent.MTime, 992657524)

    def testSingleBlockDev(self):
        "Loading a single-block-device list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
B('special/hda1', 0660, 0, 6, 1018535114, 769)
''')
        Tree.Parse(Input)
        Ent = Tree.items["special/hda1"]
        self.assertEqual(Ent.Mode, 0660)
        self.assertEqual(Ent.Owner, 0)
        self.assertEqual(Ent.Group, 6)
        self.assertEqual(Ent.MTime, 1018535114)
        self.assertEqual(Ent.RDev, 769)

    def testSingleCharDev(self):
        "Loading a single-char-device list"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
        Tree.Parse(Input)
        Ent = Tree.items["special/random"]
        self.assertEqual(Ent.Mode, 0644)
        self.assertEqual(Ent.Owner, 0)
        self.assertEqual(Ent.Group, 0)
        self.assertEqual(Ent.MTime, 1018535114)
        self.assertEqual(Ent.RDev, 264)

    def testOneOfEach(self):
        "Loading one item of each type"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
Sync2cd(Archive = 3, Time = 12345678, Version = 1)
D('home/test', 0700, 500, 600, 1067336294)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 42)
P('special/gpmdata', 0664, 0, 0, 1007419555)
B('special/hda1', 0660, 0, 6, 1018535114, 769)
S('special/lircd', 0664, 0, 500, 992657524)
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
        Tree.Parse(Input)
        self.assertEqual(Tree.Archive, 3)
        self.assertEqual(Tree.Time, 12345678)
        self.assert_("home/test" in Tree.items)
        self.assert_("home/test/file1.mp3" in Tree.items)
        self.assert_("home/test/link1.mp3" in Tree.items)
        self.assert_("special/gpmdata" in Tree.items)
        self.assert_("special/lircd" in Tree.items)
        self.assert_("special/hda1" in Tree.items)
        self.assert_("special/random" in Tree.items)

    def testLinkWithSpecialChars(self):
        "Loading a link with special chars in the filenames"
        Tree = sync2cd.FsTree()
        Input = StringIO.StringIO('''\
L('home/link"with"quotes', 0777, 0, 0, 1034546253, 'home/target"with"quotes')
L("home/link'with'quotes", 0777, 0, 0, 1034546253, "home/target'with'quotes")
L('home/link"with\\'quotes', 0777, 0, 0, 1034546253, 'home/target"with\\'quotes')
L('home/link_\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4', 0777, 0, 0, 1034546253, 'home/target_\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4')
''')
        Tree.Parse(Input)
        self.assertEqual(Tree.items['home/link"with"quotes'].Target, 'home/target"with"quotes')
        self.assertEqual(Tree.items["home/link'with'quotes"].Target, "home/target'with'quotes")
        self.assertEqual(Tree.items['home/link"with\'quotes'].Target, 'home/target"with\'quotes')
        self.assertEqual(Tree.items['home/link_���\\���'].Target, 'home/target_���\\���')

    def testBadDescriptor(self):
        "Error in descriptor"
        try:
            Tree = sync2cd.ReadArchiveDescriptor("/bad_descriptor", 1)
            self.fail()
        except sync2cd.ParseError, e:
            self.assert_(str(e).startswith("bad_descriptor.0001:5: NameError: "))

    def testBackupMerge(self):
        "Merge two trees for backup purposes"
        OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
        PhysicalTree = sync2cd.WalkPaths(["home/test"])
        NewTree = sync2cd.BackupTreeMerge(OldTree, PhysicalTree, 3, [1, 2])

        out = StringIO.StringIO()
        NewTree.MakeDescriptor(out)
        self.assertEqual(out.getvalue(), """\
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 3)
F('home/test/file3.mp3', 0770, 500, 600, 990000000, 1280, 'e514979236a3b13cd9a4e81c43595f04', 3)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
""")

    def testSizedBackupMerge(self):
        "Merge two trees for backup purposes, with limited medium size"
        OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
        PhysicalTree = sync2cd.WalkPaths(["home/test"])
        NewTree = sync2cd.BackupTreeMerge(OldTree, PhysicalTree, 3, [1, 2], 4096)
        TotalSize = 0
        for Item in NewTree.items.itervalues():
            if not isinstance(Item, sync2cd.FileInfo):
                continue
            if Item.Archive == 3:
                TotalSize += Item.PaddedSize(sync2cd.BlockSize)

        # Only file5.mp3 and file3.mp3 should be in archive 3
        self.assert_(TotalSize <= 4096)
        self.assert_("home/test/dir1/dir1.1/file5.mp3" in NewTree.items)
        self.assert_("home/test/file2.mp3" not in NewTree.items)
        self.assert_("home/test/file3.mp3" in NewTree.items)
        self.assertEqual(3, NewTree.items["home/test/dir1/dir1.1/file5.mp3"].Archive)
        self.assertEqual(3, NewTree.items["home/test/file3.mp3"].Archive)
            
    def testSizedBackupMerge2(self):
        "Merge two trees for backup purposes, with small medium size"
        OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
        PhysicalTree = sync2cd.WalkPaths(["home/test"])
        NewTree = sync2cd.BackupTreeMerge(OldTree, PhysicalTree, 3, [1, 2], 2048)
        TotalSize = 0
        for Item in NewTree.items.itervalues():
            if not isinstance(Item, sync2cd.FileInfo):
                continue
            if Item.Archive == 3:
                TotalSize += Item.PaddedSize(sync2cd.BlockSize)

        # Only file3.mp3 should be in archive 3, and file5.mp3 should be present with old data
        self.assert_(TotalSize <= 2048)
        self.assert_("home/test/dir1/dir1.1/file5.mp3" in NewTree.items)
        self.assert_("home/test/file2.mp3" not in NewTree.items)
        self.assert_("home/test/file3.mp3" in NewTree.items)
        self.assertNotEqual(3, NewTree.items["home/test/dir1/dir1.1/file5.mp3"].Archive)
        self.assertEqual(991200000, NewTree.items["home/test/dir1/dir1.1/file5.mp3"].MTime)
        self.assertEqual(3, NewTree.items["home/test/file3.mp3"].Archive)
