"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import unittest

import sync2cd

# Filter list
class FilterListTest(unittest.TestCase):
    def testNoPattern(self):
        "Filter list with no pattern"
        Filter = sync2cd.FilterList()
        self.assert_(not Filter.Match("Test pattern"))

    def testOnePattern(self):
        "Filter list with one pattern"
        Filter = sync2cd.FilterList()
        Filter.AddGlob("Test *")
        self.assert_(Filter.Match("Test pattern"))
        self.assert_(not Filter.Match("Other test pattern"))
    
    def testTwoPatterns(self):
        "Filter list with two patterns"
        Filter = sync2cd.FilterList()
        Filter.AddGlob("Test *")
        Filter.AddRegexp(".* test .*")
        self.assert_(Filter.Match("Test pattern"))
        self.assert_(Filter.Match("Other test pattern"))
        self.assert_(not Filter.Match("Not matched"))
