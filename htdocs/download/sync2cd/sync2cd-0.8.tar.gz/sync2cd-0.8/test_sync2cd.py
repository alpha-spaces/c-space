#!/usr/bin/env python
"""\
test_sync2cd.py   Test cases for sync2cd.py
Copyright (C) 2004  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

# To do list:
#  - Check for '..' in input specifications (ensure we don't go above BaseDir)
#  - Restore functionality
#  - Verify functionality: check that CD is readable and compare contents
#  - Support hard links
#  - Detect file renames
#  - Customize DescriptorDir in config file
#  - Customize suffix length in config file
#  - Customize block size in config file

# Module imports
import unittest
import sys
import os
import stat
import StringIO
import md5
import time
import re

import sync2cd

# Generate file entries
if 0:
        def ProcessEntry(Arg, DirName, Names):
                print "test"
                for Entry in Names:
                        File = os.path.join(DirName, Entry)
                        s = os.lstat(File)
                        print '"' + File + '": ' + str(s)

        os.path.walk("/dev", ProcessEntry, 0)
        sys.exit(0)


# A set of test files and directories       
TestFiles = {
        "/home": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/home/test": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1/dir1.1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir1/dir1.1/file5.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/home/test/dir1/file4.mp3": ((33204, 7061930L, 9L, 1, 500, 505, 542594L, 1062349591, 1056059953, 1056059953), "File 4 is also non-empty"),
        "/home/test/dir2": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir2/file6.mp3": ((33152, 377119L, 774L, 1, 500, 12, 0L, 1053379283, 1021222945, 1021222945), "Is this file 6?"),
        "/home/test/dir2/file7.mp3": ((33060, 737386L, 774L, 1, 1, 1, 124L, 1061249091, 1018928518, 1034548145), "File 7 is short"),
        "/home/test/dir3": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir3/dir3.1": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/home/test/dir3/dir3.1/file9.mp3": ((33188, 737171L, 774L, 1, 0, 0, 492L, 1061249091, 1018927583, 1034548105), "We finish with file 9"),
        "/home/test/dir3/file8.mp3": ((33060, 737379L, 774L, 1, 1, 1, 111L, 1061249091, 1018928511, 1034548145), "In file 8 there is no data"),
        "/home/test/file1.mp3": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), "Content 1"),
        "/home/test/file2.mp3": ((33270, 1407445L, 774L, 1, 500, 600, 1280L, 1063048300, 1063048300, 1063048300), "Content 1"),
        "/home/test/file3.mp3": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048300, 1063048396), "Content 3"),
        "/home/test/link1.mp3": ((41471, 441542L, 774L, 1, 0, 0, 11L, 1067447134, 1034546253, 1034546253), "home/test/file1.mp3"),
        "/lost": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/lost/file1.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file2.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file3.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/lost/file4.mp3": ((33188, 884738L, 774L, 1, 0, 0, 1463L, 1054331223, 991209287, 1054333751), "More of file 5"),
        "/test": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir/Music": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/test/dir/Pictures": ((16877, 376097L, 774L, 14, 0, 0, 4096L, 1067310151, 1048719055, 1048719055), ),
        "/special": ((16832, 1227166L, 774L, 51, 500, 600, 4096L, 1067342814, 1067336294, 1067336294), ),
        "/special/gpmdata": ((4532, 98121L, 771L, 1, 0, 0, 0L, 1072821519, 1007419555, 1072821519), ),
        "/special/lircd": ((49588, 98936L, 771L, 1, 0, 500, 0L, 1072821521, 992657524, 1072821521), ),
        "/special/hda1": ((25008, 98124L, 771L, 1, 0, 6, 0L, 1072821519, 1018535114, 1072821519), 769),
        "/special/random": ((8612, 99633L, 771L, 1, 0, 0, 0L, 1074206037, 1018535114, 1072821521), 264),

        "/test_backup.0000": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), "Dummy descriptor"),
        "/test_backup.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
F("home/test/dir1/file4.mp3", 0664, 501, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 501, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018920000, 124, "433b7d897d3113a4f05f3ce50ad40000", 1)
"""),
        "/test_backup.0002": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 2, Time = 12345678, Version = 1)
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991200000, 1463, "00000000000000000000000000000000", 1)
F("home/test/dir1/file4.mp3", 0664, 501, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 501, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 2)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 2)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 2)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 2)
#F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)
#F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 0)
F("home/test/file10.mp3", 0770, 500, 600, 1063048300, 1280, "01234567890123456789012345678901", 0)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
"""),
        "/lost_backup": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("lost/file[14].mp3")
"""),
        "/lost_backup.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D("lost", 0700, 500, 600, 1067336294)
F("lost/file1.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
"""),
        "/lost_backup.0003": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 3, Time = 12340000, Version = 1)
D("lost", 0700, 500, 600, 1067336294)
F("lost/file1.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
F("lost/file2.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 2)
F("lost/file3.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
"""),
        "/bad_descriptor.0001": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12340000, Version = 1)
D("lost", 0700, 500, 600, 1067336294)
F("lost/file1.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
F("lost/file2.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
BadLine("This line is bad")
F("lost/file3.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
"""),
        "/empty_file": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
"""),
        "/test_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
MediumSize("650M")
HashFunction("sha1")
BaseDir("/test/dir")
Input("Music")
Input("Pictures")
"""),
        "/absolute_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
MediumSize("650M")
BaseDir("/test/dir")
Input("/home/Music")
"""),
        "/exclude_descriptor": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("home/test")
Exclude("home/test/dir1/*.mp3")
ExcludeRegexp("home/test/dir2/([^/]+/)?[^/]+\\.mp3")
ExcludeRegexp("home/test/dir2/([^/]+/)?[^/]+\\.mp3")
"""),
        "/exclude_descriptor_non_root": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/home")
Input("test")
Exclude("test/dir1/*.mp3")
ExcludeRegexp("test/dir2/([^/]+/)?[^/]+\\.mp3")
"""),
        "/exclude_dir": ((33272, 1407445L, 774L, 1, 500, 600, 1280L, 1063048397, 1063048395, 1063048396), """\
# -*- coding: iso-8859-1 -*-
BaseDir("/")
Input("home/test")
Exclude("home/test/dir1")
""")
}


# Virtual filesystem
class VfsTestCase(unittest.TestCase):
        """Setup test case for our 'virtual' filesystem."""
        def setUp(self):
                self.OldOpen = __builtins__.open
                self.OldStat = os.stat
                self.OldLstat = os.lstat
                self.OldListDir = os.listdir
                self.OldReadLink = os.readlink
                self.OldGetCwd = os.getcwd
                self.OldHash = sync2cd.FileInfo.HashFunction
                __builtins__.open = self.open
                os.stat = self.stat
                os.lstat = self.lstat
                os.listdir = self.listdir
                os.readlink = self.readlink
                self.cwd = "/"
                os.getcwd = self.getcwd
                sync2cd.FileInfo.HashFunction = md5

        def tearDown(self):
                __builtins__.open = self.OldOpen
                os.stat = self.OldStat
                os.lstat = self.OldLstat
                os.listdir = self.OldListDir
                os.readlink = self.OldReadLink
                os.getcwd = self.OldGetCwd
                sync2cd.FileInfo.HashFunction = self.OldHash

        def open(self, Path, Mode):
                Path = os.path.abspath(Path)
                try:
                        return StringIO.StringIO(TestFiles[Path][1])
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def stat(self, Path):
                Path = os.path.abspath(Path)
                try:
                        Data = TestFiles[Path]
                        Mode = Data[0][stat.ST_MODE]
                        RDev = 0
                        if stat.S_ISBLK(Mode) or stat.S_ISCHR(Mode):
                                RDev = Data[1]
                        return os.stat_result(Data[0], {"st_rdev": RDev})

                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def lstat(self, Path):
                Path = os.path.abspath(Path)
                try:
                        Data = TestFiles[Path]
                        Mode = Data[0][stat.ST_MODE]
                        RDev = 0
                        if stat.S_ISBLK(Mode) or stat.S_ISCHR(Mode):
                                RDev = Data[1]
                        return os.stat_result(Data[0], {"st_rdev": RDev})
                        
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"

        def listdir(self, Path):
                Path = os.path.abspath(Path)
                if not Path.endswith("/"):
                        Path += "/"
                Entries = []
                for k in TestFiles.iterkeys():
                        if k.startswith(Path):
                                Name = k[len(Path):]
                                if "/" not in Name:
                                        Entries.append(Name)
                return Entries

        def readlink(self, Path):
                Path = os.path.abspath(Path)
                try:
                        return TestFiles[Path][1]
                except KeyError:
                        raise OSError, "[Errno 2] No such file or directory: '" + Path + "'"
        
        def getcwd(self):
                return self.cwd

                
# DirEntInfo children
class FileInfoTest(VfsTestCase):
        """DirEntInfo child tests."""
        def testDirInfoAttributes(self):
                "Info loading for a directory"
                FileName = "home/test"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.DirInfo))

        def testFileInfoAttributes(self):
                "Creation and attributes of FileInfo"
                FileName = "home/test/file1.mp3"
                Info = sync2cd.LoadDirEntInfo(FileName)

                self.assertEqual(Info.Name, FileName)
                self.assertEqual(Info.Mode, 0770)
                self.assert_(isinstance(Info, sync2cd.FileInfo))
                self.assertEqual(Info.Owner, 500)
                self.assertEqual(Info.Group, 600)
                self.assertEqual(Info.MTime, 1063048395)
                self.assertEqual(Info.Size,  1280)
                m = sync2cd.FileInfo.HashFunction.new(TestFiles[os.path.abspath(FileName)][1])
                self.assertEqual(Info.Hash(), m.hexdigest())

        def testSymLinkInfoAttributes(self):
                "Info loading for a link"
                FileName = "home/test/link1.mp3"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.SymLinkInfo))
                self.assertEqual(Info.Target, "home/test/file1.mp3")

        def testPipeInfoAttributes(self):
                "Info loading for a pipe"
                FileName = "special/gpmdata"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.PipeInfo))

        def testSocketInfoAttributes(self):
                "Info loading for a socket"
                FileName = "special/lircd"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.SocketInfo))

        def testBlockDevInfoAttributes(self):
                "Info loading for a block device"
                FileName = "special/hda1"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.BlockDevInfo))

        def testCharDevInfoAttributes(self):
                "Info loading for a char device"
                FileName = "special/random"
                Info = sync2cd.LoadDirEntInfo(FileName)
                self.assert_(isinstance(Info, sync2cd.CharDevInfo))

        def testDirComparison(self):
                "Comparison between directories"
                Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
                Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048395)
                self.assertEqual(Info1, Info2)

                Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
                Info2 = sync2cd.DirInfo("Dir2", 0771, 500, 600, 1063048395)
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
                Info2 = sync2cd.DirInfo("Dir2", 0770, 501, 600, 1063048395)
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
                Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 601, 1063048395)
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
                Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048396)
                self.assertNotEqual(Info1, Info2)

        def testFileComparison(self):
                "Comparison between files"
                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
                self.assertEqual(Info1, Info2)
                
                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0771, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertNotEqual(Info1, Info2)

        def testFileInfoComparison(self):
                "Comparison between FileInfo instances"
                Info1_1 = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
                Info1_2 = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
                self.assertEqual(Info1_1.Compare(Info1_2), sync2cd.FileInfo.CmpSame)

                Info2 = sync2cd.LoadDirEntInfo("home/test/file2.mp3")
                self.assertEqual(Info1_1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)
                
                Info3 = sync2cd.LoadDirEntInfo("home/test/file3.mp3")
                self.assertEqual(Info1_1.Compare(Info3), sync2cd.FileInfo.CmpChanged)

        def testFileCompare(self):
                "Comparison between files with Compare()"
                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)
                
                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 33273, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpChanged)

                # Don't evaluate MD5 if size and mtime haven't changed
                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)

                Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
                Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "00000000000000000000000000000000")
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpChanged)

        def testLinkComparison(self):
                "Comparison between Links"
                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
                Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target")
                self.assertEqual(Info1, Info2)

                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
                Info2 = sync2cd.SymLinkInfo("Link2", 0771, 500, 600, 1063048395, "Target")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
                Info2 = sync2cd.SymLinkInfo("Link2", 0770, 501, 600, 1063048395, "Target")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
                Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 601, 1063048395, "Target")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
                Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048396, "Target")
                self.assertNotEqual(Info1, Info2)

                Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target1")
                Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target2")
                self.assertNotEqual(Info1, Info2)

        def testDirectFileInfo(self):
                "Direct FileInfo structure"
                FileName = "home/test/file1.mp3"
                Info1 = sync2cd.FileInfo(FileName, 0770, 500, 600, 1063048395, 1280,
                                         sync2cd.FileInfo.HashFunction.new(TestFiles[os.path.abspath(FileName)][1]).hexdigest())
                Info2 = sync2cd.LoadDirEntInfo(FileName)
                self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)

        def testToStr(self):
                "Conversion of DirEntInfo to string"
                Info = sync2cd.LoadDirEntInfo("home/test/dir1")
                Output = str(Info)
                self.assertEqual(Output, 'D("home/test/dir1", 0700, 500, 600, 1067336294)')

                Info = sync2cd.LoadDirEntInfo("home/test/link1.mp3")
                Output = str(Info)
                self.assertEqual(Output, 'L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")')

                Info = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
                Output = str(Info)
                self.assertEqual(Output, 'F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)')

                Info = sync2cd.LoadDirEntInfo("special/gpmdata")
                Output = str(Info)
                self.assertEqual(Output, 'P("special/gpmdata", 0664, 0, 0, 1007419555)')

                Info = sync2cd.LoadDirEntInfo("special/hda1")
                Output = str(Info)
                self.assertEqual(Output, 'B("special/hda1", 0660, 0, 6, 1018535114, 769)')

                Info = sync2cd.LoadDirEntInfo("special/random")
                Output = str(Info)
                self.assertEqual(Output, 'C("special/random", 0644, 0, 0, 1018535114, 264)')

        def testToStrWithQuotes(self):
                "Conversion to string with quotes in filenames"
                Info = sync2cd.SymLinkInfo('home/test/link"with"quotes', 0777, 0, 0, 1034546253, 'home/target"with"quotes')
                Output = str(Info)
                self.assertEqual(Output, 'L("home/test/link\\"with\\"quotes", 0777, 0, 0, 1034546253, "home/target\\"with\\"quotes")')

        def testNonNormalPath(self):
                "Normalization of non-normal path"
                Info = sync2cd.LoadDirEntInfo("home//./test/dir1/../file1.mp3")
                self.assertEqual(Info.Name, "home/test/file1.mp3")


# Filesystem tree
class FsTreeTest(VfsTestCase):
        def testEmptyList(self):
                "Loading an empty list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO("")
                Tree.Parse(Input)
                self.assertEqual(Tree.Dirs, {})
                self.assertEqual(Tree.Files, {})

        def testSingleDir(self):
                "Loading a single-dir list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
D("home/test", 0700, 500, 600, 1067336294)
''')
                Tree.Parse(Input)
                Ent = Tree.Dirs["home/test"]
                self.assertEqual(Ent.Mode, 0700)
                self.assertEqual(Ent.Owner, 500)
                self.assertEqual(Ent.Group, 600)
                self.assertEqual(Ent.MTime, 1067336294)

        def testSingleFile(self):
                "Loading a single-file list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280L, "0123456789012345", 42)
''')
                Tree.Parse(Input)
                Ent = Tree.Files["home/test/file1.mp3"]
                self.assertEqual(Ent.Mode, 0770)
                self.assertEqual(Ent.Owner, 500)
                self.assertEqual(Ent.Group, 600)
                self.assertEqual(Ent.MTime, 1063048395)
                self.assertEqual(Ent.Size, 1280)
                self.assertEqual(Ent.Hash(), "0123456789012345")
                self.assertEqual(Ent.Archive, 42)

        def testSingleLink(self):
                "Loading a single-link list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')
                Tree.Parse(Input)
                Ent = Tree.Others["home/test/link1.mp3"]
                self.assertEqual(Ent.Mode, 0777)
                self.assertEqual(Ent.Owner, 0)
                self.assertEqual(Ent.Group, 0)
                self.assertEqual(Ent.MTime, 1034546253)
                self.assertEqual(Ent.Target, "home/test/file1.mp3")

        def testSinglePipe(self):
                "Loading a single-pipe list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
P("special/gpmdata", 0664, 0, 0, 1007419555)
''')
                Tree.Parse(Input)
                Ent = Tree.Others["special/gpmdata"]
                self.assertEqual(Ent.Mode, 0664)
                self.assertEqual(Ent.Owner, 0)
                self.assertEqual(Ent.Group, 0)
                self.assertEqual(Ent.MTime, 1007419555)

        def testSingleSocket(self):
                "Loading a single-socket list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
S("special/lircd", 0664, 0, 500, 992657524)
''')
                Tree.Parse(Input)
                Ent = Tree.Others["special/lircd"]
                self.assertEqual(Ent.Mode, 0664)
                self.assertEqual(Ent.Owner, 0)
                self.assertEqual(Ent.Group, 500)
                self.assertEqual(Ent.MTime, 992657524)

        def testSingleBlockDev(self):
                "Loading a single-block-device list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
B("special/hda1", 0660, 0, 6, 1018535114, 769)
''')
                Tree.Parse(Input)
                Ent = Tree.Others["special/hda1"]
                self.assertEqual(Ent.Mode, 0660)
                self.assertEqual(Ent.Owner, 0)
                self.assertEqual(Ent.Group, 6)
                self.assertEqual(Ent.MTime, 1018535114)
                self.assertEqual(Ent.RDev, 769)

        def testSingleCharDev(self):
                "Loading a single-char-device list"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
C("special/random", 0644, 0, 0, 1018535114, 264)
''')
                Tree.Parse(Input)
                Ent = Tree.Others["special/random"]
                self.assertEqual(Ent.Mode, 0644)
                self.assertEqual(Ent.Owner, 0)
                self.assertEqual(Ent.Group, 0)
                self.assertEqual(Ent.MTime, 1018535114)
                self.assertEqual(Ent.RDev, 264)

        def testOneOfEach(self):
                "Loading one item of each type"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 3, Time = 12345678, Version = 1)
D("home/test", 0700, 500, 600, 1067336294)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280L, "0123456789012345", 42)
P("special/gpmdata", 0664, 0, 0, 1007419555)
B("special/hda1", 0660, 0, 6, 1018535114, 769)
S("special/lircd", 0664, 0, 500, 992657524)
C("special/random", 0644, 0, 0, 1018535114, 264)
''')
                Tree.Parse(Input)
                self.assertEqual(Tree.Archive, 3)
                self.assertEqual(Tree.Time, 12345678)
                self.assert_("home/test" in Tree.Dirs)
                self.assert_("home/test/file1.mp3" in Tree.Files)
                self.assert_("home/test/link1.mp3" in Tree.Others)
                self.assert_("special/gpmdata" in Tree.Others)
                self.assert_("special/lircd" in Tree.Others)
                self.assert_("special/hda1" in Tree.Others)
                self.assert_("special/random" in Tree.Others)

        def testLinkWithQuotes(self):
                "Loading a link with quotes in the filenames"
                Tree = sync2cd.FsTree()
                Input = StringIO.StringIO('''\
# -*- coding: iso-8859-1 -*-
L("home/link\\"with\\"quotes", 0777, 0, 0, 1034546253, "home/target\\"with\\"quotes")
''')
                Tree.Parse(Input)
                Link = Tree.Others['home/link"with"quotes']
                self.assertEqual(Link.Target, 'home/target"with"quotes')

        def testBadDescriptor(self):
                "Error in descriptor"
                try:
                        Tree = sync2cd.ReadArchiveDescriptor("/bad_descriptor", 1)
                        self.fail()
                except sync2cd.ParseError, e:
                        self.assert_(str(e).startswith("bad_descriptor.0001:6: NameError: "))

        def testDictDiff(self):
                "Dictionary difference"
                Diff = sync2cd.DictDiff({}, {})
                self.assertEqual(Diff, ([], [], []))
                
                Diff = sync2cd.DictDiff({"r": 0}, {})
                self.assertEqual(Diff, ([], [], ["r"]))
                
                Diff = sync2cd.DictDiff({}, {"a": 0})
                self.assertEqual(Diff, (["a"], [], []))

                Diff = sync2cd.DictDiff({"c": 0}, {"c": 1})
                self.assertEqual(Diff, ([], ["c"], []))
                
                Diff = sync2cd.DictDiff({"s": 0}, {"s": 0})
                self.assertEqual(Diff, ([], [], []))

                Diff = sync2cd.DictDiff({"r": 1, "c": 2, "s": 3}, {"a": 0, "c": 4, "s": 3})
                self.assertEqual(Diff, (["a"], ["c"], ["r"]))

        def testTreeDiff(self):
                "Tree difference"
                OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                PhysicalTree = sync2cd.WalkPaths(["home/test"])
                (Dirs, Files, Others) = sync2cd.TreeDiff(OldTree, PhysicalTree)

                self.assertEqual(Dirs, ([], ["home/test/dir2"], []))
                Files[0].sort()
                Files[1].sort()
                Files[2].sort()
                self.assertEqual(Files, (["home/test/file2.mp3",
                                          "home/test/file3.mp3"],
                                         ["home/test/dir1/dir1.1/file5.mp3",
                                          "home/test/dir1/file4.mp3"],
                                         ["home/test/file10.mp3"]))
                self.assertEqual(Others, ([], [], []))

        def testBackupMerge(self):
                "Merge two trees for backup purposes"
                OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                PhysicalTree = sync2cd.WalkPaths(["home/test"])
                NewTree = sync2cd.BackupTreeMerge(OldTree, PhysicalTree, 3, [1, 2])

                Descriptor = NewTree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
# -*- coding: iso-8859-1 -*-
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
F("home/test/dir1/file4.mp3", 0664, 500, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 2)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 2)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 2)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 2)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 3)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 3)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
""")

        def testSizedBackupMerge(self):
                "Merge two trees for backup purposes, with limited medium size"
                OldTree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                PhysicalTree = sync2cd.WalkPaths(["home/test"])
                NewTree = sync2cd.BackupTreeMerge(OldTree, PhysicalTree, 3, [1, 2], 4096)
                TotalSize = 0
                for Item in NewTree.Files.itervalues():
                        if Item.Archive == 3:
                                TotalSize += Item.PaddedSize(sync2cd.BlockSize)

                # Only file5.mp3 and file2.mp3 should be in archive 3
                self.assert_(TotalSize <= 4096)
                self.assert_("home/test/dir1/dir1.1/file5.mp3" in NewTree.Files)
                self.assert_("home/test/file2.mp3" in NewTree.Files)
                self.assert_("home/test/file3.mp3" not in NewTree.Files)

                
# Archive descriptors
class ArchivesDescriptorTest(VfsTestCase):
        def testListArchives(self):
                "Find archive description files"
                Archives = sync2cd.ListArchives("/test_backup")
                self.assertEqual(Archives, [1, 2])

        def testArchiveName(self):
                "Make an archive descriptor file name"
                Name = sync2cd.ArchiveDescriptorName("/test_backup", 123)
                self.assertEqual(Name, "/test_backup.0123")
                
        def testReadArchive(self):
                "Read an archive descriptor"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 1)
                self.assertEqual(len(Tree.Dirs), 4)
                self.assertEqual(len(Tree.Files), 4)
                self.assertEqual(len(Tree.Others), 0)

                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                self.assertEqual(len(Tree.Dirs), 6)
                self.assertEqual(len(Tree.Files), 8)
                self.assertEqual(len(Tree.Others), 1)


# Shell-style pattern to regexp converter
class GlobToRegexpTest(unittest.TestCase):
        def testNoPattern(self):
                "Path containing no pattern"
                Input = "/home/test/a file.mp3"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output, re.escape(Input) + "$")

        def testStarPattern(self):
                "Path containing a star pattern"
                Input = "/home/te*t/my * file.mp*"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[^/]*" + re.escape("t/my ")
                        + "[^/]*" + re.escape(" file.mp") + "[^/]*" + "$")

        def testDoubleStarPattern(self):
                "Path containing a double-star pattern"
                Input = "/home/te**t/my ** file.mp**"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + ".*" + re.escape("t/my ")
                        + ".*" + re.escape(" file.mp") + ".*" + "$")

                self.assertEqual(sync2cd.GlobToRegexp("test*"),
                                 "test[^/]*$")

        def testQuestionPattern(self):
                "Path containing a question-mark pattern"
                Input = "/home/te?t/my ? file.mp?"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[^/]" + re.escape("t/my ")
                        + "[^/]" + re.escape(" file.mp") + "[^/]" + "$")

        def testRangePatterns(self):
                "Path containing a character range pattern"
                Input = "/home/te[a-c]t/my [b-d0-9] file.mp[23]"
                Output = sync2cd.GlobToRegexp(Input)
                self.assertEqual(Output,
                        re.escape("/home/te") + "[a-c]" + re.escape("t/my ")
                        + "[b-d0-9]" + re.escape(" file.mp") + "[23]" + "$")

                self.assertEqual(sync2cd.GlobToRegexp("[!abc]"),
                                 "[^abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[a!bc]"),
                                 "[a!bc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[^abc]"),
                                 "[^abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[]abc]"),
                                 "[]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[!]abc]"),
                                 "[^]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[^]abc]"),
                                 "[^]abc]$")
                self.assertEqual(sync2cd.GlobToRegexp("[abc"),
                                 "\\[abc$")
                self.assertEqual(sync2cd.GlobToRegexp("[ab\\s]"),
                                 "[ab\\\\s]$")

                        
# Filter list
class FilterListTest(unittest.TestCase):
        def testNoPattern(self):
                "Filter list with no pattern"
                Filter = sync2cd.FilterList()
                self.assert_(not Filter.Match("Test pattern"))

        def testOnePattern(self):
                "Filter list with one pattern"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("Test *")
                self.assert_(Filter.Match("Test pattern"))
                self.assert_(not Filter.Match("Other test pattern"))
        
        def testTwoPatterns(self):
                "Filter list with two patterns"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("Test *")
                Filter.AddRegexp(".* test .*")
                self.assert_(Filter.Match("Test pattern"))
                self.assert_(Filter.Match("Other test pattern"))
                self.assert_(not Filter.Match("Not matched"))


# Filesystem walking
class TreeWalkTest(VfsTestCase):
        def testTreeWalk(self):
                "Walk a tree"
                Tree = sync2cd.WalkPaths(["home/test"])
                self.assertEqual(len(Tree.Dirs), 6)
                self.assertEqual(len(Tree.Files), 9)
                self.assertEqual(len(Tree.Others), 1)

        def testDescriptorGeneration(self):
                "Generate a descriptor from a tree"
                Tree = sync2cd.WalkPaths(["home/test"])
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
# -*- coding: iso-8859-1 -*-
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 0)
F("home/test/dir1/file4.mp3", 0664, 500, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 0)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 0)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 0)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 0)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 0)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 0)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
""")

        def testFileWalking(self):
                "Walking files instead of directories"
                Tree = sync2cd.WalkPaths(["home/test/file1.mp3", "home/test/file2.mp3"])
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
# -*- coding: iso-8859-1 -*-
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 0)
""")

        def testExcludedWalking(self):
                "Walk a tree with exclusions"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("home/test/dir[13]/*")
                Filter.AddRegexp("home/(.)es\\1/link.\\.mp[123]")
                Tree = sync2cd.WalkPaths(["home/test"], Filter)
                self.assertEqual(len(Tree.Dirs), 4)
                self.assertEqual(len(Tree.Files), 5)
                self.assertEqual(len(Tree.Others), 0)

        def testSpecialFileWalking(self):
                "Walk a tree with special entities"
                Tree = sync2cd.WalkPaths(["special"])
                self.assertEqual(len(Tree.Dirs), 1)
                self.assertEqual(len(Tree.Files), 0)
                self.assertEqual(len(Tree.Others), 4)
                Descriptor = Tree.MakeDescriptor()
                self.assertEqual(Descriptor, """\
# -*- coding: iso-8859-1 -*-
D("special", 0700, 500, 600, 1067336294)
P("special/gpmdata", 0664, 0, 0, 1007419555)
B("special/hda1", 0660, 0, 6, 1018535114, 769)
S("special/lircd", 0664, 0, 500, 992657524)
C("special/random", 0644, 0, 0, 1018535114, 264)
""")


# Descriptor creation
def mytime():
        return 12345678

class CreationTest(VfsTestCase):
        def setUp(self):
                VfsTestCase.setUp(self)
                self.OldTime = time.time
                time.time = mytime

        def tearDown(self):
                VfsTestCase.tearDown(self)
                time.time = self.OldTime
        
        def testCreation(self):
                "Archive descriptor creation"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None)

                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
F("home/test/dir1/file4.mp3", 0664, 500, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 2)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 2)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 2)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 2)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 3)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 3)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')
                
        def testBigEnoughSizedCreation(self):
                "Sized archive descriptor creation, with enough room on the medium"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None, 10000)

                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
F("home/test/dir1/file4.mp3", 0664, 500, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 2)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 2)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 2)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 2)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 3)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 3)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')

        def testSizedCreation(self):
                "Sized archive descriptor creation, with truncation"
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/test_backup", ["home/test"], None, 2048)

                # Only file5.mp3 should be in archive 3
                self.assertEqual(Archive, 3)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 3, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
F("home/test/dir1/file4.mp3", 0664, 500, 505, 1056059953, 542594, "22216af3e014b443aab3c68fde453d68", 1)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 2)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 2)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 2)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 2)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')

        def testMissingDescriptor(self):
                "Creation of an archive with one descriptor missing"
                Archives = sync2cd.ListArchives("/lost_backup")
                self.assertEqual(Archives, [1, 3])

                (Archive, Descriptor) = sync2cd.CreateDescriptor("/lost_backup", ["lost"], None)

                self.assertEqual(Archive, 4)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 4, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("lost", 0700, 500, 600, 1067336294)
F("lost/file1.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
F("lost/file2.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 4)
F("lost/file3.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 3)
F("lost/file4.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 4)
''')

        def testExcludes(self):
                "Config file with exclude patterns"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_descriptor"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_descriptor", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir1", 0700, 500, 600, 1067336294)
D("home/test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("home/test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
D("home/test/dir2", 0700, 500, 600, 1067336294)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 1)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 1)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 1)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')

        def testExcludesNonRoot(self):
                "Config file with exclude patterns and non-root base"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_descriptor_non_root"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_descriptor_non_root", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("test", 0700, 500, 600, 1067336294)
D("test/dir1", 0700, 500, 600, 1067336294)
D("test/dir1/dir1.1", 0700, 500, 600, 1067336294)
F("test/dir1/dir1.1/file5.mp3", 0644, 0, 0, 991209287, 1463, "f6ced8d61e9545503165d9233eb68db3", 1)
D("test/dir2", 0700, 500, 600, 1067336294)
D("test/dir3", 0700, 500, 600, 1067336294)
D("test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 1)
F("test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 1)
F("test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 1)
L("test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')

        def testExcludeDir(self):
                "Config file with exclude patterns matching a directory"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/exclude_dir"])
                self.cwd = Config.BaseDir
                (Archive, Descriptor) = sync2cd.CreateDescriptor("/exclude_dir", Config.Inputs, Config.Filter, 0)
                self.assertEqual(Archive, 1)
                self.assertEqual(Descriptor, '''\
# -*- coding: iso-8859-1 -*-
Sync2cd(Archive = 1, Time = 12345678, Version = ''' + str(sync2cd.DescriptorFormatVersion) + ''') # 1970.05.23 21:21:18 UTC
D("home/test", 0700, 500, 600, 1067336294)
D("home/test/dir2", 0700, 500, 600, 1067336294)
F("home/test/dir2/file6.mp3", 0600, 500, 12, 1021222945, 0, "c69f52e90182b1188582799b9ab95195", 1)
F("home/test/dir2/file7.mp3", 0444, 1, 1, 1018928518, 124, "433b7d897d3113a4f05f3ce50ad40faa", 1)
D("home/test/dir3", 0700, 500, 600, 1067336294)
D("home/test/dir3/dir3.1", 0700, 500, 600, 1067336294)
F("home/test/dir3/dir3.1/file9.mp3", 0644, 0, 0, 1018927583, 492, "b514a213066bbd126c9c6f51fc2f852f", 1)
F("home/test/dir3/file8.mp3", 0444, 1, 1, 1018928511, 111, "af4b9fc3b9cb11019293c3a697368e5d", 1)
F("home/test/file1.mp3", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("home/test/file2.mp3", 0766, 500, 600, 1063048300, 1280, "81d6a1501eaff685ab50c7ff7d29d396", 1)
F("home/test/file3.mp3", 0770, 500, 600, 1063048300, 1280, "e514979236a3b13cd9a4e81c43595f04", 1)
L("home/test/link1.mp3", 0777, 0, 0, 1034546253, "home/test/file1.mp3")
''')


# Status printing
class StatusTest(VfsTestCase):
        def testHumanReadable(self):
                "Conversion of a size to a human-readable format"
                self.assertEqual(sync2cd.HumanReadable(0), "0")
                self.assertEqual(sync2cd.HumanReadable(1023), "1023")
                self.assertEqual(sync2cd.HumanReadable(1024), "1.0k")
                self.assertEqual(sync2cd.HumanReadable(5678), "5.5k")
                self.assertEqual(sync2cd.HumanReadable(10230), "9.9k")
                self.assertEqual(sync2cd.HumanReadable(10240), "10k")
                self.assertEqual(sync2cd.HumanReadable(23456), "22k")
                self.assertEqual(sync2cd.HumanReadable(1048575), "1023k")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024), "1.0M")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024), "1.0G")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024), "1.0T")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024 * 1024), "1.0P")
                self.assertEqual(sync2cd.HumanReadable(1024 * 1024 * 1024 * 1024 * 1024 * 1024), "1.0E")
                
        def testArchiveStatus(self):
                "Print status for a specific archive"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                Status = Tree.CreateStatus(2, 0)
                self.assertEqual(Status, '''\
Archive: 2
Created: 23.05.1970, 21:21:18 UTC (12345678)
Version: 1
Size:    1.9k (2007 bytes)
Padded:  8.0k (8192 bytes)
''')

        def testArchiveStatusContent(self):
                "Print status for a specific archive with archive content"
                Tree = sync2cd.ReadArchiveDescriptor("/test_backup", 2)
                Status = Tree.CreateStatus(2, 1)
                self.assertEqual(Status, '''\
Archive: 2
Created: 23.05.1970, 21:21:18 UTC (12345678)
Version: 1
Size:    1.9k (2007 bytes)
Padded:  8.0k (8192 bytes)
Content:
home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3
home/test/file1.mp3
''')

        def testTreeStatus(self):
                "Print status of current tree"
                Status = sync2cd.CreateSyncStatus("/test_backup", ["home/test"], None, 1)
                self.assertEqual(Status, '''\
Size:    3.9k (4023 bytes)
Padded:  6.0k (6144 bytes)
Content:
home/test/dir1/dir1.1/file5.mp3
home/test/file2.mp3
home/test/file3.mp3
''')

        def testFilteredTreeStatus(self):
                "Print status of current tree with filter"
                Filter = sync2cd.FilterList()
                Filter.AddGlob("home/test/dir1/*/*.mp3")
                Status = sync2cd.CreateSyncStatus("/test_backup", ["home/test"], Filter, 1)
                self.assertEqual(Status, '''\
Size:    2.5k (2560 bytes)
Padded:  4.0k (4096 bytes)
Content:
home/test/file2.mp3
home/test/file3.mp3
''')


# Graft list printing
class GraftListTest(VfsTestCase):
        def testGraftPoint(self):
                "Escaping of graft point entries"
                self.assertEqual(sync2cd.GraftEscape("home/test/file1.mp3"), "home/test/file1.mp3")
                self.assertEqual(sync2cd.GraftEscape("with=equal.mp3"), "with\\=equal.mp3")
                self.assertEqual(sync2cd.GraftEscape("with\\backslash.mp3"), "with\\\\backslash.mp3")
                
        def testGraftList(self):
                "Generate a graft list"
                BurnList = sync2cd.CreateGraftList("/test_backup", 2, "/usr/local/bin/sync2cd.py")
                self.assertEqual(BurnList, '''\
.sync2cd/sync2cd.py=/usr/local/bin/sync2cd.py
.sync2cd/test_backup=/test_backup
.sync2cd/test_backup.0002=/test_backup.0002
home/test/dir2/file7.mp3=/home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3=/home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3=/home/test/dir3/file8.mp3
home/test/file1.mp3=/home/test/file1.mp3
''')

        def testNonRootGraftList(self):
                "Generate a graft list when not in root directory"
                self.cwd = "/prefix"
                BurnList = sync2cd.CreateGraftList("/test_backup", 2, "/usr/local/bin/sync2cd.py")
                self.assertEqual(BurnList, '''\
.sync2cd/sync2cd.py=/usr/local/bin/sync2cd.py
.sync2cd/test_backup=/test_backup
.sync2cd/test_backup.0002=/test_backup.0002
home/test/dir2/file7.mp3=/prefix/home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3=/prefix/home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3=/prefix/home/test/dir3/file8.mp3
home/test/file1.mp3=/prefix/home/test/file1.mp3
''')


# Configuration parsing
class ConfigParserTest(VfsTestCase):
        def testCommandLineArgs(self):
                "Command line arguments"
                Args = ["sync2cd.py",
                        "--archive", "1",
                        "--create",
                        "--graft-list",
                        "--medium-size", "10M",
                        "--print",
                        "--status",
                        "--verbose",
                        "-v",
                        "/empty_file"]
                Config = sync2cd.ConfigParser(Args)
                self.assertEqual(Config.Archive, 1)
                self.assert_(Config.Create)
                self.assert_(Config.GraftList)
                self.assert_(not Config.Help)
                self.assertEqual(Config.MediumSize, 10 * 1024 * 1024)
                self.assert_(Config.Print)
                self.assert_(Config.Status)
                self.assertEqual(Config.Verbose, 2)
                self.assertEqual(Config.ScriptPath, "/sync2cd.py")
                
        def testCommandLineHelp(self):
                "Command line arguments with help and no config file"
                Args = ["sync2cd.py", "--help"]
                Config = sync2cd.ConfigParser(Args)
                self.assert_(Config.Help)

        def testTooManyConfigFiles(self):
                "More than one config file"
                Args = ["sync2cd.py", "/empty_file", "/test_descriptor"]
                self.assertRaises(sync2cd.Error, sync2cd.ConfigParser, Args)

        def testParsing(self):
                "Parsing of a config file"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/test_descriptor"])
                self.assertEqual(Config.MediumSize, 650 * 1024 * 1024)
                self.assertEqual(sync2cd.FileInfo.HashFunction, sync2cd.sha)
                self.assertEqual(Config.BaseDir, "/test/dir")
                self.assertEqual(len(Config.Inputs), 2)
                self.assertEqual(Config.Inputs[0], "Music")
                self.assertEqual(Config.Inputs[1], "Pictures")

        def testMediumSizeOverride(self):
                "Overriding of medium size on command line"
                Config = sync2cd.ConfigParser(["sync2cd.py", "--medium-size", "700M", "/test_descriptor"])
                self.assertEqual(Config.MediumSize, 700 * 1024 * 1024)

        def testAbsoluteInput(self):
                "Config file with absolute input specification"
                try:
                        Config = sync2cd.ConfigParser(["sync2cd.py", "/absolute_descriptor"])
                        self.fail()
                except sync2cd.ParseError, e:
                        self.assert_(str(e).startswith("absolute_descriptor:4: ParseError: "))

        def testGlobInput(self):
                "Input specification with wildcards"
                Config = sync2cd.ConfigParser(["sync2cd.py", "/lost_backup"])
                self.assertEqual(Config.BaseDir, "/")
                self.assertEqual(len(Config.Inputs), 2)
                self.assertEqual(Config.Inputs[0], "lost/file1.mp3")
                self.assertEqual(Config.Inputs[1], "lost/file4.mp3")

                
# Main entry point
if __name__ == "__main__":
        unittest.main()
