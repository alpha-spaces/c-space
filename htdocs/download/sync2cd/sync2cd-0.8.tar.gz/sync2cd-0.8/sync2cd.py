#!/usr/bin/env python
"""\
sync2cd.py   Incremental archiving tool to CD/DVD
Copyright (C) 2004  Remy Blank

This file is part of sync2cd.

sync2cd is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

sync2cd is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with sync2cd; if not, write to the Free Software Foundation,
Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
"""

# Module imports
import sys
import os
import stat
import glob
import re
import md5
import sha
import time
import getopt
import traceback

# Constants
ProgramName = "sync2cd.py"
ProgramVersion = "0.8"
Author = "Remy Blank"
CopyrightYear = "2004"
DescriptorFormatVersion = 3
SuffixSize = 4
BlockSize = 2048
DescriptorDir = ".sync2cd"
HashFunctions = {
        "md5": md5,
        "sha": sha,
        "sha1": sha
}


# Generic exception
class Error(Exception): pass
                

# Python script parser
class ParseError(Exception): pass

class ScriptParser(object):
        "Python script parser."
        def __init__(self):
                self.Globals = {}

        def AddGlobal(self, **kwargs):
                """Add symbols to globals."""
                self.Globals.update(kwargs)

        def Parse(self, Input):
                """Parse python script input."""
                if type(Input) not in (str, file, type(self.Parse.func_code)):
                        Input = Input.read()
                try:
                        exec Input in self.Globals
                except:
                        (Type, Value, Traceback) = sys.exc_info()
                        Traceback = Traceback.tb_next
                        ExcText =   str(traceback.tb_lineno(Traceback)) + ": "                  \
                                  + "".join(traceback.format_exception_only(Type, Value))
                        del Traceback
                        raise ParseError, ExcText[:-1]


# Helpers
def QuoteString(s):
        """Quote all occurences of double quotes in a string."""
        return s.replace('"', '\\"')


def HumanReadable(Value, Kilo = 1024):
        """Convert a value to a human-readable format."""
        def ToDec(Value, Exp):
                if Value < 10 * Exp:
                        (Div, Mod) = divmod(Value, Exp)
                        return "%d.%d" % (Div, (Mod * 10) / Exp)
                else:
                        return "%d" % (Value / Exp)
        
        if Value < Kilo:
                return str(Value)
        if Value < Kilo * Kilo:
                return ToDec(Value, Kilo) + "k"
        if Value < Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo) + "M"
        if Value < Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo) + "G"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo) + "T"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo) + "P"
        if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
                return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo * Kilo) + "E"

                
# Directory entries
class DirEntInfo(object):
        """Directory entry information holder."""
        def __init__(self, Name, Mode, Owner, Group, MTime):
                self.Name = os.path.normpath(Name)
                self.SetStat(Mode, Owner, Group, MTime)

        def SetStat(self, Mode, Owner, Group, MTime):
                self.Mode = stat.S_IMODE(Mode)
                self.Owner = Owner
                self.Group = Group
                self.MTime = MTime

        def __eq__(self, Other):
                return    (self.Mode, self.Owner, self.Group, self.MTime)       \
                       == (Other.Mode, Other.Owner, Other.Group, Other.MTime)
                       
        def __ne__(self, Other):
                return not self.__eq__(Other)

        def __str__(self):
                Args = ['"' + QuoteString(self.Name) + '"']
                StrArgs = self.GetStrArgs()
                Args.extend(StrArgs[1:])
                return StrArgs[0] + "(" + ", ".join([str(x) for x in Args]) + ")"


class DirInfo(DirEntInfo):
        """Directory information holder."""
        def GetStrArgs(self):
                return ("D", oct(self.Mode), self.Owner, self.Group, self.MTime)


class FileInfo(DirEntInfo):
        """File information holder."""
        CmpSame = 0
        CmpStatChanged = 1
        CmpChanged = 2

        HashFunction = md5

        def __init__(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive = 0):
                super(FileInfo, self).__init__(Name, Mode, Owner, Group, MTime)
                self.Size = Size
                self._Hash = Hash
                self.Archive = Archive

        def PaddedSize(self, BlockSize):
                return (self.Size + (BlockSize - 1)) & ~(BlockSize - 1)
                
        def Hash(self):
                return self._Hash

        def SetHash(self, Hash):
                if Hash and (len(Hash) != 2 * FileInfo.HashFunction.digest_size):
                        raise Error, "Hash function mismatch"
                self._Hash = Hash

        def __eq__(self, Other):
                return super(FileInfo, self).__eq__(Other) and (self.Size == Other.Size)
                
        def Compare(self, Other):
                if self.Size != Other.Size:
                        return FileInfo.CmpChanged
                if self.MTime != Other.MTime:
                        if self.Hash() != Other.Hash():
                                return FileInfo.CmpChanged
                        return FileInfo.CmpStatChanged
                if (self.Mode, self.Owner, self.Group) == (Other.Mode, Other.Owner, Other.Group):
                        return FileInfo.CmpSame
                return FileInfo.CmpStatChanged

        def GetStrArgs(self):
                return ("F", oct(self.Mode), self.Owner, self.Group, self.MTime,
                        self.Size, '"' + self.Hash() + '"', self.Archive)

                
class LoadedFileInfo(FileInfo):
        """File info holder, with lazy MD5 evaluation."""
        def __init__(self, Name, Mode, Owner, Group, MTime, Size):
                super(LoadedFileInfo, self).__init__(Name, Mode, Owner, Group, MTime, Size, "")

        def Hash(self):
                if not self._Hash:
                        m = FileInfo.HashFunction.new()
                        File = open(self.Name, "r")
                        try:
                                while 1:
                                        Data = File.read(64 * 1024)
                                        if not Data:
                                                break
                                        m.update(Data)
                        finally:
                                File.close()
                        self._Hash = m.hexdigest()
                return super(LoadedFileInfo, self).Hash()

                
class SymLinkInfo(DirEntInfo):
        """Symbolic link information holder."""
        def __init__(self, Name, Mode, Owner, Group, MTime, Target):
                super(SymLinkInfo, self).__init__(Name, Mode, Owner, Group, MTime)
                self.Target = Target

        def __eq__(self, Other):
                return super(SymLinkInfo, self).__eq__(Other) and (self.Target == Other.Target)

        def GetStrArgs(self):
                return ("L", oct(self.Mode), self.Owner, self.Group, self.MTime,
                        '"' + QuoteString(self.Target) + '"')


class PipeInfo(DirEntInfo):
        """Named pipe information holder."""
        def GetStrArgs(self):
                return ("P", oct(self.Mode), self.Owner, self.Group, self.MTime)
        
        
class SocketInfo(DirEntInfo):
        """Socket information holder."""
        def GetStrArgs(self):
                return ("S", oct(self.Mode), self.Owner, self.Group, self.MTime)


class DevInfo(DirEntInfo):
        """Device information holder."""
        def __init__(self, Name, Mode, Owner, Group, MTime, RDev):
                super(DevInfo, self).__init__(Name, Mode, Owner, Group, MTime)
                self.RDev = RDev

        def __eq__(self, Other):
                return super(DevInfo, self).__eq__(Other) and (self.RDev == Other.RDev)


class BlockDevInfo(DevInfo):
        """Block device information holder."""
        def GetStrArgs(self):
                return ("B", oct(self.Mode), self.Owner, self.Group, self.MTime, self.RDev)


class CharDevInfo(DevInfo):
        """Char device information holder."""
        def GetStrArgs(self):
                return ("C", oct(self.Mode), self.Owner, self.Group, self.MTime, self.RDev)


def LoadDirEntInfo(Name):
        """Create a DirEntInfo child and populate with info loaded from filesystem."""
        Name = os.path.normpath(Name)
        Stat = os.lstat(Name)
        Mode = Stat[stat.ST_MODE]
        if stat.S_ISDIR(Mode):
                return DirInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                               Stat[stat.ST_MTIME])
        elif stat.S_ISREG(Mode):
                return LoadedFileInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                      Stat[stat.ST_MTIME], Stat[stat.ST_SIZE])
        elif stat.S_ISLNK(Mode):
                return SymLinkInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                   Stat[stat.ST_MTIME], os.readlink(Name))
        elif stat.S_ISFIFO(Mode):
                return PipeInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                Stat[stat.ST_MTIME])
        elif stat.S_ISSOCK(Mode):
                return SocketInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                  Stat[stat.ST_MTIME])
        elif stat.S_ISBLK(Mode):
                return BlockDevInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                    Stat[stat.ST_MTIME], Stat.st_rdev)
        elif stat.S_ISCHR(Mode):
                return CharDevInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
                                   Stat[stat.ST_MTIME], Stat.st_rdev)
        print >> sys.stderr, "Omitting " + Name
        return None


# Filesystem tree
class FsTree(ScriptParser):
        """Filesystem tree container."""
        def __init__(self, Other = None):
                super(FsTree, self).__init__()
                self.AddGlobal(Sync2cd = self.Sync2cd,
                               D = self.Dir,
                               F = self.File,
                               L = self.SymLink,
                               P = self.Pipe,
                               S = self.Socket,
                               B = self.BlockDev,
                               C = self.CharDev)
                
                if Other is not None:
                        self.Archive = Other.Archive
                        self.Time = Other.Time
                        self.Version = Other.Version
                        self.Dirs = Other.Dirs.copy()
                        self.Files = Other.Files.copy()
                        self.Others = Other.Others.copy()
                else:
                        self.Archive = 0
                        self.Time = 0
                        self.Version = 0
                        self.Dirs = {}
                        self.Files = {}
                        self.Others = {}

        def SetMeta(self, Archive, Time = None):
                self.Archive = Archive
                if Time:
                        self.Time = int(Time)
                else:
                        self.Time = int(time.time())

        def TimeStr(self):
                return time.strftime("%Y.%m.%d %H:%M:%S UTC", time.gmtime(self.Time))
                
        def Add(self, Entry):
                if isinstance(Entry, DirInfo):
                        self.Dirs[Entry.Name] = Entry
                elif isinstance(Entry, FileInfo):
                        self.Files[Entry.Name] = Entry
                else:
                        self.Others[Entry.Name] = Entry

        def Sync2cd(self, Archive, Time, Version):
                self.Archive = Archive
                self.Time = int(Time)
                self.Version = Version
                if Version > DescriptorFormatVersion:
                        print >> sys.stderr, "Warning: descriptor format version higher than current"

        def Dir(self, Name, Mode, Owner, Group, MTime):
                Mode = stat.S_IMODE(Mode) | stat.S_IFDIR
                self.Dirs[Name] = DirInfo(Name, Mode, Owner, Group, MTime)

        def File(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive):
                Mode = stat.S_IMODE(Mode) | stat.S_IFREG
                self.Files[Name] = FileInfo(Name, Mode, Owner, Group, MTime, Size, Hash, Archive)

        def SymLink(self, Name, Mode, Owner, Group, MTime, Target):
                Mode = stat.S_IMODE(Mode) | stat.S_IFLNK
                self.Others[Name] = SymLinkInfo(Name, Mode, Owner, Group, MTime, Target)

        def Pipe(self, Name, Mode, Owner, Group, MTime):
                Mode = stat.S_IMODE(Mode) | stat.S_IFIFO
                self.Others[Name] = PipeInfo(Name, Mode, Owner, Group, MTime)

        def Socket(self, Name, Mode, Owner, Group, MTime):
                Mode = stat.S_IMODE(Mode) | stat.S_IFSOCK
                self.Others[Name] = SocketInfo(Name, Mode, Owner, Group, MTime)

        def BlockDev(self, Name, Mode, Owner, Group, MTime, RDev):
                Mode = stat.S_IMODE(Mode) | stat.S_IFBLK
                self.Others[Name] = BlockDevInfo(Name, Mode, Owner, Group, MTime, RDev)

        def CharDev(self, Name, Mode, Owner, Group, MTime, RDev):
                Mode = stat.S_IMODE(Mode) | stat.S_IFCHR
                self.Others[Name] = CharDevInfo(Name, Mode, Owner, Group, MTime, RDev)

        def MakeDescriptor(self):
                Meta = "# -*- coding: iso-8859-1 -*-\n"
                if self.Archive != 0:
                        Meta +=   'Sync2cd(Archive = ' + str(self.Archive)      \
                                + ', Time = ' + str(self.Time)                  \
                                + ', Version = ' + str(DescriptorFormatVersion) \
                                + ') # ' + self.TimeStr() + '\n'
                Items = self.Dirs.copy()
                Items.update(self.Files)
                Items.update(self.Others)
                Names = Items.keys()
                Names.sort()
                Lines = [str(Items[Name]) for Name in Names]
                return Meta + "\n".join(Lines) + "\n"

        def CreateStatus(self, Archive, ShowContent):
                TotalSize = 0
                PaddedSize = 0
                Content = []
                for Item in self.Files.itervalues():
                        if Item.Archive != Archive:
                                continue
                        TotalSize += Item.Size
                        PaddedSize += Item.PaddedSize(BlockSize)
                        Content.append(Item.Name)

                Output = []
                if self.Archive != 0:
                        Output.append("Archive: %d" % self.Archive)
                if self.Time:
                        Output.append("Created: %s (%d)" % (time.strftime("%d.%m.%Y, %H:%M:%S UTC", time.gmtime(self.Time)),
                                                            self.Time))
                if self.Version:
                        Output.append("Version: %d" % self.Version)
                Output.append("Size:    %s (%d bytes)" % (HumanReadable(TotalSize), TotalSize))
                Output.append("Padded:  %s (%d bytes)" % (HumanReadable(PaddedSize), PaddedSize))
                if ShowContent:
                        Output.append("Content:")
                        Content.sort()
                        Output.extend(Content)
                return "\n".join(Output) + "\n"
        

def DictDiff(From, To):
        """Compute the difference between two dictionaries."""
        Added = To.copy()
        Changed = []
        Removed = From.copy()

        for (k, v) in From.iteritems():
                if k not in To:
                        continue
                del Added[k]
                del Removed[k]
                if v != To[k]:
                        Changed.append(k)
                        
        return ([Item for Item in Added.iterkeys()],
                Changed,
                [Item for Item in Removed.iterkeys()])
        

def TreeDiff(OldTree, NewTree):
        """Compute the difference between two trees."""
        Dirs = DictDiff(OldTree.Dirs, NewTree.Dirs)
        Files = DictDiff(OldTree.Files, NewTree.Files)
        Others = DictDiff(OldTree.Others, NewTree.Others)
        return (Dirs, Files, Others)

        
def BackupTreeMerge(OldTree, PhysTree, NewArchiveNum, ExistingArchives, MaxTotalSize = 0):
        """Merge two trees for backup purposes"""
        NewTree = FsTree(PhysTree)
        FileDiff = DictDiff(OldTree.Files, PhysTree.Files)

        # Tag added files
        Stored = FileDiff[0]
        for Name in FileDiff[0]:
                NewTree.Files[Name].Archive = NewArchiveNum

        # Tag changed files
        for Name in FileDiff[1]:
                OldItem = OldTree.Files[Name]
                NewItem = NewTree.Files[Name]

                Cmp = NewItem.Compare(OldItem)
                if Cmp == FileInfo.CmpChanged:
                        Stored.append(Name)
                        NewTree.Files[Name].Archive = NewArchiveNum

        # Copy existing info from old tree, provided archive still exists
        ArchiveDict = {}
        for n in ExistingArchives:
                ArchiveDict[n] = 1
        
        for (k, Item) in NewTree.Files.iteritems():
                if Item.Archive != 0:
                        continue
                OldItem = OldTree.Files[k]
                if OldItem.Archive in ArchiveDict:
                        Item.SetHash(OldItem.Hash())
                        Item.Archive = OldItem.Archive
                else:
                        Stored.append(Item.Name)
                        Item.Archive = NewArchiveNum

        # Limit total size to specified value
        if MaxTotalSize > 0:
                # Keep only oldest entries
                List = [(NewTree.Files[k].MTime, NewTree.Files[k].Name, NewTree.Files[k]) for k in Stored]
                List.sort()
                CurSize = 0
                for i in range(len(List)):
                        Item = List[i][2]
                        CurSize += Item.PaddedSize(BlockSize)
                        if CurSize > MaxTotalSize:
                                if i == 0:
                                        raise Error, "Not enough room on medium for first file"
                                for (MTime, Name, Item) in List[i:]:
                                        del NewTree.Files[Item.Name]
                                break
                        Item.SetHash("")
                        Item.Archive = NewArchiveNum
                
        return NewTree
        

# Archive descriptor
def ListArchives(DescriptorBase):
        """Return the list of available archive descriptors."""
        Files = glob.glob(DescriptorBase + "." + SuffixSize * "[0-9]")
        Archives = [int(File[-SuffixSize:]) for File in Files]
        Archives.sort()
        if Archives and Archives[0] == 0:
                del Archives[0]
        return Archives


def ArchiveDescriptorName(DescriptorBase, ArchiveNum):
        """Generate the name of an archive descriptor from the base name and the archive number."""
        Suffix = ".%0*d" % (SuffixSize, ArchiveNum)
        return DescriptorBase + Suffix
        
        
def ReadArchiveDescriptor(DescriptorBase, ArchiveNum):
        """Read a complete archive descriptor."""
        Tree = FsTree()
        FileName = ArchiveDescriptorName(DescriptorBase, ArchiveNum)
        Input = open(FileName, "r")
        try:
                try:
                        Tree.Parse(Input)
                except ParseError, e:
                        raise ParseError, os.path.basename(FileName) + ":" + str(e)
                return Tree
        finally:
                Input.close()
        

# Filesystem walking
def WalkPath(Path, Tree, Filter = None):
        """Walk the filesystem and add entries to an FsTree."""
        def ProcessEntry((Tree, Filter), DirName, Names):
                ProcNames = []
                for i in range(len(Names)):
                        Entry = Names[i]
                        EntryName = os.path.join(DirName, Entry)
                        if Filter is not None and Filter.Match(EntryName):
                                continue
                        ProcNames.append(Entry)
                        Item = LoadDirEntInfo(EntryName)
                        if Item is not None:
                                Tree.Add(Item)
                Names[:] = ProcNames

        if Filter is not None and Filter.Match(Path):
                return
        TopEntry = LoadDirEntInfo(Path)
        if TopEntry is None:
                return
        Tree.Add(TopEntry)
        os.path.walk(Path, ProcessEntry, (Tree, Filter))


def WalkPaths(Paths, Filter = None):
        """Construct an FsTree by walking multiple paths of the filesystem."""
        Tree = FsTree()
        for Path in Paths:
                WalkPath(Path, Tree, Filter)
        return Tree


# Descriptor creation
def CreateDescriptor(DescriptorBase, Paths, Filter, MaxTotalSize = 0):
        """Produce a new backup archive descriptor."""
        Archives = ListArchives(DescriptorBase)
        if not Archives:
                Archive = 1
                OldTree = FsTree()
        else:
                Archive = Archives[-1] + 1
                OldTree = ReadArchiveDescriptor(DescriptorBase, Archive - 1)

        PhysicalTree = WalkPaths(Paths, Filter)
        NewTree = BackupTreeMerge(OldTree, PhysicalTree, Archive, Archives, MaxTotalSize)
        NewTree.SetMeta(Archive)
        Descriptor = NewTree.MakeDescriptor()
        return (Archive, Descriptor)                


# Status creation
def CreateStatus(DescriptorBase, Archive, ShowContent):
        """Produce a status output for a specific archive."""
        Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
        Status = Tree.CreateStatus(Archive, ShowContent)
        return Status
        

def CreateSyncStatus(DescriptorBase, Paths, Filter, ShowContent):
        """Produce a synchronization status ouptut of the current state of the filesystem."""
        Archives = ListArchives(DescriptorBase)
        if not Archives:
                OldTree = FsTree()
        else:
                OldTree = ReadArchiveDescriptor(DescriptorBase, Archives[-1])

        PhysicalTree = WalkPaths(Paths, Filter)
        NewTree = BackupTreeMerge(OldTree, PhysicalTree, -1, Archives)
        Status = NewTree.CreateStatus(-1, ShowContent)
        return Status
        

# Graft list creation
def GraftEscape(s):
        """Escape a file name to be used as a graft point."""
        s = s.replace("\\", "\\\\")
        s = s.replace("=", "\\=")
        return s


def GraftEntry(Src, Dst):
        """Generate a graft list entry."""
        while Dst.startswith("/"):
                Dst = Dst[1:]
        return GraftEscape(Dst) + "=" + GraftEscape(Src)

                
def CreateGraftList(DescriptorBase, Archive, ScriptPath):
        """Produce a graft list that can be fed to mkisofs."""
        DescName = ArchiveDescriptorName(DescriptorBase, Archive)
        Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
        Content = []
        for Item in Tree.Files.itervalues():
                if Item.Archive != Archive:
                        continue
                Content.append(GraftEntry(os.path.abspath(Item.Name), Item.Name))
        Content.sort()
        Content.insert(0, GraftEntry(ScriptPath, os.path.join(DescriptorDir, os.path.basename(ScriptPath))))
        Content.insert(1, GraftEntry(DescriptorBase, os.path.join(DescriptorDir, os.path.basename(DescriptorBase))))
        Content.insert(2, GraftEntry(DescName, os.path.join(DescriptorDir, os.path.basename(DescName))))
        return "\n".join(Content) + "\n"


# Shell-style pattern to regexp converter
def GlobToRegexp(ShellPattern):
        """Convert a shell-style pattern to a regexp."""
        Result = ""
        i = 0
        n = len(ShellPattern)
        while i < n:
                c = ShellPattern[i]
                i += 1
                if c == "*":
                        if i < n and ShellPattern[i] == "*":
                                Result += ".*"
                                i += 1
                        else:
                                Result += "[^/]*"
                elif c == "?":
                        Result += "[^/]"
                elif c == "[":
                        j = i
                        if ShellPattern[j] == "!" or ShellPattern[j] == "^":
                                j += 1
                        if ShellPattern[j] == "]":
                                j += 1
                        while j < n and ShellPattern[j] != "]":
                                j += 1
                        if j >= n:
                                Result += "\\["
                        else:
                                Chars = ShellPattern[i:j].replace("\\", "\\\\")
                                i = j + 1
                                if Chars[0] == "!":
                                        Chars = "^" + Chars[1:]
                                Result += "[%s]" % Chars
                else:
                        Result += re.escape(c)
        return Result + "$"


# Filter list manager
class FilterList:
        "Filter list."
        def __init__(self):
                self.Patterns = []
                
        def AddGlob(self, Pattern):
                self.Patterns.append(re.compile(GlobToRegexp(Pattern)))

        def AddRegexp(self, Pattern):
                self.Patterns.append(re.compile(Pattern))

        def Match(self, Path):
                for Pattern in self.Patterns:
                        if Pattern.match(Path):
                                return 1
                return 0
                        
        
# Configuration parser
class ConfigParser(ScriptParser):
        "Configuration parser."
        Archive = 0
        Create = 0
        GraftList = 0
        Help = 0
        MediumSize = 0
        Print = 0
        Status = 0
        Verbose = 0
        Descriptor = ""

        BaseDir = ""
        ScriptPath = ""

        def __init__(self, Argv):
                super(ConfigParser, self).__init__()
                self.AddGlobal(ArchiveSize = self.SetArchiveSize,       # Obsolete
                               BaseDir = self.SetBaseDir,
                               Exclude = self.AddExclude,
                               ExcludeGlob = self.AddExcludeGlob,       # Obsolete
                               ExcludeRegEx = self.AddExcludeRegEx,     # Obsolete
                               ExcludeRegexp = self.AddExcludeRegexp,
                               HashFunction = self.SetHashFunction,
                               Input = self.AddInput,
                               MediumSize = self.SetMediumSize)

                self.InputGlobs = []
                self.Filter = FilterList()

                self.ScriptPath = os.path.abspath(Argv[0])
                (Options, Arguments) = getopt.getopt(Argv[1:],
                        "a:cghm:psv",
                        ["archive=", "create", "graft-list", "help", "medium-size=",
                         "print", "status", "verbose"])

                # Parse config file first, so that command line overrides
                if len(Arguments) > 1:
                        raise Error, "More than one configuration file specified"
                if len(Arguments) == 1:
                        self.Descriptor = os.path.abspath(Arguments[0])
                        File = open(self.Descriptor, "r")
                        try:
                                try:
                                        self.Parse(File)
                                except ParseError, e:
                                        raise ParseError, os.path.basename(self.Descriptor) + ":" + str(e)
                        finally:
                                File.close()

                for (Opt, Param) in Options:
                        if Opt in ("-a", "--archive"):
                                self.Archive = int(Param)
                        elif Opt in ("-c", "--create"):
                                self.Create = 1
                        elif Opt in ("-g", "--graft-list"):
                                self.GraftList = 1
                        elif Opt in ("-h", "--help"):
                                self.Help = 1
                        elif Opt in ("-m", "--medium-size"):
                                self.SetMediumSize(Param)
                        elif Opt in ("-p", "--print"):
                                self.Print = 1
                        elif Opt in ("-s", "--status"):
                                self.Status = 1
                        elif Opt in ("-v", "--verbose"):
                                self.Verbose += 1
                
                if (len(Arguments) == 0) and not self.Help:
                        raise Error, "Missing configuration file"
                        
        def GetInputs(self):
                Inputs = []
                for Input in self.InputGlobs:
                        Entries = glob.glob(Input)
                        if not Entries:
                                Inputs.append(Input)
                        else:
                                Entries.sort()
                                Inputs.extend(Entries)
                return Inputs

        Inputs = property(GetInputs)

        def SetArchiveSize(self, *args, **kargs):
                print >> sys.stderr, "Warning: obsolete option 'ArchiveSize' (use 'MediumSize' instead)"
                self.SetMediumSize(*args, **kargs)
                
        def SetMediumSize(self, Value):
                if type(Value) == type(""):
                        if Value.endswith("k"):
                                self.MediumSize = int(Value[:-1]) * 1024
                        elif Value.endswith("M"):
                                self.MediumSize = int(Value[:-1]) * 1024 * 1024
                        else:
                                self.MediumSize = int(Value)
                else:
                        self.MediumSize = Value

        def SetHashFunction(self, HashFunctionName):
                FileInfo.HashFunction = HashFunctions[HashFunctionName]
                
        def SetBaseDir(self, Value):
                self.BaseDir = Value

        def AddInput(self, Input):
                if os.path.isabs(Input):
                        raise ParseError, "Absolute path '" + Input + "'"
                self.InputGlobs.append(Input)

        def AddExclude(self, Pattern):
                self.Filter.AddGlob(Pattern)

        def AddExcludeGlob(self, Pattern):
                print >> sys.stderr, "Warning: obsolete option 'ExcludeGlob' (use 'Exclude' instead)"
                self.Filter.AddGlob(Pattern)

        def AddExcludeRegEx(self, Pattern):
                print >> sys.stderr, "Warning: obsolete option 'ExcludeRegEx' (use 'ExcludeRegexp' instead)"
                self.Filter.AddRegexp(Pattern)

        def AddExcludeRegexp(self, Pattern):
                self.Filter.AddRegexp(Pattern)

                                
def Usage(Argv):
        """Print program usage info."""
        #                     0         1         2         3         4         5         6         7
        #                     01234567890123456789012345678901234567890123456789012345678901234567890123456789
        print >> sys.stderr, "Usage: %s [commands] [options] ConfigFile\n" % os.path.basename(Argv[0])
        print >> sys.stderr, "Commands: -c, --create           Create a new archive descriptor"
        print >> sys.stderr, "          -g, --graft-list       Output a graft list for an archive"
        print >> sys.stderr, "          -h, --help             Show this text"
        print >> sys.stderr, "          -p, --print            Print archive information"
        print >> sys.stderr, "          -s, --status           Print current synchronization status\n"
        print >> sys.stderr, "Options:  -a N, --archive N      Operate on archive number N"
        print >> sys.stderr, "          -m N, --medium-size N  Set archive medium size to N"
        print >> sys.stderr, "          -v, --verbose          Be more verbose"


# Main program
def Main(Argv):
        """Main program."""
        try:
                try:
                        Config = ConfigParser(Argv)
                except (getopt.GetoptError, ValueError, Error), e:
                        print >> sys.stderr, str(e) + "\n"
                        Usage(Argv)
                        return 2

                if Config.Help:
                        print >> sys.stderr, "%s %s   Incremental archiving tool to CD/DVD" % (ProgramName, ProgramVersion)
                        print >> sys.stderr, "Copyright (C) %s  %s\n" % (CopyrightYear, Author)
                        Usage(Argv)
                        return 2

                # Initial change of directory
                if Config.BaseDir:
                        os.chdir(Config.BaseDir)

                # Sync status printing
                if Config.Status:
                        if not Config.Inputs:
                                Usage(Argv)
                                return 2

                        Status = CreateSyncStatus(Config.Descriptor, Config.Inputs, Config.Filter, Config.Verbose > 0)
                        print Status[:-1]

                # Descriptor creation
                if Config.Create:
                        if not Config.Inputs:
                                Usage(Argv)
                                return 2

                        (Archive, Descriptor) = CreateDescriptor(Config.Descriptor, Config.Inputs,
                                                                 Config.Filter, Config.MediumSize)
                        File = open(ArchiveDescriptorName(Config.Descriptor, Archive), "w")
                        try:
                                File.write(Descriptor)
                        finally:
                                File.close()
                        Config.Archive = Archive

                # Status printing
                if Config.Print:
                        if Config.Archive == 0:
                                print >> sys.stderr, "No archive number specified\n"
                                Usage(Argv)
                                return 2

                        Status = CreateStatus(Config.Descriptor, Config.Archive, Config.Verbose > 0)
                        print Status[:-1]

                # Graft list output
                if Config.GraftList:
                        if Config.Archive == 0:
                                print >> sys.stderr, "No archive number specified\n"
                                Usage(Argv)
                                return 2

                        GraftList = CreateGraftList(Config.Descriptor, Config.Archive, Config.ScriptPath)
                        print GraftList[:-1]

                return 0

        except (ParseError, Error, EnvironmentError), e:
                print >> sys.stderr, str(e)
                return 1

        except KeyboardInterrupt, e:
                return 1

                
# Main entry point
if __name__ == "__main__":
        sys.exit(Main(sys.argv))

