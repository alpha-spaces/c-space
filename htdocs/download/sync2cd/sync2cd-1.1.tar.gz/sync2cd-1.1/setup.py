#!/usr/bin/env python
"""\
Installation script for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

from distutils.core import setup
import os
import sys

if __name__ == "__main__":
    if sys.version_info[:2] < (2, 2):
        print "sync2cd requires version 2.2 or later of python"
        sys.exit(1)

    # Import project metadata
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "lib")))
    from sync2cd import metadata
    
    setup(
        name = metadata.project,
        version = metadata.version,
        author = metadata.author,
        author_email = metadata.email,
        license = metadata.license,
        url = metadata.url,
        download_url = metadata.download,
        description = metadata.description,
        long_description = metadata.longDescription,
        keywords = metadata.keywords,
        platforms = metadata.platforms,
        classifiers = metadata.classifiers,

        package_dir = {"": "lib"},
        py_modules = ["sync2cd"],
        scripts = [
            "bin/sync2cd",
            "bin/sync2cd_mounter.sh",
            "bin/sync2cd_mkcd.sh",
            "bin/sync2cd_mkdvd.sh"],
        data_files = [
            ("share/doc/sync2cd-%s" % metadata.version, [
                "ChangeLog",
                "COPYING",
                "README",
                "doc/sync2cd.html"]),
        ],
    )

    if (metadata.version[-1:] == "x") or (metadata.date[-2:] == "xx"):
        print "\n*\n* WARNING: release metadata is not set\n*"
