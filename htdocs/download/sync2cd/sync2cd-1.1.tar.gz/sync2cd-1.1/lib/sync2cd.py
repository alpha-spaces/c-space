#!/bin/env python
"""\
Incremental archiving tool to CD/DVD
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# TODO: Func: Verify, check that CD is readable and compare contents

# TODO: Func: Rewrite last medium (possibly rewrite medium by ID)
# TODO: Customize suffix length in config file
# TODO: Customize block size in config file

# Module imports
import errno
import getopt
import glob
import md5
import os
import re
import sha
import shutil
import stat
import sys
import time
import traceback

__metaclass__ = type

# Constants
DescriptorFormatVersion = 3
SuffixSize = 4
BlockSize = 2048
DescriptorDir = ".sync2cd"
HashFunctions = {
    "md5": md5,
    "sha": sha,
    "sha1": sha
}

# Project metadata
class metadata:
    project   = "sync2cd"
    version   = "1.1"
    date      = "2006.05.06"
    author    = "Remy Blank"
    email     = "software@calins.ch"
    copyright = "Copyright (C) %s %s <%s>" % (date[0:4], author, email)
    license   = "GPL-2"
    url       = "http://www.calins.ch/software/%s.html" % project
    download  = "http://www.calins.ch/download/%s/%s-%s.tar.gz" % (project, project, version)
    description = "Incremental archiving tool to CD/DVD"
    longDescription = """\
sync2cd is an incremental archiving tool. It allows backing up complete
filesystem hierarchies to multiple backup media (e.g. CD-R). Files are archived
incrementally, i.e. only new or changed files are stored during an archive
operation.

All entity types are supported: directories, files, symlinks, named pipes,
sockets, block and character devices.
"""
    keywords = ["backup", "incremental", "archive", "CD", "DVD", "synchronization"]
    platforms = ["POSIX"]
    classifiers = [
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: End Users/Desktop",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: GNU General Public License (GPL)",
        "Operating System :: POSIX",
        "Programming Language :: Python",
        "Topic :: System :: Archiving",
    ]

__author__ = metadata.author
__version__ = metadata.version
__date__ = metadata.date


# Generic exception
class Error(Exception): pass
                

# Python script parser
class ParseError(Exception): pass

class ScriptParser(object):
    "Python script parser."
    def __init__(self):
        self.Globals = {}

    def AddGlobal(self, **kwargs):
        """Add symbols to globals."""
        self.Globals.update(kwargs)

    def Parse(self, Input, lineByLine=False):
        """Parse python script input."""
        if lineByLine:
            if isinstance(Input, basestring):
                it = Input.splitlines()
            else:
                it = Input
            lineNo = 0
            for line in it:
                lineNo += 1
                try:
                    exec line in self.Globals
                except:
                    (Type, Value, Traceback) = sys.exc_info()
                    if Traceback.tb_next is not None:
                        Traceback = Traceback.tb_next
                    ExcText = str(lineNo) + ": " + "".join(traceback.format_exception_only(Type, Value))
                    del Traceback
                    raise ParseError, ExcText[:-1]
        else:
            if type(Input) not in (str, file, type(self.Parse.func_code)):
                Input = Input.read()
            try:
                exec Input in self.Globals
            except:
                (Type, Value, Traceback) = sys.exc_info()
                if Traceback.tb_next is not None:
                    Traceback = Traceback.tb_next
                ExcText =   str(traceback.tb_lineno(Traceback)) + ": "                  \
                      + "".join(traceback.format_exception_only(Type, Value))
                del Traceback
                raise ParseError, ExcText[:-1]


# Helpers
def HumanReadable(Value, Kilo = 1024):
    """Convert a value to a human-readable format."""
    def ToDec(Value, Exp):
        if Value < 10 * Exp:
            (Div, Mod) = divmod(Value, Exp)
            return "%d.%d" % (Div, (Mod * 10) / Exp)
        else:
            return "%d" % (Value / Exp)
    
    if Value < Kilo:
        return str(Value)
    if Value < Kilo * Kilo:
        return ToDec(Value, Kilo) + "k"
    if Value < Kilo * Kilo * Kilo:
        return ToDec(Value, Kilo * Kilo) + "M"
    if Value < Kilo * Kilo * Kilo * Kilo:
        return ToDec(Value, Kilo * Kilo * Kilo) + "G"
    if Value < Kilo * Kilo * Kilo * Kilo * Kilo:
        return ToDec(Value, Kilo * Kilo * Kilo * Kilo) + "T"
    if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
        return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo) + "P"
    if Value < Kilo * Kilo * Kilo * Kilo * Kilo * Kilo * Kilo:
        return ToDec(Value, Kilo * Kilo * Kilo * Kilo * Kilo * Kilo) + "E"


def ToBytes(Value):
    if type(Value) == type(""):
        if Value.endswith("k"):
            return int(float(Value[:-1]) * 1024)
        elif Value.endswith("M"):
            return int(float(Value[:-1]) * 1024 * 1024)
        elif Value.endswith("G"):
            return int(float(Value[:-1]) * 1024 * 1024 * 1024)
        elif Value.endswith("T"):
            return int(float(Value[:-1]) * 1024 * 1024 * 1024 * 1024)
        elif Value.endswith("P"):
            return int(float(Value[:-1]) * 1024 * 1024 * 1024 * 1024 * 1024)
        elif Value.endswith("E"):
            return int(float(Value[:-1]) * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
        else:
            return int(float(Value))
    else:
        return int(Value)


# Entity creator
class EntityCreator:
    """Creator of filesystem entities"""
    def SetStat(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Set entity status."""
        s = os.lstat(Path)
        if (ATime, MTime) != (None, None):
            try:
                os.utime(Path, (ATime or s.st_atime, MTime or s.st_mtime))
            except OSError:
                pass
        if Mode is not None:
            try:
                os.chmod(Path, stat.S_IMODE(Mode))
            except OSError:
                pass
        if (Uid, Gid) != (None, None):
            try:
                os.lchown(Path, Uid or s.st_uid, Gid or s.st_gid)
            except OSError:
                pass

    def CreateFile(self, Path, SrcPath, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a file on the filesystem."""
        dstFile = os.fdopen(os.open(Path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0600), "w")
        try:
            srcFile = open(SrcPath, "rb")
            try:
                while 1:
                    data = srcFile.read(65536)
                    if not data:
                        break
                    dstFile.write(data)
            finally:
                srcFile.close()
        finally:
            dstFile.close()
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

    def CreateDir(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a directory on the filesystem."""
        os.mkdir(Path)
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

    def CreateSymlink(self, Path, Target, Uid=None, Gid=None):
        """Create a symbolic link on the filesystem."""
        os.symlink(Target, Path)
        self.SetStat(Path, None, Uid, Gid, None, None)

    def CreateCharDevice(self, Path, Device, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a character device on the filesystem."""
        os.mknod(Path, stat.S_IFCHR | 0600, Device)
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

    def CreateBlockDevice(self, Path, Device, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a block device on the filesystem."""
        os.mknod(Path, stat.S_IFBLK | 0600, Device)
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

    def CreatePipe(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a pipe on the filesystem."""
        os.mkfifo(Path)
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)

    def CreateSocket(self, Path, Mode=None, Uid=None, Gid=None, ATime=None, MTime=None):
        """Create a Unix socket on the filesystem."""
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind(Path)
        s.close()
        self.SetStat(Path, Mode, Uid, Gid, ATime, MTime)


# Directory entries
class DirEntInfo(object):
    __slots__ = ("Name", "Mode", "Owner", "Group", "MTime")
    
    Creator = EntityCreator()
    
    """Directory entry information holder."""
    def __init__(self, Name, Mode, Owner, Group, MTime):
        self.Name = os.path.normpath(Name)
        self.SetStat(Mode, Owner, Group, MTime)

    def SetStat(self, Mode, Owner, Group, MTime):
        self.Mode = stat.S_IMODE(Mode)
        self.Owner = Owner
        self.Group = Group
        self.MTime = MTime

    def __eq__(self, Other):
        return    (self.Mode, self.Owner, self.Group, self.MTime)       \
               == (Other.Mode, Other.Owner, Other.Group, Other.MTime)
                   
    def __ne__(self, Other):
        return not self.__eq__(Other)

    def __str__(self):
        Args = [repr(self.Name)]
        StrArgs = self.GetStrArgs()
        Args.extend(StrArgs[1:])
        return StrArgs[0] + "(" + ", ".join([str(x) for x in Args]) + ")"

    def AbsPath(self, Base):
        return os.path.abspath(os.path.join(Base, self.Name))

    def SetFsStat(self, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.SetStat(DstPath, self.Mode, self.Owner, self.Group, None, self.MTime)


class DirInfo(DirEntInfo):
    """Directory information holder."""
    __slots__ = ()
    
    def GetStrArgs(self):
        return ("D", oct(self.Mode), self.Owner, self.Group, self.MTime)
            
    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateDir(DstPath)


def FromHex(s):
    """Convert a hash from hex to binary."""
    return "".join(chr(int(s[each:each + 2], 16)) for each in range(0, len(s), 2))
    
    
def ToHex(s):
    """Convert a hash from binary to hex."""
    return "".join(hex(ord(each))[2:].zfill(2) for each in s)
    
    
class FileInfo(DirEntInfo):
    """File information holder."""
    CmpSame = 0
    CmpStatChanged = 1
    CmpChanged = 2

    HashFunction = md5

    __slots__ = ("Size", "_Hash", "Archive")

    def __init__(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive = 0):
        super(FileInfo, self).__init__(Name, Mode, Owner, Group, MTime)
        self.Size = Size
        self.SetHash(FromHex(Hash))
        self.Archive = Archive

    def PaddedSize(self, BlockSize):
        return (self.Size + (BlockSize - 1)) & ~(BlockSize - 1)
            
    def Hash(self):
        return self._Hash

    def SetHash(self, Hash):
        if Hash and (len(Hash) != FileInfo.HashFunction.digest_size):
            raise Error, "Hash function mismatch"
        self._Hash = Hash

    def __eq__(self, Other):
        return super(FileInfo, self).__eq__(Other) and (self.Size == Other.Size)
            
    def Compare(self, Other):
        if self.Size != Other.Size:
            return FileInfo.CmpChanged
        if self.MTime != Other.MTime:
            if self.Hash() != Other.Hash():
                return FileInfo.CmpChanged
            return FileInfo.CmpStatChanged
        if (self.Mode, self.Owner, self.Group) == (Other.Mode, Other.Owner, Other.Group):
            return FileInfo.CmpSame
        return FileInfo.CmpStatChanged

    def GetStrArgs(self):
        return ("F", oct(self.Mode), self.Owner, self.Group, self.MTime,
            self.Size, repr(ToHex(self.Hash())), self.Archive)

    def Create(self, SrcBase, DstBase):
        SrcPath = self.AbsPath(SrcBase)
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateFile(DstPath, SrcPath, self.Mode, self.Owner, self.Group, None, self.MTime)

                
class LazyFileInfo(FileInfo):
    """File info holder, with lazy MD5 evaluation."""
    __slots__ = ()
    
    def __init__(self, Name, Mode, Owner, Group, MTime, Size):
        super(LazyFileInfo, self).__init__(Name, Mode, Owner, Group, MTime, Size, "")

    def Hash(self):
        if not self._Hash:
            m = FileInfo.HashFunction.new()
            File = open(self.Name, "r")
            try:
                while 1:
                    Data = File.read(64 * 1024)
                    if not Data:
                        break
                    m.update(Data)
            finally:
                File.close()
            self._Hash = m.digest()
        return super(LazyFileInfo, self).Hash()

                
class SymLinkInfo(DirEntInfo):
    """Symbolic link information holder."""
    __slots__ = ("Target", )
    
    def __init__(self, Name, Mode, Owner, Group, MTime, Target):
        super(SymLinkInfo, self).__init__(Name, Mode, Owner, Group, MTime)
        self.Target = Target

    def __eq__(self, Other):
        return super(SymLinkInfo, self).__eq__(Other) and (self.Target == Other.Target)

    def GetStrArgs(self):
        return ("L", oct(self.Mode), self.Owner, self.Group, self.MTime,
            repr(self.Target))

    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateSymlink(DstPath, self.Target, self.Owner, self.Group)


class PipeInfo(DirEntInfo):
    """Named pipe information holder."""
    __slots__ = ()
    
    def GetStrArgs(self):
        return ("P", oct(self.Mode), self.Owner, self.Group, self.MTime)
    
    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreatePipe(DstPath, self.Mode, self.Owner, self.Group, None, self.MTime)

        
class SocketInfo(DirEntInfo):
    """Socket information holder."""
    __slots__ = ()
    
    def GetStrArgs(self):
        return ("S", oct(self.Mode), self.Owner, self.Group, self.MTime)

    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateSocket(DstPath, self.Mode, self.Owner, self.Group, None, self.MTime)


class DevInfo(DirEntInfo):
    """Device information holder."""
    __slots__ = ("RDev", )
    
    def __init__(self, Name, Mode, Owner, Group, MTime, RDev):
        super(DevInfo, self).__init__(Name, Mode, Owner, Group, MTime)
        self.RDev = RDev

    def __eq__(self, Other):
        return super(DevInfo, self).__eq__(Other) and (self.RDev == Other.RDev)


class BlockDevInfo(DevInfo):
    """Block device information holder."""
    __slots__ = ()
    
    def GetStrArgs(self):
        return ("B", oct(self.Mode), self.Owner, self.Group, self.MTime, self.RDev)

    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateBlockDevice(DstPath, self.RDev, self.Mode, self.Owner, self.Group, 
            None, self.MTime)


class CharDevInfo(DevInfo):
    """Char device information holder."""
    __slots__ = ()
    
    def GetStrArgs(self):
        return ("C", oct(self.Mode), self.Owner, self.Group, self.MTime, self.RDev)

    def Create(self, SrcBase, DstBase):
        DstPath = self.AbsPath(DstBase)
        self.Creator.CreateCharDevice(DstPath, self.RDev, self.Mode, self.Owner, self.Group, 
            None, self.MTime)


def LoadDirEntInfo(Name):
    """Create a DirEntInfo child and populate with info loaded from filesystem."""
    Name = os.path.normpath(Name)
    Stat = os.lstat(Name)
    Mode = Stat[stat.ST_MODE]
    if stat.S_ISDIR(Mode):
        return DirInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME])
    elif stat.S_ISREG(Mode):
        if not os.access(Name, os.R_OK):
            print >> sys.stderr, "Unreadable: " + Name
            return None
        return LazyFileInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME], Stat[stat.ST_SIZE])
    elif stat.S_ISLNK(Mode):
        return SymLinkInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME], os.readlink(Name))
    elif stat.S_ISFIFO(Mode):
        return PipeInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME])
    elif stat.S_ISSOCK(Mode):
        return SocketInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME])
    elif stat.S_ISBLK(Mode):
        return BlockDevInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME], Stat.st_rdev)
    elif stat.S_ISCHR(Mode):
        return CharDevInfo(Name, Mode, Stat[stat.ST_UID], Stat[stat.ST_GID],
            Stat[stat.ST_MTIME], Stat.st_rdev)
    print >> sys.stderr, "Omitting " + Name
    return None


# Filesystem tree
class FsTree(ScriptParser):
    """Filesystem tree container."""
    def __init__(self, Other = None):
        super(FsTree, self).__init__()
        self.AddGlobal(Sync2cd = self.Sync2cd,
            D = self.Dir,
            F = self.File,
            L = self.SymLink,
            P = self.Pipe,
            S = self.Socket,
            B = self.BlockDev,
            C = self.CharDev)
        
        if Other is not None:
            self.Archive = Other.Archive
            self.Time = Other.Time
            self.Version = Other.Version
            self.items = Other.items.copy()
        else:
            self.Archive = 0
            self.Time = 0
            self.Version = 0
            self.items = {}

    def SetMeta(self, Archive, Time = None):
        self.Archive = Archive
        if Time:
            self.Time = int(Time)
        else:
            self.Time = int(time.time())

    def TimeStr(self):
        return time.strftime("%Y.%m.%d %H:%M:%S UTC", time.gmtime(self.Time))
            
    def Add(self, Entry):
        self[Entry.Name] = Entry

    def __contains__(self, key):
        return key in self.items
        
    def __getitem__(self, key):
        return self.items[key]
        
    def __setitem__(self, key, value):
        self.items[key] = value
        
    def __delitem__(self, key):
        del self.items[key]
        
    def iterUnsorted(self):
        return self.items.itervalues()
        
    def iterSorted(self):
        keys = self.items.keys()
        keys.sort()
        for each in keys:
            yield self.items[each]

    def Sync2cd(self, Archive, Time, Version):
        self.Archive = Archive
        self.Time = int(Time)
        self.Version = Version
        if Version > DescriptorFormatVersion:
            print >> sys.stderr, "Warning: descriptor format version higher than current"

    def Dir(self, Name, Mode, Owner, Group, MTime):
        Mode = stat.S_IMODE(Mode) | stat.S_IFDIR
        self[Name] = DirInfo(Name, Mode, Owner, Group, MTime)

    def File(self, Name, Mode, Owner, Group, MTime, Size, Hash, Archive):
        Mode = stat.S_IMODE(Mode) | stat.S_IFREG
        self[Name] = FileInfo(Name, Mode, Owner, Group, MTime, Size, Hash, Archive)

    def SymLink(self, Name, Mode, Owner, Group, MTime, Target):
        Mode = stat.S_IMODE(Mode) | stat.S_IFLNK
        self[Name] = SymLinkInfo(Name, Mode, Owner, Group, MTime, Target)

    def Pipe(self, Name, Mode, Owner, Group, MTime):
        Mode = stat.S_IMODE(Mode) | stat.S_IFIFO
        self[Name] = PipeInfo(Name, Mode, Owner, Group, MTime)

    def Socket(self, Name, Mode, Owner, Group, MTime):
        Mode = stat.S_IMODE(Mode) | stat.S_IFSOCK
        self[Name] = SocketInfo(Name, Mode, Owner, Group, MTime)

    def BlockDev(self, Name, Mode, Owner, Group, MTime, RDev):
        Mode = stat.S_IMODE(Mode) | stat.S_IFBLK
        self[Name] = BlockDevInfo(Name, Mode, Owner, Group, MTime, RDev)

    def CharDev(self, Name, Mode, Owner, Group, MTime, RDev):
        Mode = stat.S_IMODE(Mode) | stat.S_IFCHR
        self[Name] = CharDevInfo(Name, Mode, Owner, Group, MTime, RDev)

    def MakeDescriptor(self, out):
        if self.Archive != 0:
            out.write('Sync2cd(Archive=' + str(self.Archive)
                    + ', Time=' + str(self.Time)
                    + ', Version=' + str(DescriptorFormatVersion)
                    + ') # ' + self.TimeStr() + '\n')
        for each in self.iterSorted():
            out.write(str(each) + "\n")

    def CreateStatus(self, out, Archive, ShowContent, MediumSize=None):
        TotalSize = 0
        PaddedSize = 0
        for Item in self.iterUnsorted():
            if not isinstance(Item, FileInfo):
                continue
            if Item.Archive != Archive:
                continue
            TotalSize += Item.Size
            PaddedSize += Item.PaddedSize(BlockSize)

        if self.Archive != 0:
            out.write("Archive:   %d\n" % self.Archive)
        if self.Time:
            out.write("Created:   %s (%d)\n" % (time.strftime("%d.%m.%Y, %H:%M:%S UTC", time.gmtime(self.Time)),
                self.Time))
        if self.Version:
            out.write("Version:   %d\n" % self.Version)
        out.write("Size:      %s (%d bytes)\n" % (HumanReadable(TotalSize), TotalSize))
        out.write("Padded:    %s (%d bytes)\n" % (HumanReadable(PaddedSize), PaddedSize))
        if MediumSize:
            Archives = (PaddedSize + MediumSize - 1) / MediumSize
            LastFree = MediumSize - (PaddedSize % MediumSize)
            if Archives == 0:
                out.write("Remaining: 0 archive\n")
            else:
                out.write("Remaining: %d archive%s will have %s free\n"
                    % (Archives, (Archives > 1) and "s, last one" or ",", 
                        HumanReadable(LastFree)))
        if ShowContent:
            out.write("Content:\n")
            for item in self.iterSorted():
                if not isinstance(item, FileInfo):
                    continue
                if item.Archive != Archive:
                    continue
                out.write(item.Name + "\n")
                
    def AddParentDirs(self, path, dict):
        dirPath = ""
        for part in path.split(os.sep)[:-1]:
            dirPath = os.path.join(dirPath, part)
            dict[dirPath] = 1
    
    def MakeRestoreList(self, Filter):
        # TODO: Return lists of items directly, instead of names
        DirFilter = FilterList()
        Dirs = {}
        Files = {}
        Others = {}

        # Must do a first pass with dirs only, as dicts are not sorted
        for item in self.iterUnsorted():
            if not isinstance(item, DirInfo):
                continue
            name = item.Name
            if Filter.Match(name) or DirFilter.Match(name):
                Dirs[name] = 1
                # TODO: Only if DirFilter doesn't match already
                DirFilter.AddGlob(os.path.join(name, "**"))
                self.AddParentDirs(name, Dirs)
        for item in self.iterUnsorted():
            if isinstance(item, DirInfo):
                continue
            name = item.Name
            if Filter.Match(name) or DirFilter.Match(name):
                if isinstance(item, FileInfo):
                    Files.setdefault(item.Archive, []).append(name)
                else:
                    Others[name] = 1
                self.AddParentDirs(name, Dirs)
                
        Dirs = Dirs.keys()
        Dirs.sort()
        Others = Others.keys()
        Others.sort()
        # Should already be sorted
        for each in Files.itervalues():
            each.sort()
        return (Dirs, Files, Others)
        

def TreeDiff(fromTree, toTree):
    """Compute the difference between two sorted lists."""
    added = []
    changed = []
    for item in toTree.iterUnsorted():
        name = item.Name
        if name not in fromTree:
            added.append(name)
        elif item != fromTree[name]:
            changed.append(name)
    return (added, changed)
        

def BackupTreeMerge(OldTree, PhysTree, NewArchiveNum, ExistingArchives, MaxTotalSize=0, SortKey=lambda Item: (Item.MTime, Item.Name)):
    """Merge two trees for backup purposes"""
    NewTree = FsTree(PhysTree)
    (added, changed) = TreeDiff(OldTree, PhysTree)

    # Tag added files
    stored = []
    for name in added:
        item = NewTree[name]
        if not isinstance(item, FileInfo):
            continue
        stored.append(name)
        item.Archive = NewArchiveNum
        
    # Tag changed files
    for name in changed:
        newItem = NewTree[name]
        if not isinstance(newItem, FileInfo):
            continue
        oldItem = OldTree[name]
        if newItem.Compare(oldItem) == FileInfo.CmpChanged:
            stored.append(name)
            newItem.Archive = NewArchiveNum
            
    # Copy existing info from old tree, provided archive still exists
    ArchiveDict = {}
    for n in ExistingArchives:
        ArchiveDict[n] = 1
    
    for item in NewTree.iterUnsorted():
        if not isinstance(item, FileInfo):
            continue
        if item.Archive != 0:
            continue
        k = item.Name
        oldItem = OldTree[k]
        if oldItem.Archive in ArchiveDict:
            item.SetHash(oldItem.Hash())
            item.Archive = oldItem.Archive
        else:
            stored.append(item.Name)
            item.Archive = NewArchiveNum
            
    # Limit total size to specified value
    if MaxTotalSize > 0:
        items = [(SortKey(NewTree[k]), NewTree[k]) for k in stored if isinstance(NewTree[k], FileInfo)]
        items.sort()
        curSize = 0
        for i in range(len(items)):
            item = items[i][1]
            curSize += item.PaddedSize(BlockSize)
            if curSize > MaxTotalSize:
                if i == 0:
                    raise Error, "Not enough room on medium for first file '%s', size %d" % (item.Name, item.Size)
                for (key, item) in items[i:]:
                    if item.Name in OldTree:
                        NewTree[item.Name] = OldTree[item.Name]
                    else:
                        del NewTree[item.Name]
                break
            item.SetHash("")
            item.Archive = NewArchiveNum

    return NewTree
        

# Archive descriptor
def ListArchives(DescriptorBase):
    """Return the list of available archive descriptors."""
    Files = glob.glob(DescriptorBase + "." + SuffixSize * "[0-9]")
    Archives = [int(File[-SuffixSize:]) for File in Files]
    Archives.sort()
    if Archives and Archives[0] == 0:
        del Archives[0]
    return Archives


def ArchiveDescriptorName(DescriptorBase, ArchiveNum):
    """Generate the name of an archive descriptor from the base name and the archive number."""
    return DescriptorBase + ".%0*d" % (SuffixSize, ArchiveNum)
        
        
def ReadArchiveDescriptor(DescriptorBase, ArchiveNum):
    """Read a complete archive descriptor."""
    Tree = FsTree()
    FileName = ArchiveDescriptorName(DescriptorBase, ArchiveNum)
    Input = open(FileName, "r")
    try:
        try:
            Tree.Parse(Input, lineByLine=True)
        except ParseError, e:
            raise ParseError, os.path.basename(FileName) + ":" + str(e)
        return Tree
    finally:
        Input.close()
        

# Filesystem walking
def WalkPath(Path, Tree, Filter = None):
    """Walk the filesystem and add entries to an FsTree."""
    def ProcessEntry((Tree, Filter), DirName, Names):
        ProcNames = []
        for i in range(len(Names)):
            Entry = Names[i]
            EntryName = os.path.join(DirName, Entry)
            if Filter is not None and Filter.Match(EntryName):
                continue
            ProcNames.append(Entry)
            Item = LoadDirEntInfo(EntryName)
            if Item is not None:
                Tree.Add(Item)
        Names[:] = ProcNames

    if Filter is not None and Filter.Match(Path):
        return
    TopEntry = LoadDirEntInfo(Path)
    if TopEntry is None:
        return
    Tree.Add(TopEntry)
    os.path.walk(Path, ProcessEntry, (Tree, Filter))


def WalkPaths(Paths, Filter = None):
    """Construct an FsTree by walking multiple paths of the filesystem."""
    Tree = FsTree()
    for Path in Paths:
        WalkPath(Path, Tree, Filter)
    return Tree


# Descriptor creation
def CreateDescriptor(DescriptorBase, Paths, Filter, MaxTotalSize=0, SortKey=lambda Item: (Item.MTime, Item.Name)):
    """Produce a new backup archive descriptor."""
    Archives = ListArchives(DescriptorBase)
    if not Archives:
        Archive = 1
        OldTree = FsTree()
    else:
        Archive = Archives[-1] + 1
        OldTree = ReadArchiveDescriptor(DescriptorBase, Archive - 1)

    PhysicalTree = WalkPaths(Paths, Filter)
    NewTree = BackupTreeMerge(OldTree, PhysicalTree, Archive, Archives, MaxTotalSize, SortKey)
    NewTree.SetMeta(Archive)
    
    fileName = ArchiveDescriptorName(DescriptorBase, Archive)
    out = open(fileName, "w")
    try:
        try:
            NewTree.MakeDescriptor(out)
        finally:
            out.close()
    except:
        try: os.remove(fileName)
        except: pass
        raise
    return Archive


# Restore
def Restore(DescriptorBase, Archive, Patterns, Mounter, DstPath, ShowItems=False):
    """Restore selected items"""
    if not Archive:
        Archives = ListArchives(DescriptorBase)
        if not Archives:
            raise Error, "No archives available"
        Archive = Archives[-1]

    Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
    (Dirs, Files, Others) = Tree.MakeRestoreList(Patterns)
    
    # Restore directories
    for each in Dirs:
        if ShowItems:
            print each
        try:
            DirEntInfo.Creator.CreateDir(os.path.abspath(os.path.join(DstPath, each)))
        except OSError, e:
            if e.errno != errno.EEXIST:
                raise

    # Restore special items
    for each in Others:
        if ShowItems:
            print each
        try:
            Tree.Others[each].Create("", DstPath)
        except OSError, e:
            print >>sys.stderr, str(e)
    
    # Restore files
    Archives = Files.keys()
    Archives.sort()
    for CurArchive in Archives:
        SrcPath = MountMedium(DescriptorBase, CurArchive, Mounter)
        if SrcPath is None:
            continue
        for each in Files[CurArchive]:
            item = Tree[each]
            if ShowItems:
                print each
            try:
                item.Create(SrcPath, DstPath)
            except (OSError, IOError), e:
                print >> sys.stderr, str(e)
    
    # Set attributes of directories
    for each in Dirs:
        if each not in Tree:
            continue
        item = Tree[each]
        if isinstance(item, DirInfo):
            item.SetFsStat(DstPath)

    # Eject last medium
    if Files:
        MountMedium(DescriptorBase, 0, Mounter)
        
                
def MountMedium(DescriptorBase, Archive, Mounter):
    """Mount a specific backup medium"""
    Pipe = os.popen(Mounter + " " + ArchiveDescriptorName(DescriptorBase, Archive), "r")
    Path = Pipe.read()
    Result = Pipe.close()
    if not Result:
        return Path.strip()
    elif os.WIFSIGNALED(Result):
        raise Error, "Mounter script exited with signal " + str(os.WTERMSIG(Result))
    elif os.WEXITSTATUS(Result) == 1:
        return None
    elif os.WEXITSTATUS(Result) > 1:
        raise Error, "Restore aborted by mounter script"

        
# Status creation
def CreateStatus(out, DescriptorBase, Archive, ShowContent):
    """Produce a status output for a specific archive."""
    Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
    Status = Tree.CreateStatus(out, Archive, ShowContent)
    return Status
        

def CreateSyncStatus(out, DescriptorBase, Paths, Filter, ShowContent, MediumSize=None, SortKey=lambda Item: (Item.MTime, Item.Name)):
    """Produce a synchronization status ouptut of the current state of the filesystem."""
    Archives = ListArchives(DescriptorBase)
    if not Archives:
        OldTree = FsTree()
    else:
        OldTree = ReadArchiveDescriptor(DescriptorBase, Archives[-1])

    PhysicalTree = WalkPaths(Paths, Filter)
    NewTree = BackupTreeMerge(OldTree, PhysicalTree, -1, Archives, SortKey)
    Status = NewTree.CreateStatus(out, -1, ShowContent, MediumSize)
    return Status
        

# Graft list creation
def GraftEscape(s):
    """Escape a file name to be used as a graft point."""
    s = s.replace("\\", "\\\\")
    s = s.replace("=", "\\=")
    return s


def GraftEntry(Src, Dst):
    """Generate a graft list entry."""
    while Dst.startswith(os.sep):
        Dst = Dst[1:]
    return GraftEscape(Dst) + "=" + GraftEscape(Src)

                
def CreateGraftList(DescriptorBase, Archive, ScriptPath, out):
    """Produce a graft list that can be fed to mkisofs."""
    DescName = ArchiveDescriptorName(DescriptorBase, Archive)
    Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
    out.write(GraftEntry(ScriptPath, os.path.join(DescriptorDir, os.path.basename(ScriptPath))) + "\n")
    out.write(GraftEntry(DescriptorBase, os.path.join(DescriptorDir, os.path.basename(DescriptorBase))) + "\n")
    out.write(GraftEntry(DescName, os.path.join(DescriptorDir, os.path.basename(DescName))) + "\n")
    for Item in Tree.iterSorted():
        if not isinstance(Item, FileInfo):
            continue
        if Item.Archive != Archive:
            continue
        out.write(GraftEntry(os.path.abspath(Item.Name), Item.Name) + "\n")


# Copying operation
def Copy(Src, Dst, ShowFiles):
    """Copy a file"""
    if ShowFiles:
        print Src
    Dir = os.path.dirname(Dst)
    if not os.path.isdir(Dir):
        os.makedirs(Dir)
    shutil.copyfile(Src, Dst)
        

def CopyFiles(DescriptorBase, Archive, ScriptPath, Destination, ShowFiles):
    """Copy files to destination"""
    DescName = ArchiveDescriptorName(DescriptorBase, Archive)
    Tree = ReadArchiveDescriptor(DescriptorBase, Archive)
    Copy(ScriptPath, os.path.join(Destination, DescriptorDir, os.path.basename(ScriptPath)), ShowFiles)
    Copy(DescriptorBase, os.path.join(Destination, DescriptorDir, os.path.basename(DescriptorBase)), ShowFiles)
    Copy(DescName, os.path.join(Destination, DescriptorDir, os.path.basename(DescName)), ShowFiles)
    for Item in Tree.iterSorted():
        if not isinstance(Item, FileInfo):
            continue
        if Item.Archive == Archive:
            Dst = Item.Name
            while Dst.startswith(os.sep):
                Dst = Dst[1:]
            Copy(Item.Name, os.path.join(Destination, Dst), ShowFiles)
                    
        
# Shell-style pattern to regexp converter
def GlobToRegexp(ShellPattern):
    """Convert a shell-style pattern to a regexp."""
    Result = ""
    i = 0
    n = len(ShellPattern)
    while i < n:
        c = ShellPattern[i]
        i += 1
        if c == "*":
            if i < n and ShellPattern[i] == "*":
                Result += ".*"
                i += 1
            else:
                Result += "[^" + os.sep + "]*"
        elif c == "?":
            Result += "[^" + os.sep + "]"
        elif c == "[":
            j = i
            if ShellPattern[j] == "!" or ShellPattern[j] == "^":
                j += 1
            if ShellPattern[j] == "]":
                j += 1
            while j < n and ShellPattern[j] != "]":
                j += 1
            if j >= n:
                Result += "\\["
            else:
                Chars = ShellPattern[i:j].replace("\\", "\\\\")
                i = j + 1
                if Chars[0] == "!":
                    Chars = "^" + Chars[1:]
                Result += "[%s]" % Chars
        else:
            Result += re.escape(c)
    return Result + "$"


# Filter list manager
class FilterList:
    "Filter list."
    def __init__(self):
        self.Patterns = []
            
    def AddGlob(self, Pattern):
        self.Patterns.append(re.compile(GlobToRegexp(Pattern)))

    def AddRegexp(self, Pattern):
        self.Patterns.append(re.compile(Pattern))

    def Match(self, Path):
        for Pattern in self.Patterns:
            if Pattern.match(Path):
                return 1
        return 0
    
    def Count(self):
        return len(self.Patterns)
                        
        
# Configuration parser
class ConfigParser(ScriptParser):
    "Configuration parser."
    Archive = 0
    Copy = 0
    Create = 0
    Destination = ""
    GraftList = 0
    Help = 0
    MediumSize = 0
    Mounter = ""
    Print = 0
    Restore = 0
    Sort = "time"
    Status = 0
    Verbose = 0
    Descriptor = ""

    BaseDir = ""
    ScriptPath = ""

    def __init__(self, Argv):
        super(ConfigParser, self).__init__()
        self.AddGlobal(ArchiveSize = self.SetArchiveSize,       # Obsolete
                       BaseDir = self.SetBaseDir,
                       Exclude = self.AddExclude,
                       ExcludeGlob = self.AddExcludeGlob,       # Obsolete
                       ExcludeRegEx = self.AddExcludeRegEx,     # Obsolete
                       ExcludeRegexp = self.AddExcludeRegexp,
                       HashFunction = self.SetHashFunction,
                       Input = self.AddInput,
                       MediumSize = self.SetMediumSize,
                       Sort= self.SetSort)

        self.InputGlobs = []
        self.Filter = FilterList()
        self.Patterns = FilterList()

        Path = os.path.abspath(__file__)
        if (Path.endswith(".pyc") or Path.endswith(".pyo")) and os.path.isfile(Path[:-1]):
            Path = Path[:-1]
        self.ScriptPath = Path
        
        (Options, Arguments) = getopt.getopt(Argv[1:],
            "a:b:cd:ghm:n:prsvx:y",
            ["archive=", "copy", "create", "destination=", "glob=", "graft-list", "help", 
             "medium-size=", "mounter=", "print", "regexp=", "restore", "sort=", "status", 
             "verbose"])

        # Parse config file first, so that command line overrides
        if len(Arguments) >= 1:
            self.Descriptor = os.path.abspath(Arguments[0])
            File = open(self.Descriptor, "r")
            try:
                try:
                    self.Parse(File)
                except ParseError, e:
                    raise ParseError, os.path.basename(self.Descriptor) + ":" + str(e)
            finally:
                File.close()

        for (Opt, Param) in Options:
            if Opt in ("-a", "--archive"):
                self.Archive = int(Param)
            elif Opt in ("-b", "--glob"):
                self.Patterns.AddGlob(Param)
            elif Opt in ("-d", "--destination"):
                self.Destination = Param
            elif Opt in ("-c", "--create"):
                self.Create = 1
            elif Opt in ("-g", "--graft-list"):
                self.GraftList = 1
            elif Opt in ("-h", "--help"):
                self.Help = 1
            elif Opt in ("-m", "--medium-size"):
                self.SetMediumSize(Param)
            elif Opt in ("-n", "--mounter"):
                self.Mounter = Param
            elif Opt in ("-p", "--print"):
                self.Print = 1
            elif Opt in ("-r", "--restore"):
                self.Restore = 1
            elif Opt in ("--sort", ):
                self.Sort = Param
            elif Opt in ("-s", "--status"):
                self.Status = 1
            elif Opt in ("-v", "--verbose"):
                self.Verbose += 1
            elif Opt in ("-x", "--regexp"):
                self.Patterns.AddRegexp(Param)
            elif Opt in ("-y", "--copy"):
                self.Copy = 1

        if self.Create and self.Restore:
            raise Error, "--create and --restore are mutually exclusive"
        if self.Copy and self.Restore:
            raise Error, "--copy and --restore are mutually exclusive"
        if (len(Arguments) == 0) and not self.Help:
            raise Error, "Missing configuration file"
        if len(Arguments) > 1:
            raise Error, "Parameters found after configuration file"

        if self.Destination:
            self.Destination = os.path.abspath(self.Destination)
        if self.Mounter:
            self.Mounter = os.path.abspath(self.Mounter)
        if self.Sort == "alpha":
            self.SortKey = lambda Item: Item.Name
        elif self.Sort == "time":
            self.SortKey = lambda Item: (Item.MTime, Item.Name)
        else:
            raise Error, "Invalid sort criterion: %s" % self.Sort
                    
    def GetInputs(self):
        Inputs = []
        for Input in self.InputGlobs:
            Entries = glob.glob(Input)
            if not Entries:
                Inputs.append(Input)
            else:
                Entries.sort()
                Inputs.extend(Entries)
        return Inputs

    Inputs = property(GetInputs)

    def SetArchiveSize(self, *args, **kargs):
        print >> sys.stderr, "Warning: obsolete option 'ArchiveSize' (use 'MediumSize' instead)"
        self.SetMediumSize(*args, **kargs)
            
    def SetMediumSize(self, Value):
        self.MediumSize = ToBytes(Value)

    def SetHashFunction(self, HashFunctionName):
        FileInfo.HashFunction = HashFunctions[HashFunctionName]
            
    def SetSort(self, Value):
        self.Sort = Value
        
    def SetBaseDir(self, Value):
        self.BaseDir = Value

    def AddInput(self, Input):
        if os.path.isabs(Input):
            raise ParseError, "Absolute path: '" + Input + "'"
        self.InputGlobs.append(Input)

    def AddExclude(self, Pattern):
        self.Filter.AddGlob(Pattern)

    def AddExcludeGlob(self, Pattern):
        print >> sys.stderr, "Warning: obsolete option 'ExcludeGlob' (use 'Exclude' instead)"
        self.Filter.AddGlob(Pattern)

    def AddExcludeRegEx(self, Pattern):
        print >> sys.stderr, "Warning: obsolete option 'ExcludeRegEx' (use 'ExcludeRegexp' instead)"
        self.Filter.AddRegexp(Pattern)

    def AddExcludeRegexp(self, Pattern):
        self.Filter.AddRegexp(Pattern)

                                
def Usage(Argv):
    """Print program usage info."""
    #                     0         1         2         3         4         5         6         7
    #                     01234567890123456789012345678901234567890123456789012345678901234567890123456789
    print >> sys.stderr, "Usage: %s [commands] [options] config_file\n" % os.path.basename(Argv[0])
    print >> sys.stderr, "Commands: -c, --create               Create a new archive descriptor"
    print >> sys.stderr, "          -g, --graft-list           Output a graft list for an archive"
    print >> sys.stderr, "          -h, --help                 Show this text"
    print >> sys.stderr, "          -p, --print                Print archive information"
    print >> sys.stderr, "          -r, --restore              Restore from archives"
    print >> sys.stderr, "          -s, --status               Print current synchronization status"
    print >> sys.stderr, "          -y, --copy                 Copy files of an archive to destination\n"
    print >> sys.stderr, "Options:  -a N, --archive N          Operate on archive number N"
    print >> sys.stderr, "          -b GLOB, --glob GLOB       Add glob GLOB to pattern list"
    print >> sys.stderr, "          -d DIR, --destination DIR  Copy or restore into directory DIR"
    print >> sys.stderr, "          -m N, --medium-size N      Set archive medium size to N"
    print >> sys.stderr, "          -n CMD, --mounter CMD      Mount media using CMD for restore"
    print >> sys.stderr, "          --sort HOW                 File sorting key (time or alpha)"
    print >> sys.stderr, "          -v, --verbose              Be more verbose"
    print >> sys.stderr, "          -x EXP, --regexp EXP       Add regular expression EXP to pattern list"


# Main program
def Main(Argv):
    """Main program."""
    try:
        try:
            Config = ConfigParser(Argv)
        except (getopt.GetoptError, ValueError, Error), e:
            print >> sys.stderr, str(e) + "\n"
            Usage(Argv)
            return 2

        if Config.Help:
            print >> sys.stderr, "%s %s   %s" % (metadata.project, metadata.version, 
                metadata.description)
            print >> sys.stderr, metadata.copyright
            Usage(Argv)
            return 2

        # Initial change of directory
        if Config.BaseDir:
            os.chdir(Config.BaseDir)

        # Sync status printing
        if Config.Status:
            if not Config.Inputs:
                print >> sys.stderr, "No Input() in configuration file\n"
                Usage(Argv)
                return 2

            CreateSyncStatus(sys.stdout, Config.Descriptor, Config.Inputs, Config.Filter, 
                Config.Verbose > 0, Config.MediumSize, Config.SortKey)

        # Descriptor creation
        if Config.Create:
            if not Config.Inputs:
                print >> sys.stderr, "No Input() in configuration file\n"
                Usage(Argv)
                return 2

            Archive = CreateDescriptor(Config.Descriptor, Config.Inputs,
                Config.Filter, Config.MediumSize, Config.SortKey)
            Config.Archive = Archive

        # Status printing
        if Config.Print:
            if Config.Archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                Usage(Argv)
                return 2

            CreateStatus(sys.stdout, Config.Descriptor, Config.Archive, Config.Verbose > 0)

        # Graft list output
        if Config.GraftList:
            if Config.Archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                Usage(Argv)
                return 2

            CreateGraftList(Config.Descriptor, Config.Archive, Config.ScriptPath, sys.stdout)

        # Copy
        if Config.Copy:
            if Config.Archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                Usage(Argv)
                return 2
            if not Config.Destination:
                print >> sys.stderr, "Missing destination"
                return 2
            if not os.path.isdir(Config.Destination):
                print >> sys.stderr, "Invalid destination: " + Config.Destination
                return 2

            CopyFiles(Config.Descriptor, Config.Archive, Config.ScriptPath, 
                Config.Destination, Config.Verbose > 0)
            
        # Restore
        if Config.Restore:
            if not Config.Mounter:
                print >> sys.stderr, "Missing mount script\n"
                Usage(Argv)
                return 2
            if not Config.Destination:
                Config.Destination = os.path.abspath(os.curdir)
            if not os.path.isdir(Config.Destination):
                print >> sys.stderr, "Invalid destination: " + Config.Destination
                return 2
            if Config.Patterns.Count() == 0:
                Config.Patterns.AddGlob("**")
                    
            Restore(Config.Descriptor, Config.Archive, Config.Patterns, Config.Mounter, 
                Config.Destination, Config.Verbose > 0)
                
        return 0

    except ParseError, e:
        print >> sys.stderr, "Parse error: " + str(e)
        return 1
    except Error, e:
        print >> sys.stderr, "Error: " + str(e)
        return 1
    except OSError, e:
        print >> sys.stderr, str(e)
        return 1
    except KeyboardInterrupt, e:
        print >> sys.stderr, "Aborted by user"
        return 1

                
# Main entry point
if __name__ == "__main__":
    sys.exit(Main(sys.argv))

