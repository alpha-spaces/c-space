# -*- coding: iso-8859-1 -*-

"""\
Test cases for sync2cd
Copyright (C) 2006  Remy Blank

This file is part of sync2cd.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation, version 2.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
"""

# Module imports
import os

from Vfs import TestFiles, VfsTestCase
import sync2cd

# DirEntInfo children
class DirEntInfoTest(VfsTestCase):
    """DirEntInfo child tests."""
    def testDirInfoAttributes(self):
        "Info loading for a directory"
        FileName = "home/test"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.DirInfo))

    def testFileInfoAttributes(self):
        "Creation and attributes of FileInfo"
        FileName = "home/test/file1.mp3"
        Info = sync2cd.LoadDirEntInfo(FileName)

        self.assertEqual(Info.Name, FileName)
        self.assertEqual(Info.Mode, 0770)
        self.assert_(isinstance(Info, sync2cd.FileInfo))
        self.assertEqual(Info.Owner, 500)
        self.assertEqual(Info.Group, 600)
        self.assertEqual(Info.MTime, 1063048395)
        self.assertEqual(Info.Size,  1280)
        m = sync2cd.FileInfo.HashFunction.new(TestFiles[os.path.abspath(FileName)][1])
        self.assertEqual(Info.Hash(), m.digest())

    def testSymLinkInfoAttributes(self):
        "Info loading for a link"
        FileName = "home/test/link1.mp3"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.SymLinkInfo))
        self.assertEqual(Info.Target, "home/test/file1.mp3")

    def testPipeInfoAttributes(self):
        "Info loading for a pipe"
        FileName = "special/gpmdata"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.PipeInfo))

    def testSocketInfoAttributes(self):
        "Info loading for a socket"
        FileName = "special/lircd"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.SocketInfo))

    def testBlockDevInfoAttributes(self):
        "Info loading for a block device"
        FileName = "special/hda1"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.BlockDevInfo))

    def testCharDevInfoAttributes(self):
        "Info loading for a char device"
        FileName = "special/random"
        Info = sync2cd.LoadDirEntInfo(FileName)
        self.assert_(isinstance(Info, sync2cd.CharDevInfo))

    def testDirComparison(self):
        "Comparison between directories"
        Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048395)
        self.assertEqual(Info1, Info2)

        Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        Info2 = sync2cd.DirInfo("Dir2", 0771, 500, 600, 1063048395)
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        Info2 = sync2cd.DirInfo("Dir2", 0770, 501, 600, 1063048395)
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 601, 1063048395)
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        Info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048396)
        self.assertNotEqual(Info1, Info2)

    def testFileComparison(self):
        "Comparison between files"
        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
        self.assertEqual(Info1, Info2)
        
        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0771, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(Info1, Info2)

    def testFileInfoComparison(self):
        "Comparison between FileInfo instances"
        Info1_1 = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
        Info1_2 = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
        self.assertEqual(Info1_1.Compare(Info1_2), sync2cd.FileInfo.CmpSame)

        Info2 = sync2cd.LoadDirEntInfo("home/test/file2.mp3")
        self.assertEqual(Info1_1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)
        
        Info3 = sync2cd.LoadDirEntInfo("home/test/file3.mp3")
        self.assertEqual(Info1_1.Compare(Info3), sync2cd.FileInfo.CmpChanged)

    def testFileCompare(self):
        "Comparison between files with Compare()"
        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)
        
        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 33273, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpStatChanged)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpChanged)

        # Don't evaluate MD5 if size and mtime haven't changed
        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)

        Info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        Info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "00000000000000000000000000000000")
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpChanged)

    def testLinkComparison(self):
        "Comparison between Links"
        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target")
        self.assertEqual(Info1, Info2)

        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        Info2 = sync2cd.SymLinkInfo("Link2", 0771, 500, 600, 1063048395, "Target")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        Info2 = sync2cd.SymLinkInfo("Link2", 0770, 501, 600, 1063048395, "Target")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 601, 1063048395, "Target")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048396, "Target")
        self.assertNotEqual(Info1, Info2)

        Info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target1")
        Info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target2")
        self.assertNotEqual(Info1, Info2)

    def testDirectFileInfo(self):
        "Direct FileInfo structure"
        FileName = "home/test/file1.mp3"
        Info1 = sync2cd.FileInfo(FileName, 0770, 500, 600, 1063048395, 1280,
                                 sync2cd.FileInfo.HashFunction.new(TestFiles[os.path.abspath(FileName)][1]).hexdigest())
        Info2 = sync2cd.LoadDirEntInfo(FileName)
        self.assertEqual(Info1.Compare(Info2), sync2cd.FileInfo.CmpSame)

    def testToStr(self):
        "Conversion of DirEntInfo to string"
        Info = sync2cd.LoadDirEntInfo("home/test/dir1")
        Output = str(Info)
        self.assertEqual(Output, "D('home/test/dir1', 0700, 500, 600, 1067336294)")

        Info = sync2cd.LoadDirEntInfo("home/test/link1.mp3")
        Output = str(Info)
        self.assertEqual(Output, "L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')")

        Info = sync2cd.LoadDirEntInfo("home/test/file1.mp3")
        Output = str(Info)
        self.assertEqual(Output, "F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)")

        Info = sync2cd.LoadDirEntInfo("special/gpmdata")
        Output = str(Info)
        self.assertEqual(Output, "P('special/gpmdata', 0664, 0, 0, 1007419555)")

        Info = sync2cd.LoadDirEntInfo("special/hda1")
        Output = str(Info)
        self.assertEqual(Output, "B('special/hda1', 0660, 0, 6, 1018535114, 769)")

        Info = sync2cd.LoadDirEntInfo("special/random")
        Output = str(Info)
        self.assertEqual(Output, "C('special/random', 0644, 0, 0, 1018535114, 264)")

    def testToStrWithQuotes(self):
        "Conversion to string with quotes in filenames"
        Info = sync2cd.SymLinkInfo('home/test/link"with"quotes', 0777, 0, 0, 1034546253, 'home/target"with"quotes')
        Output = str(Info)
        self.assertEqual(Output, "L('home/test/link\"with\"quotes', 0777, 0, 0, 1034546253, 'home/target\"with\"quotes')")

        Info = sync2cd.SymLinkInfo('home/test/link\'with\'quotes', 0777, 0, 0, 1034546253, 'home/target\'with\'quotes')
        Output = str(Info)
        self.assertEqual(Output, 'L("home/test/link\'with\'quotes", 0777, 0, 0, 1034546253, "home/target\'with\'quotes")')

        Info = sync2cd.SymLinkInfo('home/test/link"with\'quotes', 0777, 0, 0, 1034546253, 'home/target"with\'quotes')
        Output = str(Info)
        self.assertEqual(Output, "L('home/test/link\"with\\\'quotes', 0777, 0, 0, 1034546253, 'home/target\"with\\\'quotes')")

    def testToStrSpecialChars(self):
        "Conversion of DirEntInfo to string with special chars"
        Info = sync2cd.SymLinkInfo('home/test/���\\���', 0777, 0, 0, 1034546253, 'home/target/���\\���')
        Output = str(Info)
        self.assertEqual(Output, "L('home/test/\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4', 0777, 0, 0, 1034546253, 'home/target/\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4')")
            
    def testNonNormalPath(self):
        "Normalization of non-normal path"
        Info = sync2cd.LoadDirEntInfo("home//./test/dir1/../file1.mp3")
        self.assertEqual(Info.Name, "home/test/file1.mp3")


class DirEntCreationTest(VfsTestCase):
    """DirEnt entity creation tests."""
    def testDirCreation(self):
        "Creating a directory entity"
        Info = sync2cd.DirInfo("Dir", 0770, 500, 600, 1063048395)
        Info.Create("", "/dest")
        Info.SetFsStat("/dest")
        self.assertEqual({
            "/dest/Dir": ("D", {"Mode": 0770, "Uid": 500, "Gid": 600, "MTime": 1063048395})
        }, self.Entities)
                    
    def testFileCreation(self):
        "Creating a file entity"
        Info = sync2cd.FileInfo("dir/File", 0770, 500, 600, 1063048395, 1234, "00000000000000000000000000000000")
        Info.Create("/home/src", "/dest")
        self.assertEqual({
            "/dest/dir/File": ("F", {"Mode": 0770, "Uid": 500, "Gid": 600, 
                "MTime": 1063048395, "SrcPath": "/home/src/dir/File"})
        }, self.Entities)
                
    def testSymLinkCreation(self):
        "Creating a symlink entity"
        Info = sync2cd.SymLinkInfo("Link", 0770, 500, 600, 1063048395, "LinkTarget")
        Info.Create("", "/dest")
        self.assertEqual({
            "/dest/Link": ("L", {"Uid": 500, "Gid": 600, "Target": "LinkTarget"})
        }, self.Entities)

    def testPipeCreation(self):
        "Creating a named pipe entity"
        Info = sync2cd.PipeInfo("Pipe", 0770, 500, 600, 1063048395)
        Info.Create("", "/dest")
        self.assertEqual({
            "/dest/Pipe": ("P", {"Mode": 0770, "Uid": 500, "Gid": 600, "MTime": 1063048395})
        }, self.Entities)
                    
    def testSocketCreation(self):
        "Creating a socket entity"
        Info = sync2cd.SocketInfo("Socket", 0770, 500, 600, 1063048395)
        Info.Create("", "/dest")
        self.assertEqual({
            "/dest/Socket": ("S", {"Mode": 0770, "Uid": 500, "Gid": 600, "MTime": 1063048395})
        }, self.Entities)
                    
    def testBlockDevCreation(self):
        "Creating a block device entity"
        Info = sync2cd.BlockDevInfo("BlkDev", 0770, 500, 600, 1063048395, 1)
        Info.Create("", "/dest")
        self.assertEqual({
            "/dest/BlkDev": ("B", {"Device": 1, "Mode": 0770, "Uid": 500, "Gid": 600, 
                "MTime": 1063048395})
        }, self.Entities)
                    
    def testCharDevCreation(self):
        "Creating a character device entity"
        Info = sync2cd.CharDevInfo("ChrDev", 0770, 500, 600, 1063048395, 2)
        Info.Create("", "/dest")
        self.assertEqual({
            "/dest/ChrDev": ("C", {"Device": 2, "Mode": 0770, "Uid": 500, "Gid": 600, 
                "MTime": 1063048395})
        }, self.Entities)
                    
