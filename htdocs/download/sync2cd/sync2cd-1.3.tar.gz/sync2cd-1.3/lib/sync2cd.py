#!/usr/bin/env python
"""\
Incremental archiving tool to CD/DVD
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

# TODO: Func: Add support for POSIX ACLs
# TODO: Func: Verify, check that CD is readable and compare contents

# TODO: Func: Rewrite last medium (possibly rewrite medium by ID)
# TODO: Customize suffix length in config file
# TODO: Customize block size in config file

import errno
import getopt
import glob
import gzip
import md5
import os
import re
import sha
import shutil
import stat
import sys
import time
import traceback

# Constants
descriptorFormatVersion = 3
suffixSize = 4
blockSize = 2048
descriptorDir = ".sync2cd"
compressedExt = ".gz"
hashFunctions = {
    "md5": md5,
    "sha": sha,
    "sha1": sha
}

# Project metadata
class metadata(object):
    project   = "sync2cd"
    version   = "1.3"
    date      = "2007.04.09"
    author    = "Remy Blank"
    email     = "software@calins.ch"
    copyright = "Copyright (C) %s %s <%s>" % (date[0:4], author, email)
    license   = "GPL-2"
    url       = "http://www.calins.ch/software/%s.html" % project
    download  = "http://www.calins.ch/download/%s/%s-%s.tar.gz" % (project, project, version)
    description = "Incremental archiving tool to CD/DVD"
    longDescription = """\
sync2cd is an incremental archiving tool. It allows backing up complete
filesystem hierarchies to multiple backup media (e.g. CD-R). Files are archived
incrementally, i.e. only new or changed files are stored during an archiveMTime
operation.

All entity types are supported: directories, files, symlinks, named pipes,
sockets, block and character devices.
"""
    keywords = ["backup", "incremental", "archive", "CD", "DVD", "synchronization"]
    platforms = ["POSIX"]
    classifiers = [
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: End Users/Desktop",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: GNU General Public License (GPL)",
        "Operating System :: POSIX",
        "Programming Language :: Python",
        "Topic :: System :: Archiving",
    ]

__author__ = metadata.author
__version__ = metadata.version
__date__ = metadata.date


# Hooks for unit tests
_open = open
_zopen = gzip.open

# Exceptions
class Error(Exception): pass
class ParseError(Exception): pass

# Python script parser
class ScriptParser(object):
    "Python script parser."
    def __init__(self):
        self.globals = {}

    def addGlobal(self, **kwargs):
        """Add symbols to globals."""
        self.globals.update(kwargs)

    def parse(self, input, lineByLine=False):
        """Parse python script input."""
        if lineByLine:
            if isinstance(input, basestring):
                it = input.splitlines()
            else:
                it = input
            lineNo = 0
            for line in it:
                lineNo += 1
                try:
                    exec line in self.globals
                except:
                    (typ, value, tb) = sys.exc_info()
                    if tb.tb_next is not None:
                        tb = tb.tb_next
                    excText = str(lineNo) + ": " + "".join(traceback.format_exception_only(typ, value))
                    del tb
                    raise ParseError(excText[:-1])
        else:
            if type(input) not in (str, file, type(self.parse.func_code)):
                input = input.read()
            try:
                exec input in self.globals
            except:
                (typ, value, tb) = sys.exc_info()
                if tb.tb_next is not None:
                    tb = tb.tb_next
                excText =   str(traceback.tb_lineno(tb)) + ": "                  \
                      + "".join(traceback.format_exception_only(typ, value))
                del tb
                raise ParseError(excText[:-1])


# Helpers
def humanReadable(value, kilo=1024):
    """Convert a value to a human-readable format."""
    def toDec(value, exp):
        if value < 10 * exp:
            (div, mod) = divmod(value, exp)
            return "%d.%d" % (div, (mod * 10) / exp)
        else:
            return "%d" % (value / exp)

    if value < kilo:
        return str(value)
    for (i, suffix) in enumerate(["k", "M", "G", "T", "P"]):
        if value < kilo ** (i + 2):
            return toDec(value, kilo ** (i + 1)) + suffix
    return toDec(value, kilo ** 6) + "E"


def toBytes(value, kilo=1024):
    if type(value) == type(""):
        for (i, suffix) in enumerate(["k", "M", "G", "T", "P", "E"]):
            if value.endswith(suffix):
                return int(float(value[:-1]) * kilo ** (i + 1))
        return int(float(value))
    else:
        return int(value)


# Entity creator
class EntityCreator(object):
    """Creator of filesystem entities"""
    def setStat(self, path, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Set entity status."""
        s = os.lstat(path)
        if (atime, mtime) != (None, None):
            try:
                os.utime(path, (atime or s.st_atime, mtime or s.st_mtime))
            except OSError:
                pass
        if mode is not None:
            try:
                os.chmod(path, stat.S_IMODE(mode))
            except OSError:
                pass
        if (uid, gid) != (None, None):
            try:
                os.lchown(path, uid or s.st_uid, gid or s.st_gid)
            except OSError:
                pass

    def createFile(self, path, srcPath, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a file on the filesystem."""
        dstFile = os.fdopen(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0600), "w")
        try:
            srcFile = open(srcPath, "rb")
            try:
                while 1:
                    data = srcFile.read(65536)
                    if not data:
                        break
                    dstFile.write(data)
            finally:
                srcFile.close()
        finally:
            dstFile.close()
        self.setStat(path, mode, uid, gid, atime, mtime)

    def createDir(self, path, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a directory on the filesystem."""
        os.mkdir(path)
        self.setStat(path, mode, uid, gid, atime, mtime)

    def createSymlink(self, path, target, uid=None, gid=None):
        """Create a symbolic link on the filesystem."""
        os.symlink(target, path)
        self.setStat(path, None, uid, gid, None, None)

    def createCharDevice(self, path, device, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a character device on the filesystem."""
        os.mknod(path, stat.S_IFCHR | 0600, device)
        self.setStat(path, mode, uid, gid, atime, mtime)

    def createBlockDevice(self, path, device, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a block device on the filesystem."""
        os.mknod(path, stat.S_IFBLK | 0600, device)
        self.setStat(path, mode, uid, gid, atime, mtime)

    def createPipe(self, path, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a pipe on the filesystem."""
        os.mkfifo(path)
        self.setStat(path, mode, uid, gid, atime, mtime)

    def createSocket(self, path, mode=None, uid=None, gid=None, atime=None, mtime=None):
        """Create a Unix socket on the filesystem."""
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind(path)
        s.close()
        self.setStat(path, mode, uid, gid, atime, mtime)


# Directory entries
class DirEntInfo(object):
    __slots__ = ("name", "mode", "owner", "group", "mtime")
    
    creator = EntityCreator()
    
    """Directory entry information holder."""
    def __init__(self, name, mode, owner, group, mtime):
        self.name = os.path.normpath(name)
        self.setStat(mode, owner, group, mtime)

    def setStat(self, mode, owner, group, mtime):
        self.mode = stat.S_IMODE(mode)
        self.owner = owner
        self.group = group
        self.mtime = mtime

    def __eq__(self, other):
        return    (self.mode, self.owner, self.group, self.mtime)       \
               == (other.mode, other.owner, other.group, other.mtime)
                   
    def __ne__(self, other):
        return not self.__eq__(other)

    def __str__(self):
        args = [repr(self.name)]
        strArgs = self.getStrArgs()
        args.extend(strArgs[1:])
        return strArgs[0] + "(" + ", ".join([str(x) for x in args]) + ")"

    def absPath(self, base):
        return os.path.abspath(os.path.join(base, self.name))

    def setFsStat(self, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.setStat(dstPath, self.mode, self.owner, self.group, None, self.mtime)


class DirInfo(DirEntInfo):
    """Directory information holder."""
    __slots__ = ()
    
    def getStrArgs(self):
        return ("D", oct(self.mode), self.owner, self.group, self.mtime)
            
    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createDir(dstPath)


def fromHex(s):
    """Convert a hash from hex to binary."""
    return "".join(chr(int(s[each:each + 2], 16)) for each in range(0, len(s), 2))
    
    
def toHex(s):
    """Convert a hash from binary to hex."""
    return "".join(hex(ord(each))[2:].zfill(2) for each in s)
    
    
class FileInfo(DirEntInfo):
    """File information holder."""
    cmpSame = 0
    cmpStatChanged = 1
    cmpChanged = 2

    hashFunction = md5

    __slots__ = ("size", "_hash", "archive")

    def __init__(self, name, mode, owner, group, mtime, size, hash, archive = 0):
        super(FileInfo, self).__init__(name, mode, owner, group, mtime)
        self.size = size
        self.setHash(fromHex(hash))
        self.archive = archive

    def paddedSize(self, bSize):
        return (self.size + (bSize - 1)) & ~(bSize - 1)
            
    def hash(self):
        return self._hash

    def setHash(self, hash):
        if hash and (len(hash) != FileInfo.hashFunction.digest_size):
            raise Error("Hash function mismatch")
        self._hash = hash

    def __eq__(self, other):
        return super(FileInfo, self).__eq__(other) and (self.size == other.size)
            
    def compare(self, other):
        if self.size != other.size:
            return self.cmpChanged
        if self.mtime != other.mtime:
            if self.hash() != other.hash():
                return self.cmpChanged
            return self.cmpStatChanged
        if (self.mode, self.owner, self.group) == (other.mode, other.owner, other.group):
            return self.cmpSame
        return self.cmpStatChanged

    def getStrArgs(self):
        return ("F", oct(self.mode), self.owner, self.group, self.mtime,
            self.size, repr(toHex(self.hash())), self.archive)

    def create(self, srcBase, dstBase):
        srcPath = self.absPath(srcBase)
        dstPath = self.absPath(dstBase)
        self.creator.createFile(dstPath, srcPath, self.mode, self.owner, self.group, None, self.mtime)

                
class LazyFileInfo(FileInfo):
    """File info holder, with lazy MD5 evaluation."""
    __slots__ = ()
    
    def __init__(self, name, mode, owner, group, mtime, size):
        super(LazyFileInfo, self).__init__(name, mode, owner, group, mtime, size, "")

    def hash(self):
        if not self._hash:
            m = FileInfo.hashFunction.new()
            file = _open(self.name, "r")
            try:
                while 1:
                    data = file.read(64 * 1024)
                    if not data:
                        break
                    m.update(data)
            finally:
                file.close()
            self._hash = m.digest()
        return super(LazyFileInfo, self).hash()

                
class SymLinkInfo(DirEntInfo):
    """Symbolic link information holder."""
    __slots__ = ("target", )
    
    def __init__(self, name, mode, owner, group, mtime, target):
        super(SymLinkInfo, self).__init__(name, mode, owner, group, mtime)
        self.target = target

    def __eq__(self, other):
        return super(SymLinkInfo, self).__eq__(other) and (self.target == other.target)

    def getStrArgs(self):
        return ("L", oct(self.mode), self.owner, self.group, self.mtime, repr(self.target))

    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createSymlink(dstPath, self.target, self.owner, self.group)


class PipeInfo(DirEntInfo):
    """Named pipe information holder."""
    __slots__ = ()
    
    def getStrArgs(self):
        return ("P", oct(self.mode), self.owner, self.group, self.mtime)
    
    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createPipe(dstPath, self.mode, self.owner, self.group, None, self.mtime)

        
class SocketInfo(DirEntInfo):
    """Socket information holder."""
    __slots__ = ()
    
    def getStrArgs(self):
        return ("S", oct(self.mode), self.owner, self.group, self.mtime)

    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createSocket(dstPath, self.mode, self.owner, self.group, None, self.mtime)


class DevInfo(DirEntInfo):
    """Device information holder."""
    __slots__ = ("rdev", )
    
    def __init__(self, name, mode, owner, group, mtime, rdev):
        super(DevInfo, self).__init__(name, mode, owner, group, mtime)
        self.rdev = rdev

    def __eq__(self, other):
        return super(DevInfo, self).__eq__(other) and (self.rdev == other.rdev)


class BlockDevInfo(DevInfo):
    """Block device information holder."""
    __slots__ = ()
    
    def getStrArgs(self):
        return ("B", oct(self.mode), self.owner, self.group, self.mtime, self.rdev)

    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createBlockDevice(dstPath, self.rdev, self.mode, self.owner, self.group, 
            None, self.mtime)


class CharDevInfo(DevInfo):
    """Char device information holder."""
    __slots__ = ()
    
    def getStrArgs(self):
        return ("C", oct(self.mode), self.owner, self.group, self.mtime, self.rdev)

    def create(self, srcBase, dstBase):
        dstPath = self.absPath(dstBase)
        self.creator.createCharDevice(dstPath, self.rdev, self.mode, self.owner, self.group, 
            None, self.mtime)


def loadDirEntInfo(name):
    """Create a DirEntInfo child and populate with info loaded from filesystem."""
    name = os.path.normpath(name)
    st = os.lstat(name)
    mode = st.st_mode
    if stat.S_ISDIR(mode):
        return DirInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime)
    elif stat.S_ISREG(mode):
        if not os.access(name, os.R_OK):
            print >> sys.stderr, "Unreadable: " + name
            return None
        return LazyFileInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime, st.st_size)
    elif stat.S_ISLNK(mode):
        return SymLinkInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime, os.readlink(name))
    elif stat.S_ISFIFO(mode):
        return PipeInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime)
    elif stat.S_ISSOCK(mode):
        return SocketInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime)
    elif stat.S_ISBLK(mode):
        return BlockDevInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime, st.st_rdev)
    elif stat.S_ISCHR(mode):
        return CharDevInfo(name, mode, st.st_uid, st.st_gid, st.st_mtime, st.st_rdev)
    print >> sys.stderr, "Omitting " + name
    return None


# Filesystem tree
class FsTree(ScriptParser):
    """Filesystem tree container."""
    def __init__(self, other=None):
        super(FsTree, self).__init__()
        self.addGlobal(Sync2cd = self.sync2cd,
            D = self.dir,
            F = self.file,
            L = self.symLink,
            P = self.pipe,
            S = self.socket,
            B = self.blockDev,
            C = self.charDev)
        
        if other is not None:
            self.archive = other.archive
            self.time = other.time
            self.version = other.version
            self.items = other.items.copy()
        else:
            self.archive = 0
            self.time = 0
            self.version = 0
            self.items = {}

    def setMeta(self, archive, tim=None):
        self.archive = archive
        if tim:
            self.time = int(tim)
        else:
            self.time = int(time.time())

    def timeStr(self):
        return time.strftime("%Y.%m.%d %H:%M:%S UTC", time.gmtime(self.time))
            
    def add(self, entry):
        self[entry.name] = entry

    def __contains__(self, key):
        return key in self.items
        
    def __getitem__(self, key):
        return self.items[key]
        
    def __setitem__(self, key, value):
        self.items[key] = value
        
    def __delitem__(self, key):
        del self.items[key]
        
    def iterUnsorted(self):
        return self.items.itervalues()
        
    def iterSorted(self):
        keys = self.items.keys()
        keys.sort()
        for each in keys:
            yield self.items[each]

    def sync2cd(self, Archive, Time, Version):
        # NOTE: Arguments must stay uppercased!
        self.archive = Archive
        self.time = int(Time)
        self.version = Version
        if Version > descriptorFormatVersion:
            print >> sys.stderr, "Warning: descriptor format version higher than current"

    def dir(self, name, mode, owner, group, mtime):
        mode = stat.S_IMODE(mode) | stat.S_IFDIR
        self[name] = DirInfo(name, mode, owner, group, mtime)

    def file(self, name, mode, owner, group, mtime, size, hash, archive):
        mode = stat.S_IMODE(mode) | stat.S_IFREG
        self[name] = FileInfo(name, mode, owner, group, mtime, size, hash, archive)

    def symLink(self, name, mode, owner, group, mtime, target):
        mode = stat.S_IMODE(mode) | stat.S_IFLNK
        self[name] = SymLinkInfo(name, mode, owner, group, mtime, target)

    def pipe(self, name, mode, owner, group, mtime):
        mode = stat.S_IMODE(mode) | stat.S_IFIFO
        self[name] = PipeInfo(name, mode, owner, group, mtime)

    def socket(self, name, mode, owner, group, mtime):
        mode = stat.S_IMODE(mode) | stat.S_IFSOCK
        self[name] = SocketInfo(name, mode, owner, group, mtime)

    def blockDev(self, name, mode, owner, group, mtime, rdev):
        mode = stat.S_IMODE(mode) | stat.S_IFBLK
        self[name] = BlockDevInfo(name, mode, owner, group, mtime, rdev)

    def charDev(self, name, mode, owner, group, mtime, rdev):
        mode = stat.S_IMODE(mode) | stat.S_IFCHR
        self[name] = CharDevInfo(name, mode, owner, group, mtime, rdev)

    def makeDescriptor(self, out):
        if self.archive != 0:
            out.write('Sync2cd(Archive=' + str(self.archive)
                    + ', Time=' + str(self.time)
                    + ', Version=' + str(descriptorFormatVersion)
                    + ') # ' + self.timeStr() + '\n')
        for each in self.iterSorted():
            out.write(str(each) + "\n")

    def createStatus(self, out, archive, showContent, mediumSize=None):
        totalSize = 0
        paddedSize = 0
        for item in self.iterUnsorted():
            if not isinstance(item, FileInfo):
                continue
            if item.archive != archive:
                continue
            totalSize += item.size
            paddedSize += item.paddedSize(blockSize)

        if self.archive != 0:
            out.write("Archive:   %d\n" % self.archive)
        if self.time:
            out.write("Created:   %s (%d)\n" % (time.strftime("%d.%m.%Y, %H:%M:%S UTC", time.gmtime(self.time)),
                self.time))
        if self.version:
            out.write("Version:   %d\n" % self.version)
        out.write("Size:      %s (%d bytes)\n" % (humanReadable(totalSize), totalSize))
        out.write("Padded:    %s (%d bytes)\n" % (humanReadable(paddedSize), paddedSize))
        if mediumSize:
            archives = (paddedSize + mediumSize - 1) / mediumSize
            lastFree = mediumSize - (paddedSize % mediumSize)
            if archives == 0:
                out.write("Remaining: 0 archive\n")
            else:
                out.write("Remaining: %d archive%s will have %s free\n"
                    % (archives, (archives > 1) and "s, last one" or ",", 
                        humanReadable(lastFree)))
        if showContent:
            out.write("Content:\n")
            for item in self.iterSorted():
                if not isinstance(item, FileInfo):
                    continue
                if item.archive != archive:
                    continue
                out.write(item.name + "\n")
                
    def addParentDirs(self, path, dict):
        dirPath = ""
        for part in path.split(os.sep)[:-1]:
            dirPath = os.path.join(dirPath, part)
            dict[dirPath] = 1
    
    def makeRestoreList(self, filter):
        # TODO: Return lists of items directly, instead of names
        dirFilter = FilterList()
        dirs = {}
        files = {}
        others = {}

        # Must do a first pass with dirs only, as dicts are not sorted
        for item in self.iterUnsorted():
            if not isinstance(item, DirInfo):
                continue
            name = item.name
            if filter.match(name) or dirFilter.match(name):
                dirs[name] = 1
                # TODO: Only if dirFilter doesn't match already
                dirFilter.addGlob(os.path.join(name, "**"))
                self.addParentDirs(name, dirs)
        for item in self.iterUnsorted():
            if isinstance(item, DirInfo):
                continue
            name = item.name
            if filter.match(name) or dirFilter.match(name):
                if isinstance(item, FileInfo):
                    files.setdefault(item.archive, []).append(name)
                else:
                    others[name] = 1
                self.addParentDirs(name, dirs)
                
        dirs = dirs.keys()
        dirs.sort()
        others = others.keys()
        others.sort()
        # Should already be sorted
        for each in files.itervalues():
            each.sort()
        return (dirs, files, others)
        

def treeDiff(fromTree, toTree):
    """Compute the difference between two sorted lists."""
    added = []
    changed = []
    for item in toTree.iterUnsorted():
        name = item.name
        if name not in fromTree:
            added.append(name)
        elif item != fromTree[name]:
            changed.append(name)
    return (added, changed)
        

def backupTreeMerge(oldTree, physTree, newArchiveNum, existingArchives, maxTotalSize=0, sortKey=lambda item: (item.mtime, item.name)):
    """Merge two trees for backup purposes"""
    newTree = FsTree(physTree)
    (added, changed) = treeDiff(oldTree, physTree)

    # Tag added files
    stored = []
    for name in added:
        item = newTree[name]
        if not isinstance(item, FileInfo):
            continue
        stored.append(name)
        item.archive = newArchiveNum
        
    # Tag changed files
    for name in changed:
        newItem = newTree[name]
        if not isinstance(newItem, FileInfo):
            continue
        oldItem = oldTree[name]
        if newItem.compare(oldItem) == FileInfo.cmpChanged:
            stored.append(name)
            newItem.archive = newArchiveNum
            
    # Copy existing info from old tree, provided archive still exists
    existingArchives = set(existingArchives)
    for item in newTree.iterUnsorted():
        if not isinstance(item, FileInfo):
            continue
        if item.archive != 0:
            continue
        k = item.name
        oldItem = oldTree[k]
        if oldItem.archive in existingArchives:
            item.setHash(oldItem.hash())
            item.archive = oldItem.archive
        else:
            stored.append(item.name)
            item.archive = newArchiveNum
            
    # Limit total size to specified value
    if maxTotalSize > 0:
        items = [(sortKey(newTree[k]), newTree[k]) for k in stored if isinstance(newTree[k], FileInfo)]
        items.sort()
        curSize = 0
        for i in range(len(items)):
            item = items[i][1]
            curSize += item.paddedSize(blockSize)
            if curSize > maxTotalSize:
                if i == 0:
                    raise Error("Not enough room on medium for first file '%s', size %d" % (item.name, item.size))
                for (key, item) in items[i:]:
                    if item.name in oldTree:
                        newTree[item.name] = oldTree[item.name]
                    else:
                        del newTree[item.name]
                break
            item.setHash("")
            item.archive = newArchiveNum

    return newTree
        

# Archive descriptor
def listArchives(config):
    """Return the list of available archive descriptors."""
    base = config.descriptor + "." + suffixSize * "[0-9]"
    uFiles = glob.glob(base)
    cFiles = glob.glob(base + compressedExt)
    uArchives = set(int(each[-suffixSize:]) for each in uFiles) - config.Discarded - set([0])
    cArchives = set(int(each[-(suffixSize + len(compressedExt)): -len(compressedExt)]) for each in cFiles) - config.Discarded - set([0])
    if uArchives & cArchives:
        raise Error("Duplicate archive descriptors: " + ", ".join("%0*d" % (suffixSize, each) for each in sorted(uArchives & cArchives)))
    return sorted(uArchives | cArchives)


def archiveDescriptorName(archiveNum, config):
    """Generate the name of an archive descriptor from the base name and the archive number."""
    return config.descriptor + ".%0*d" % (suffixSize, archiveNum)
        
        
def readArchiveDescriptor(archiveNum, config):
    """Read a complete archive descriptor."""
    fileName = archiveDescriptorName(archiveNum, config)
    if os.path.exists(fileName + compressedExt):
        if os.path.exists(fileName):
            raise Error("Duplicate archive descriptor %s" % fileName)
        fileName += compressedExt
        input = _zopen(fileName, "r")
    else:
        input = _open(fileName, "r")
    try:
        tree = FsTree()
        tree.fileName = fileName
        try:
            tree.parse(input, lineByLine=True)
        except ParseError, e:
            raise ParseError(os.path.basename(fileName) + ":" + str(e))
        return tree
    finally:
        input.close()
        

# Filesystem walking
def walkPath(path, tree, filter=None):
    """Walk the filesystem and add entries to an FsTree."""
    def processEntry((tree, filter), dirName, names):
        procNames = []
        for i in range(len(names)):
            entry = names[i]
            entryName = os.path.join(dirName, entry)
            if filter is not None and filter.match(entryName):
                continue
            procNames.append(entry)
            item = loadDirEntInfo(entryName)
            if item is not None:
                tree.add(item)
        names[:] = procNames

    if filter is not None and filter.match(path):
        return
    topEntry = loadDirEntInfo(path)
    if topEntry is None:
        return
    tree.add(topEntry)
    os.path.walk(path, processEntry, (tree, filter))


def walkPaths(paths, filter=None):
    """Construct an FsTree by walking multiple paths of the filesystem."""
    tree = FsTree()
    for path in paths:
        walkPath(path, tree, filter)
    return tree


# Descriptor creation
def createDescriptor(config):
    """Produce a new backup archive descriptor."""
    archives = listArchives(config)
    if not archives:
        archive = 1
        oldTree = FsTree()
    else:
        archive = archives[-1] + 1
        oldTree = readArchiveDescriptor(archive - 1, config)

    physicalTree = walkPaths(config.inputs, config.filter)
    newTree = backupTreeMerge(oldTree, physicalTree, archive, archives, config.mediumSize, config.sortKey)
    newTree.setMeta(archive)
    
    fileName = archiveDescriptorName(archive, config)
    if config.compress:
        fileName += compressedExt
        out = _zopen(fileName, "w")
    else:
        out = _open(fileName, "w")
    try:
        try:
            newTree.makeDescriptor(out)
        finally:
            out.close()
    except:
        try: os.remove(fileName)
        except: pass
        raise
    return archive


# Restore
def restore(config):
    """Restore selected items"""
    archive = config.archive
    showItems = config.verbose > 0
    if not archive:
        archives = listArchives(config)
        if not archives:
            raise Error("No archives available")
        archive = archives[-1]

    tree = readArchiveDescriptor(archive, config)
    (dirs, files, others) = tree.makeRestoreList(config.patterns)
    
    # Restore directories
    for each in dirs:
        if showItems:
            print each
        try:
            DirEntInfo.creator.createDir(os.path.abspath(os.path.join(config.destination, each)))
        except OSError, e:
            if e.errno != errno.EEXIST:
                raise

    # Restore special items
    for each in others:
        if showItems:
            print each
        try:
            tree[each].create("", config.destination)
        except OSError, e:
            print >> sys.stderr, str(e)
    
    # Restore files
    archives = files.keys()
    archives.sort()
    for curArchive in archives:
        srcPath = mountMedium(curArchive, config)
        if srcPath is None:
            continue
        for each in files[curArchive]:
            item = tree[each]
            if showItems:
                print each
            try:
                item.create(srcPath, config.destination)
            except (OSError, IOError), e:
                print >> sys.stderr, str(e)
    
    # Set attributes of directories
    for each in dirs:
        if each not in tree:
            continue
        item = tree[each]
        if isinstance(item, DirInfo):
            item.setFsStat(config.destination)

    # Eject last medium
    if files:
        mountMedium(0, config)
        

def mountMedium(archive, config):
    """Mount a specific backup medium"""
    pipe = os.popen(config.mounter + " " + os.path.basename(archiveDescriptorName(archive, config)), "r")
    path = pipe.read()
    result = pipe.close()
    if not result:
        return path.strip()
    elif os.WIFSIGNALED(result):
        raise Error("Mounter script exited with signal " + str(os.WTERMSIG(result)))
    elif os.WEXITSTATUS(result) == 1:
        return None
    elif os.WEXITSTATUS(result) > 1:
        raise Error("Restore aborted by mounter script")


# Status creation
def createStatus(out, config):
    """Produce a status output for a specific archive."""
    tree = readArchiveDescriptor(config.archive, config)
    return tree.createStatus(out, config.archive, config.verbose > 0)
        

def createSyncStatus(out, config):
    """Produce a synchronization status ouptut of the current state of the filesystem."""
    archives = listArchives(config)
    if not archives:
        oldTree = FsTree()
    else:
        oldTree = readArchiveDescriptor(archives[-1], config)

    physicalTree = walkPaths(config.inputs, config.filter)
    newTree = backupTreeMerge(oldTree, physicalTree, -1, archives, config.sortKey)
    return newTree.createStatus(out, -1, config.verbose > 0, config.mediumSize)
        

# Graft list creation
def graftEscape(s):
    """Escape a file name to be used as a graft point."""
    s = s.replace("\\", "\\\\")
    s = s.replace("=", "\\=")
    return s


def graftEntry(src, dst):
    """Generate a graft list entry."""
    while dst.startswith(os.sep):
        dst = dst[1:]
    return graftEscape(dst) + "=" + graftEscape(src)

                
def createGraftList(out, config):
    """Produce a graft list that can be fed to mkisofs."""
    tree = readArchiveDescriptor(config.archive, config)
    out.write(graftEntry(config.scriptPath, os.path.join(descriptorDir, os.path.basename(config.scriptPath))) + "\n")
    out.write(graftEntry(config.descriptor, os.path.join(descriptorDir, os.path.basename(config.descriptor))) + "\n")
    out.write(graftEntry(tree.fileName, os.path.join(descriptorDir, os.path.basename(tree.fileName))) + "\n")
    for item in tree.iterSorted():
        if not isinstance(item, FileInfo):
            continue
        if item.archive != config.archive:
            continue
        out.write(graftEntry(os.path.abspath(item.name), item.name) + "\n")


# Copying operation
def copy(src, dst, ShowFiles):
    """Copy a file"""
    if ShowFiles:
        print src
    dir = os.path.dirname(dst)
    if not os.path.isdir(dir):
        os.makedirs(dir)
    shutil.copyfile(src, dst)
        

def copyFiles(config):
    """Copy files to destination"""
    showFiles = config.verbose > 0
    tree = readArchiveDescriptor(config.archive, config)
    copy(config.scriptPath, os.path.join(config.destination, descriptorDir, os.path.basename(config.scriptPath)), showFiles)
    copy(config.descriptor, os.path.join(config.destination, descriptorDir, os.path.basename(config.descriptor)), showFiles)
    copy(tree.fileName, os.path.join(config.destination, descriptorDir, os.path.basename(tree.fileName)), showFiles)
    for item in tree.iterSorted():
        if not isinstance(item, FileInfo):
            continue
        if item.archive == config.archive:
            dst = item.name
            while dst.startswith(os.sep):
                dst = dst[1:]
            copy(item.name, os.path.join(config.destination, dst), showFiles)
                    
        
# Shell-style pattern to regexp converter
def globToRegexp(shellPattern):
    """Convert a shell-style pattern to a regexp."""
    result = ""
    i = 0
    n = len(shellPattern)
    while i < n:
        c = shellPattern[i]
        i += 1
        if c == "*":
            if i < n and shellPattern[i] == "*":
                result += ".*"
                i += 1
            else:
                result += "[^" + os.sep + "]*"
        elif c == "?":
            result += "[^" + os.sep + "]"
        elif c == "[":
            j = i
            if shellPattern[j] == "!" or shellPattern[j] == "^":
                j += 1
            if shellPattern[j] == "]":
                j += 1
            while j < n and shellPattern[j] != "]":
                j += 1
            if j >= n:
                result += "\\["
            else:
                chars = shellPattern[i:j].replace("\\", "\\\\")
                i = j + 1
                if chars[0] == "!":
                    chars = "^" + chars[1:]
                result += "[%s]" % chars
        else:
            result += re.escape(c)
    return result + "$"


# Filter list manager
class FilterList(object):
    "Filter list."
    def __init__(self):
        self.patterns = []
            
    def addGlob(self, pattern):
        self.patterns.append(re.compile(globToRegexp(pattern)))

    def addRegexp(self, pattern):
        self.patterns.append(re.compile(pattern))

    def match(self, path):
        for pattern in self.patterns:
            if pattern.match(path):
                return 1
        return 0
    
    def count(self):
        return len(self.patterns)
                        
        
# Configuration parser
class ConfigParser(ScriptParser):
    "Configuration parser."
    archive = 0
    compress = True
    copy = 0
    create = 0
    destination = ""
    graftList = 0
    help = 0
    mediumSize = 0
    mounter = ""
    print_ = 0
    restore = 0
    sort = "time"
    status = 0
    verbose = 0
    descriptor = ""

    baseDir = ""
    scriptPath = ""

    def __init__(self, argv):
        super(ConfigParser, self).__init__()
        self.addGlobal(ArchiveSize = self.setArchiveSize,       # Obsolete
                       BaseDir = self.setBaseDir,
                       Compress = self.setCompress,
                       Discarded = self.addDiscarded,
                       Exclude = self.addExclude,
                       ExcludeGlob = self.addExcludeGlob,       # Obsolete
                       ExcludeRegEx = self.addExcludeRegEx,     # Obsolete
                       ExcludeRegexp = self.addExcludeRegexp,
                       HashFunction = self.setHashFunction,
                       Input = self.addInput,
                       MediumSize = self.setMediumSize,
                       Sort = self.setSort)

        self.Discarded = set()
        self.filter = FilterList()
        self.inputGlobs = []
        self.patterns = FilterList()

        path = os.path.abspath(__file__)
        if (path.endswith(".pyc") or path.endswith(".pyo")) and os.path.isfile(path[:-1]):
            path = path[:-1]
        self.scriptPath = path
        
        (options, arguments) = getopt.getopt(argv[1:],
            "a:b:cd:ghm:n:prsvx:y",
            ["archive=", "copy", "create", "destination=", "glob=", "graft-list", "help", 
             "medium-size=", "mounter=", "print", "regexp=", "restore", "sort=", "status", 
             "verbose"])

        # Parse config file first, so that command line overrides
        if len(arguments) >= 1:
            self.descriptor = os.path.abspath(arguments[0])
            file = _open(self.descriptor, "r")
            try:
                try:
                    self.parse(file)
                except ParseError, e:
                    raise ParseError(os.path.basename(self.descriptor) + ":" + str(e))
            finally:
                file.close()

        for (opt, param) in options:
            if opt in ("-a", "--archive"):
                self.archive = int(param)
            elif opt in ("-b", "--glob"):
                self.patterns.addGlob(param)
            elif opt in ("-d", "--destination"):
                self.destination = param
            elif opt in ("-c", "--create"):
                self.create = 1
            elif opt in ("-g", "--graft-list"):
                self.graftList = 1
            elif opt in ("-h", "--help"):
                self.help = 1
            elif opt in ("-m", "--medium-size"):
                self.setMediumSize(param)
            elif opt in ("-n", "--mounter"):
                self.mounter = param
            elif opt in ("-p", "--print"):
                self.print_ = 1
            elif opt in ("-r", "--restore"):
                self.restore = 1
            elif opt in ("--sort", ):
                self.sort = param
            elif opt in ("-s", "--status"):
                self.status = 1
            elif opt in ("-v", "--verbose"):
                self.verbose += 1
            elif opt in ("-x", "--regexp"):
                self.patterns.addRegexp(param)
            elif opt in ("-y", "--copy"):
                self.copy = 1

        if self.create and self.restore:
            raise Error("--create and --restore are mutually exclusive")
        if self.copy and self.restore:
            raise Error("--copy and --restore are mutually exclusive")
        if (len(arguments) == 0) and not self.help:
            raise Error("Missing configuration file")
        if len(arguments) > 1:
            raise Error("Parameters found after configuration file")

        if self.destination:
            self.destination = os.path.abspath(self.destination)
        if self.mounter:
            self.mounter = os.path.abspath(self.mounter)
        if self.sort == "alpha":
            self.sortKey = lambda item: item.name
        elif self.sort == "time":
            self.sortKey = lambda item: (item.mtime, item.name)
        else:
            raise Error("Invalid sort criterion: %s" % self.sort)
                    
    def getInputs(self):
        inputs = []
        for input in self.inputGlobs:
            entries = glob.glob(input)
            if not entries:
                inputs.append(input)
            else:
                entries.sort()
                inputs.extend(entries)
        return inputs

    inputs = property(getInputs)

    def setArchiveSize(self, *args, **kargs):
        print >> sys.stderr, "Warning: obsolete option 'ArchiveSize' (use 'MediumSize' instead)"
        self.setMediumSize(*args, **kargs)
    
    def setBaseDir(self, value):
        self.baseDir = value

    def setCompress(self, value):
        self.compress = bool(value)
        
    def setHashFunction(self, hashFunctionName):
        FileInfo.hashFunction = hashFunctions[hashFunctionName]
            
    def setMediumSize(self, value):
        self.mediumSize = toBytes(value)

    def setSort(self, value):
        self.sort = value
        
    def addDiscarded(self, *args):
        self.Discarded.update(int(each) for each in args)
        
    def addExclude(self, pattern):
        self.filter.addGlob(pattern)

    def addExcludeGlob(self, pattern):
        print >> sys.stderr, "Warning: obsolete option 'ExcludeGlob' (use 'Exclude' instead)"
        self.filter.addGlob(pattern)

    def addExcludeRegEx(self, pattern):
        print >> sys.stderr, "Warning: obsolete option 'ExcludeRegEx' (use 'ExcludeRegexp' instead)"
        self.filter.addRegexp(pattern)

    def addExcludeRegexp(self, pattern):
        self.filter.addRegexp(pattern)

    def addInput(self, input):
        if os.path.isabs(input):
            raise ParseError("Absolute path: '" + input + "'")
        self.inputGlobs.append(input)

                                
def usage(argv):
    """Print program usage info."""
    #                     0         1         2         3         4         5         6         7
    #                     01234567890123456789012345678901234567890123456789012345678901234567890123456789
    print >> sys.stderr, "Usage: %s [commands] [options] config_file\n" % os.path.basename(argv[0])
    print >> sys.stderr, "Commands: -c, --create               Create a new archive descriptor"
    print >> sys.stderr, "          -g, --graft-list           Output a graft list for an archive"
    print >> sys.stderr, "          -h, --help                 Show this text"
    print >> sys.stderr, "          -p, --print                Print archive information"
    print >> sys.stderr, "          -r, --restore              Restore from archives"
    print >> sys.stderr, "          -s, --status               Print current synchronization status"
    print >> sys.stderr, "          -y, --copy                 Copy files of an archive to destination\n"
    print >> sys.stderr, "Options:  -a N, --archive N          Operate on archive number N"
    print >> sys.stderr, "          -b GLOB, --glob GLOB       Add glob GLOB to pattern list"
    print >> sys.stderr, "          -d DIR, --destination DIR  Copy or restore into directory DIR"
    print >> sys.stderr, "          -m N, --medium-size N      Set archive medium size to N"
    print >> sys.stderr, "          -n CMD, --mounter CMD      Mount media using CMD for restore"
    print >> sys.stderr, "          --sort HOW                 File sorting key (time or alpha)"
    print >> sys.stderr, "          -v, --verbose              Be more verbose"
    print >> sys.stderr, "          -x EXP, --regexp EXP       Add regular expression EXP to pattern list"


# Main program
def main(argv):
    """Main program."""
    try:
        try:
            config = ConfigParser(argv)
        except (getopt.GetoptError, ValueError, Error), e:
            print >> sys.stderr, str(e) + "\n"
            usage(argv)
            return 2

        if config.help:
            print >> sys.stderr, "%s %s   %s" % (metadata.project, metadata.version, 
                metadata.description)
            print >> sys.stderr, metadata.copyright
            usage(argv)
            return 2

        # Initial change of directory
        if config.baseDir:
            os.chdir(config.baseDir)

        # Sync status printing
        if config.status:
            if not config.inputs:
                print >> sys.stderr, "No Input() in configuration file\n"
                usage(argv)
                return 2

            createSyncStatus(sys.stdout, config)

        # Descriptor creation
        if config.create:
            if not config.inputs:
                print >> sys.stderr, "No Input() in configuration file\n"
                usage(argv)
                return 2

            config.archive = createDescriptor(config)

        # Status printing
        if config.print_:
            if config.archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                usage(argv)
                return 2

            createStatus(sys.stdout, config)

        # Graft list output
        if config.graftList:
            if config.archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                usage(argv)
                return 2

            createGraftList(sys.stdout, config)

        # Copy
        if config.copy:
            if config.archive == 0:
                print >> sys.stderr, "No archive number specified\n"
                usage(argv)
                return 2
            if not config.destination:
                print >> sys.stderr, "Missing destination"
                return 2
            if not os.path.isdir(config.destination):
                print >> sys.stderr, "Invalid destination: " + config.destination
                return 2

            copyFiles(config)
            
        # Restore
        if config.restore:
            if not config.mounter:
                print >> sys.stderr, "Missing mount script\n"
                usage(argv)
                return 2
            if not config.destination:
                config.destination = os.path.abspath(os.curdir)
            if not os.path.isdir(config.destination):
                print >> sys.stderr, "Invalid destination: " + config.destination
                return 2
            if config.patterns.count() == 0:
                config.patterns.addGlob("**")
                    
            restore(config)
                
        return 0

    except ParseError, e:
        print >> sys.stderr, "Parse error: " + str(e)
        return 1
    except Error, e:
        print >> sys.stderr, "Error: " + str(e)
        return 1
    except OSError, e:
        print >> sys.stderr, str(e)
        return 1
    except KeyboardInterrupt, e:
        print >> sys.stderr, "Aborted by user"
        return 1

                
# Main entry point
if __name__ == "__main__":
    sys.exit(main(sys.argv))

