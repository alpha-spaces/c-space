"""\
Tests for graft list printing
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

from cStringIO import StringIO

from Vfs import VfsTestCase
import sync2cd


class GraftListTest(VfsTestCase):
    def testGraftPoint(self):
        "Escaping of graft point entries"
        self.assertEqual(sync2cd.graftEscape("home/test/file1.mp3"), "home/test/file1.mp3")
        self.assertEqual(sync2cd.graftEscape("with=equal.mp3"), "with\\=equal.mp3")
        self.assertEqual(sync2cd.graftEscape("with\\backslash.mp3"), "with\\\\backslash.mp3")
            
    def testGraftList(self):
        "Generate a graft list"
        out = StringIO()
        config = sync2cd.ConfigParser(["", "-a", "2", "/test_backup"])
        config.scriptPath = "/usr/local/bin/sync2cd.py"
        sync2cd.createGraftList(out, config)
        
        self.assertEqual(out.getvalue(), '''\
.sync2cd/sync2cd.py=/usr/local/bin/sync2cd.py
.sync2cd/test_backup=/test_backup
.sync2cd/test_backup.0002.gz=/test_backup.0002.gz
home/test/dir2/file7.mp3=/home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3=/home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3=/home/test/dir3/file8.mp3
home/test/file1.mp3=/home/test/file1.mp3
''')

    def testNonRootGraftList(self):
        "Generate a graft list when not in root directory"
        self.cwd = "/prefix"
        out = StringIO()
        config = sync2cd.ConfigParser(["", "-a", "2", "/test_backup"])
        config.scriptPath = "/usr/local/bin/sync2cd.py"
        sync2cd.createGraftList(out, config)
        
        self.assertEqual(out.getvalue(), '''\
.sync2cd/sync2cd.py=/usr/local/bin/sync2cd.py
.sync2cd/test_backup=/test_backup
.sync2cd/test_backup.0002.gz=/test_backup.0002.gz
home/test/dir2/file7.mp3=/prefix/home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3=/prefix/home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3=/prefix/home/test/dir3/file8.mp3
home/test/file1.mp3=/prefix/home/test/file1.mp3
''')
