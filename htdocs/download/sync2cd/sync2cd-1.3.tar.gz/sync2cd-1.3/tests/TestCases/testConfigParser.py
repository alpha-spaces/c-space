"""\
Tests for configuration parsing
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

import os

from Vfs import VfsTestCase
import sync2cd


class ConfigParserTest(VfsTestCase):
    def testCommandLineArgs(self):
        "Command line arguments"
        args = ["sync2cd.py",
                "--archive", "1",
                "--create",
                "--graft-list",
                "--medium-size", "10M",
                "--print",
                "--sort", "alpha",
                "--status",
                "--verbose",
                "-v",
                "/empty_config"]
        config = sync2cd.ConfigParser(args)
        self.assertEqual(config.archive, 1)
        self.assert_(config.create)
        self.assertEqual(config.destination, "")
        self.assert_(config.graftList)
        self.assert_(not config.help)
        self.assertEqual(config.mediumSize, 10 * 1024 ** 2)
        self.assertEqual(config.mounter, "")
        self.assert_(config.print_)
        self.assert_(not config.restore)
        self.assertEqual(config.sort, "alpha")
        self.assert_(config.status)
        self.assertEqual(config.verbose, 2)
        self.assertEqual(os.path.abspath(sync2cd.__file__.strip("co")), config.scriptPath.strip("co"))
            
    def testRestoreCommandLine(self):
        "Command line arguments for restore"
        args = ["sync2cd.py",
                "--archive", "1",
                "--destination", "/restore",
                "--glob", "home/**",
                "--mount", "/bin/my_script",
                "--regexp", "home/.*",
                "--restore",
                "/empty_config"]
        config = sync2cd.ConfigParser(args)
        self.assertEqual(config.archive, 1)
        self.assert_(not config.create)
        self.assertEqual("/restore", config.destination)
        self.assertEqual(config.mounter, "/bin/my_script")
        self.assertEqual(2, config.patterns.count())
        self.assert_(config.restore)

    def testCommandLineHelp(self):
        "Command line arguments with help and no config file"
        args = ["sync2cd.py", "--help"]
        config = sync2cd.ConfigParser(args)
        self.assert_(config.help)

    def testTooManyConfigFiles(self):
        "More than one config file"
        args = ["sync2cd.py", "/empty_config", "/test_descriptor"]
        self.assertRaises(sync2cd.Error, sync2cd.ConfigParser, args)

    def testParsing(self):
        "Parsing of a config file"
        config = sync2cd.ConfigParser(["sync2cd.py", "/test_descriptor"])
        self.assertEqual(config.mediumSize, 650 * 1024 * 1024)
        self.assertEqual(sync2cd.FileInfo.hashFunction, sync2cd.sha)
        self.assertEqual(config.sort, "alpha")
        self.assertEqual(config.baseDir, "/test/dir")
        self.assertEqual(len(config.inputs), 2)
        self.assertEqual(config.inputs[0], "Music")
        self.assertEqual(config.inputs[1], "Pictures")

    def testMediumSizeOverride(self):
        "Overriding of medium size on command line"
        config = sync2cd.ConfigParser(["sync2cd.py", "--medium-size", "700M", "/test_descriptor"])
        self.assertEqual(config.mediumSize, 700 * 1024 ** 2)

    def testAbsoluteInput(self):
        "Config file with absolute input specification"
        try:
            config = sync2cd.ConfigParser(["sync2cd.py", "/absolute_descriptor"])
            self.fail()
        except sync2cd.ParseError, e:
            self.assert_(str(e).startswith("absolute_descriptor:4: ParseError: "))

    def testGlobInput(self):
        "Input specification with wildcards"
        config = sync2cd.ConfigParser(["sync2cd.py", "/lost_backup"])
        self.assertEqual(config.baseDir, "/")
        self.assertEqual(len(config.inputs), 2)
        self.assertEqual(config.inputs[0], "lost/file1.mp3")
        self.assertEqual(config.inputs[1], "lost/file4.mp3")
