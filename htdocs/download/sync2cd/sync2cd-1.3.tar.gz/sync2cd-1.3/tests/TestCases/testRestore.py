"""\
Tests for generating restore information
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

from cStringIO import StringIO
import os.path

import Vfs
import sync2cd


class RestoreInfoTest(Vfs.VfsTestCase):
    def vfsSetUp(self):
        self.mounter = os.path.join(os.path.dirname(__file__), "mounter.sh")
        self.tree = sync2cd.FsTree()
        input = StringIO('''\
Sync2cd(Archive = 3, Time = 12345678, Version = 1)
D('home', 0700, 500, 600, 1067336294)
D('home/test', 0700, 500, 600, 1067336294)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 3)
F('home/test/file2.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 2)
F('home/test/file3.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 1)
F('home/test/file4.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 2)
D('special', 0700, 500, 600, 1067336294)
P('special/gpmdata', 0664, 0, 0, 1007419555)
B('special/hda1', 0660, 0, 6, 1018535114, 769)
S('special/lircd', 0664, 0, 500, 992657524)
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
        self.tree.parse(input)
        
    def testGenerateAll(self):
        """Restore info generation for all files"""
        filter = sync2cd.FilterList()
        filter.addGlob("**")
        (dirs, files, others) = self.tree.makeRestoreList(filter)
        self.assertEqual([
            "home",
            "home/test",
            "special"
        ], dirs)
        self.assertEqual({
            1: ["home/test/file3.mp3"],
            2: ["home/test/file2.mp3", "home/test/file4.mp3"],
            3: ["home/test/file1.mp3"]
        }, files)
        self.assertEqual([
            "home/test/link1.mp3",
            "special/gpmdata",
            "special/hda1",
            "special/lircd",
            "special/random"
        ], others)

    def testGenerateSubset(self):
        """Restore info generation for a subset of files"""
        filter = sync2cd.FilterList()
        filter.addGlob("**/file?.mp3")
        filter.addGlob("special/h*")
        (dirs, files, others) = self.tree.makeRestoreList(filter)
        self.assertEqual([
            "home",
            "home/test",
            "special"
        ], dirs)
        self.assertEqual({
            1: ["home/test/file3.mp3"],
            2: ["home/test/file2.mp3", "home/test/file4.mp3"],
            3: ["home/test/file1.mp3"]
        }, files)
        self.assertEqual([
            "special/hda1"
        ], others)

    def testGenerateDirMatch(self):
        """Restore info generation when matching a directory"""
        filter = sync2cd.FilterList()
        filter.addGlob("**/test")
        (dirs, files, others) = self.tree.makeRestoreList(filter)
        self.assertEqual([
            "home",
            "home/test"
        ], dirs)
        self.assertEqual({
            1: ["home/test/file3.mp3"],
            2: ["home/test/file2.mp3", "home/test/file4.mp3"],
            3: ["home/test/file1.mp3"]
        }, files)
        self.assertEqual([
            "home/test/link1.mp3"
        ], others)
            
    def testRestore(self):
        """Restore operation"""
        config = sync2cd.ConfigParser(["", 
            "--mounter", self.mounter + " /mnt/src", 
            "--glob", "home/test/dir1/d**", 
            "--glob", "**/file8.*",
            "--glob", "home/test/link*",
            "--destination", "/restore",
            "/test_backup"])
        sync2cd.restore(config)
        
        self.assertEqual({
            "/restore/home": ("D", {}),
            "/restore/home/test": ("D", {"mode": 0700, "uid": 500, "gid": 600, 
                "mtime": 1067336294}),
            "/restore/home/test/dir1": ("D", {"mode": 0700, "uid": 500, "gid": 600, 
                "mtime": 1067336294}),
            "/restore/home/test/dir1/dir1.1": ("D", {"mode": 0700, "uid": 500, "gid": 600, 
                "mtime": 1067336294}),
            "/restore/home/test/dir1/dir1.1/file5.mp3": ("F", {"mode": 0644, "uid": 0, "gid": 0, 
                "mtime": 991200000, "srcPath": "/mnt/src/test_backup.0001/home/test/dir1/dir1.1/file5.mp3"}),
            "/restore/home/test/dir3": ("D", {"mode": 0700, "uid": 500, "gid": 600, 
                "mtime": 1067336294}),
            "/restore/home/test/dir3/file8.mp3": ("F", {"mode": 0444, "uid": 1, "gid": 1, 
                "mtime": 1018928511, "srcPath": "/mnt/src/test_backup.0002/home/test/dir3/file8.mp3"}),
            "/restore/home/test/link1.mp3": ("L", {"uid": 0, "gid": 0,
                "target": "home/test/file1.mp3"}),
            }, self.entities)

