"""\
Tests for status printing
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

from cStringIO import StringIO

from Vfs import VfsTestCase
import sync2cd


class StatusTest(VfsTestCase):
    def testHumanReadable(self):
        "Conversion of a size to a human-readable format"
        self.assertEqual(sync2cd.humanReadable(0), "0")
        self.assertEqual(sync2cd.humanReadable(1023), "1023")
        self.assertEqual(sync2cd.humanReadable(1024), "1.0k")
        self.assertEqual(sync2cd.humanReadable(5678), "5.5k")
        self.assertEqual(sync2cd.humanReadable(10230), "9.9k")
        self.assertEqual(sync2cd.humanReadable(10240), "10k")
        self.assertEqual(sync2cd.humanReadable(23456), "22k")
        self.assertEqual(sync2cd.humanReadable(1048575), "1023k")
        self.assertEqual(sync2cd.humanReadable(1024 ** 2), "1.0M")
        self.assertEqual(sync2cd.humanReadable(1024 ** 3), "1.0G")
        self.assertEqual(sync2cd.humanReadable(1024 ** 4), "1.0T")
        self.assertEqual(sync2cd.humanReadable(1024 ** 5), "1.0P")
        self.assertEqual(sync2cd.humanReadable(1024 ** 6), "1.0E")
        self.assertEqual(sync2cd.humanReadable(1024 ** 7), "1024E")

    def testToBytes(self):
        "Conversion from a human-readable format to bytes"
        self.assertEqual(sync2cd.toBytes(0), 0)
        self.assertEqual(sync2cd.toBytes(123), 123)
        self.assertEqual(sync2cd.toBytes(456.789), 456)
        self.assertEqual(sync2cd.toBytes("0"), 0)
        self.assertEqual(sync2cd.toBytes("1023"), 1023)
        self.assertEqual(sync2cd.toBytes("723.6"), 723)
        self.assertEqual(sync2cd.toBytes("5k"), 5 * 1024)
        self.assertEqual(sync2cd.toBytes("3.2k"), int(3.2 * 1024))
        self.assertEqual(sync2cd.toBytes("72M"), 72 * 1024 ** 2)
        self.assertEqual(sync2cd.toBytes("72.56M"), int(72.56 * 1024 ** 2))
        self.assertEqual(sync2cd.toBytes("4G"), 4 * 1024 ** 3)
        self.assertEqual(sync2cd.toBytes("4.3G"), int(4.3 * 1024 ** 3))
        self.assertEqual(sync2cd.toBytes("2T"), 2 * 1024 ** 4)
        self.assertEqual(sync2cd.toBytes("2.5T"), int(2.5 * 1024 ** 4))
        self.assertEqual(sync2cd.toBytes("3P"), 3 * 1024 ** 5)
        self.assertEqual(sync2cd.toBytes("3.8P"), int(3.8 * 1024 ** 5))
        self.assertEqual(sync2cd.toBytes("6E"), 6 * 1024 ** 6)
        self.assertEqual(sync2cd.toBytes("6.7E"), int(6.7 * 1024 ** 6))

    def testArchiveStatus(self):
        "Print status for a specific archive"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        tree = sync2cd.readArchiveDescriptor(2, config)
        out = StringIO()
        tree.createStatus(out, 2, 0)
        self.assertEqual(out.getvalue(), '''\
Archive:   2
Created:   23.05.1970, 21:21:18 UTC (12345678)
Version:   1
Size:      1.9k (2007 bytes)
Padded:    8.0k (8192 bytes)
''')

    def testArchiveStatusContent(self):
        "Print status for a specific archive with archive content"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        tree = sync2cd.readArchiveDescriptor(2, config)
        out = StringIO()
        tree.createStatus(out, 2, 1)
        self.assertEqual(out.getvalue(), '''\
Archive:   2
Created:   23.05.1970, 21:21:18 UTC (12345678)
Version:   1
Size:      1.9k (2007 bytes)
Padded:    8.0k (8192 bytes)
Content:
home/test/dir2/file7.mp3
home/test/dir3/dir3.1/file9.mp3
home/test/dir3/file8.mp3
home/test/file1.mp3
''')

    def testTreeStatus(self):
        "Print status of current tree"
        out = StringIO()
        config = sync2cd.ConfigParser(["", "-v", "/test_backup"])
        config.mediumSize = 4096
        sync2cd.createSyncStatus(out, config)
        self.assertEqual(out.getvalue(), '''\
Size:      3.9k (4023 bytes)
Padded:    6.0k (6144 bytes)
Remaining: 2 archives, last one will have 2.0k free
Content:
home/test/dir1/dir1.1/file5.mp3
home/test/file2.mp3
home/test/file3.mp3
''')

    def testFilteredTreeStatus(self):
        "Print status of current tree with filter"
        config = sync2cd.ConfigParser(["", "-v", "/test_backup"])
        config.filter.addGlob("home/test/dir1/*/*.mp3")
        out = StringIO()
        sync2cd.createSyncStatus(out, config)
        self.assertEqual(out.getvalue(), '''\
Size:      2.5k (2560 bytes)
Padded:    4.0k (4096 bytes)
Content:
home/test/file2.mp3
home/test/file3.mp3
''')
