"""\
Tests for filter list
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

import unittest

import sync2cd


class FilterListTest(unittest.TestCase):
    def testNoPattern(self):
        "Filter list with no pattern"
        filter = sync2cd.FilterList()
        self.assert_(not filter.match("Test pattern"))

    def testOnePattern(self):
        "Filter list with one pattern"
        filter = sync2cd.FilterList()
        filter.addGlob("Test *")
        self.assert_(filter.match("Test pattern"))
        self.assert_(not filter.match("Other test pattern"))
    
    def testTwoPatterns(self):
        "Filter list with two patterns"
        filter = sync2cd.FilterList()
        filter.addGlob("Test *")
        filter.addRegexp(".* test .*")
        self.assert_(filter.match("Test pattern"))
        self.assert_(filter.match("Other test pattern"))
        self.assert_(not filter.match("Not matched"))
