# -*- coding: iso-8859-1 -*-
"""\
Tests for DirEntInfo children
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

import os

from Vfs import testFiles, VfsTestCase
import sync2cd


class DirEntInfoTest(VfsTestCase):
    """DirEntInfo child tests."""
    def testDirInfoAttributes(self):
        "Info loading for a directory"
        fileName = "home/test"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.DirInfo))

    def testFileInfoAttributes(self):
        "Creation and attributes of FileInfo"
        fileName = "home/test/file1.mp3"
        info = sync2cd.loadDirEntInfo(fileName)

        self.assertEqual(info.name, fileName)
        self.assertEqual(info.mode, 0770)
        self.assert_(isinstance(info, sync2cd.FileInfo))
        self.assertEqual(info.owner, 500)
        self.assertEqual(info.group, 600)
        self.assertEqual(info.mtime, 1063048395)
        self.assertEqual(info.size,  1280)
        m = sync2cd.FileInfo.hashFunction.new(testFiles[os.path.abspath(fileName)][1])
        self.assertEqual(info.hash(), m.digest())

    def testSymLinkInfoAttributes(self):
        "Info loading for a link"
        fileName = "home/test/link1.mp3"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.SymLinkInfo))
        self.assertEqual(info.target, "home/test/file1.mp3")

    def testPipeInfoAttributes(self):
        "Info loading for a pipe"
        fileName = "special/gpmdata"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.PipeInfo))

    def testSocketInfoAttributes(self):
        "Info loading for a socket"
        fileName = "special/lircd"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.SocketInfo))

    def testBlockDevInfoAttributes(self):
        "Info loading for a block device"
        fileName = "special/hda1"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.BlockDevInfo))

    def testCharDevInfoAttributes(self):
        "Info loading for a char device"
        fileName = "special/random"
        info = sync2cd.loadDirEntInfo(fileName)
        self.assert_(isinstance(info, sync2cd.CharDevInfo))

    def testDirComparison(self):
        "Comparison between directories"
        info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048395)
        self.assertEqual(info1, info2)

        info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        info2 = sync2cd.DirInfo("Dir2", 0771, 500, 600, 1063048395)
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        info2 = sync2cd.DirInfo("Dir2", 0770, 501, 600, 1063048395)
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        info2 = sync2cd.DirInfo("Dir2", 0770, 500, 601, 1063048395)
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.DirInfo("Dir1", 0770, 500, 600, 1063048395)
        info2 = sync2cd.DirInfo("Dir2", 0770, 500, 600, 1063048396)
        self.assertNotEqual(info1, info2)

    def testFileComparison(self):
        "Comparison between files"
        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
        self.assertEqual(info1, info2)
        
        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0771, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertNotEqual(info1, info2)

    def testFileInfoComparison(self):
        "Comparison between FileInfo instances"
        info1_1 = sync2cd.loadDirEntInfo("home/test/file1.mp3")
        info1_2 = sync2cd.loadDirEntInfo("home/test/file1.mp3")
        self.assertEqual(info1_1.compare(info1_2), sync2cd.FileInfo.cmpSame)

        info2 = sync2cd.loadDirEntInfo("home/test/file2.mp3")
        self.assertEqual(info1_1.compare(info2), sync2cd.FileInfo.cmpStatChanged)
        
        info3 = sync2cd.loadDirEntInfo("home/test/file3.mp3")
        self.assertEqual(info1_1.compare(info3), sync2cd.FileInfo.cmpChanged)

    def testFileCompare(self):
        "Comparison between files with Compare()"
        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpSame)
        
        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 33273, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpStatChanged)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 501, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpStatChanged)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 601, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpStatChanged)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpStatChanged)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1281, "81d6a1501eaff685ab50c7ff7d29d396")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpChanged)

        # Don't evaluate MD5 if size and mtime haven't changed
        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048395, 1280, "00000000000000000000000000000000")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpSame)

        info1 = sync2cd.FileInfo("File1", 0770, 500, 600, 1063048395, 1280, "81d6a1501eaff685ab50c7ff7d29d396")
        info2 = sync2cd.FileInfo("File2", 0770, 500, 600, 1063048396, 1280, "00000000000000000000000000000000")
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpChanged)

    def testLinkComparison(self):
        "Comparison between Links"
        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target")
        self.assertEqual(info1, info2)

        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        info2 = sync2cd.SymLinkInfo("Link2", 0771, 500, 600, 1063048395, "Target")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        info2 = sync2cd.SymLinkInfo("Link2", 0770, 501, 600, 1063048395, "Target")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 601, 1063048395, "Target")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target")
        info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048396, "Target")
        self.assertNotEqual(info1, info2)

        info1 = sync2cd.SymLinkInfo("Link1", 0770, 500, 600, 1063048395, "Target1")
        info2 = sync2cd.SymLinkInfo("Link2", 0770, 500, 600, 1063048395, "Target2")
        self.assertNotEqual(info1, info2)

    def testDirectFileInfo(self):
        "Direct FileInfo structure"
        fileName = "home/test/file1.mp3"
        info1 = sync2cd.FileInfo(fileName, 0770, 500, 600, 1063048395, 1280,
             sync2cd.FileInfo.hashFunction.new(testFiles[os.path.abspath(fileName)][1]).hexdigest())
        info2 = sync2cd.loadDirEntInfo(fileName)
        self.assertEqual(info1.compare(info2), sync2cd.FileInfo.cmpSame)

    def testToStr(self):
        "Conversion of DirEntInfo to string"
        info = sync2cd.loadDirEntInfo("home/test/dir1")
        output = str(info)
        self.assertEqual(output, "D('home/test/dir1', 0700, 500, 600, 1067336294)")

        info = sync2cd.loadDirEntInfo("home/test/link1.mp3")
        output = str(info)
        self.assertEqual(output, "L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')")

        info = sync2cd.loadDirEntInfo("home/test/file1.mp3")
        output = str(info)
        self.assertEqual(output, "F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 0)")

        info = sync2cd.loadDirEntInfo("special/gpmdata")
        output = str(info)
        self.assertEqual(output, "P('special/gpmdata', 0664, 0, 0, 1007419555)")

        info = sync2cd.loadDirEntInfo("special/hda1")
        output = str(info)
        self.assertEqual(output, "B('special/hda1', 0660, 0, 6, 1018535114, 769)")

        info = sync2cd.loadDirEntInfo("special/random")
        output = str(info)
        self.assertEqual(output, "C('special/random', 0644, 0, 0, 1018535114, 264)")

    def testToStrWithQuotes(self):
        "Conversion to string with quotes in filenames"
        info = sync2cd.SymLinkInfo('home/test/link"with"quotes', 0777, 0, 0, 1034546253, 'home/target"with"quotes')
        output = str(info)
        self.assertEqual(output, "L('home/test/link\"with\"quotes', 0777, 0, 0, 1034546253, 'home/target\"with\"quotes')")

        info = sync2cd.SymLinkInfo('home/test/link\'with\'quotes', 0777, 0, 0, 1034546253, 'home/target\'with\'quotes')
        output = str(info)
        self.assertEqual(output, 'L("home/test/link\'with\'quotes", 0777, 0, 0, 1034546253, "home/target\'with\'quotes")')

        info = sync2cd.SymLinkInfo('home/test/link"with\'quotes', 0777, 0, 0, 1034546253, 'home/target"with\'quotes')
        output = str(info)
        self.assertEqual(output, "L('home/test/link\"with\\\'quotes', 0777, 0, 0, 1034546253, 'home/target\"with\\\'quotes')")

    def testToStrSpecialChars(self):
        "Conversion of DirEntInfo to string with special chars"
        info = sync2cd.SymLinkInfo('home/test/���\\���', 0777, 0, 0, 1034546253, 'home/target/���\\���')
        output = str(info)
        self.assertEqual(output, "L('home/test/\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4', 0777, 0, 0, 1034546253, 'home/target/\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4')")
            
    def testNonNormalPath(self):
        "Normalization of non-normal path"
        info = sync2cd.loadDirEntInfo("home//./test/dir1/../file1.mp3")
        self.assertEqual(info.name, "home/test/file1.mp3")


class DirEntCreationTest(VfsTestCase):
    """DirEnt entity creation tests."""
    def testDirCreation(self):
        "Creating a directory entity"
        info = sync2cd.DirInfo("Dir", 0770, 500, 600, 1063048395)
        info.create("", "/dest")
        info.setFsStat("/dest")
        self.assertEqual({
            "/dest/Dir": ("D", {"mode": 0770, "uid": 500, "gid": 600, "mtime": 1063048395})
        }, self.entities)
                    
    def testFileCreation(self):
        "Creating a file entity"
        info = sync2cd.FileInfo("dir/File", 0770, 500, 600, 1063048395, 1234, "00000000000000000000000000000000")
        info.create("/home/src", "/dest")
        self.assertEqual({
            "/dest/dir/File": ("F", {"mode": 0770, "uid": 500, "gid": 600, 
                "mtime": 1063048395, "srcPath": "/home/src/dir/File"})
        }, self.entities)
                
    def testSymLinkCreation(self):
        "Creating a symlink entity"
        info = sync2cd.SymLinkInfo("Link", 0770, 500, 600, 1063048395, "LinkTarget")
        info.create("", "/dest")
        self.assertEqual({
            "/dest/Link": ("L", {"uid": 500, "gid": 600, "target": "LinkTarget"})
        }, self.entities)

    def testPipeCreation(self):
        "Creating a named pipe entity"
        info = sync2cd.PipeInfo("Pipe", 0770, 500, 600, 1063048395)
        info.create("", "/dest")
        self.assertEqual({
            "/dest/Pipe": ("P", {"mode": 0770, "uid": 500, "gid": 600, "mtime": 1063048395})
        }, self.entities)
                    
    def testSocketCreation(self):
        "Creating a socket entity"
        info = sync2cd.SocketInfo("Socket", 0770, 500, 600, 1063048395)
        info.create("", "/dest")
        self.assertEqual({
            "/dest/Socket": ("S", {"mode": 0770, "uid": 500, "gid": 600, "mtime": 1063048395})
        }, self.entities)
                    
    def testBlockDevCreation(self):
        "Creating a block device entity"
        info = sync2cd.BlockDevInfo("BlkDev", 0770, 500, 600, 1063048395, 1)
        info.create("", "/dest")
        self.assertEqual({
            "/dest/BlkDev": ("B", {"device": 1, "mode": 0770, "uid": 500, "gid": 600, 
                "mtime": 1063048395})
        }, self.entities)
                    
    def testCharDevCreation(self):
        "Creating a character device entity"
        info = sync2cd.CharDevInfo("ChrDev", 0770, 500, 600, 1063048395, 2)
        info.create("", "/dest")
        self.assertEqual({
            "/dest/ChrDev": ("C", {"device": 2, "mode": 0770, "uid": 500, "gid": 600, 
                "mtime": 1063048395})
        }, self.entities)
                    
