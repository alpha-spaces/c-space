"""\
Tests for shell-style pattern to regexp converter
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

import unittest
import re

import sync2cd


class GlobToRegexpTest(unittest.TestCase):
    def testNoPattern(self):
        "Path containing no pattern"
        input = "/home/test/a file.mp3"
        output = sync2cd.globToRegexp(input)
        self.assertEqual(output, re.escape(input) + "$")

    def testStarPattern(self):
        "Path containing a star pattern"
        input = "/home/te*t/my * file.mp*"
        output = sync2cd.globToRegexp(input)
        self.assertEqual(output,
            re.escape("/home/te") + "[^/]*" + re.escape("t/my ")
            + "[^/]*" + re.escape(" file.mp") + "[^/]*" + "$")

    def testDoubleStarPattern(self):
        "Path containing a double-star pattern"
        input = "/home/te**t/my ** file.mp**"
        output = sync2cd.globToRegexp(input)
        self.assertEqual(output,
            re.escape("/home/te") + ".*" + re.escape("t/my ")
            + ".*" + re.escape(" file.mp") + ".*" + "$")

        self.assertEqual(sync2cd.globToRegexp("test*"),
            "test[^/]*$")

    def testQuestionPattern(self):
        "Path containing a question-mark pattern"
        input = "/home/te?t/my ? file.mp?"
        output = sync2cd.globToRegexp(input)
        self.assertEqual(output,
            re.escape("/home/te") + "[^/]" + re.escape("t/my ")
            + "[^/]" + re.escape(" file.mp") + "[^/]" + "$")

    def testRangePatterns(self):
        "Path containing a character range pattern"
        input = "/home/te[a-c]t/my [b-d0-9] file.mp[23]"
        output = sync2cd.globToRegexp(input)
        self.assertEqual(output,
            re.escape("/home/te") + "[a-c]" + re.escape("t/my ")
            + "[b-d0-9]" + re.escape(" file.mp") + "[23]" + "$")

        self.assertEqual(sync2cd.globToRegexp("[!abc]"),
            "[^abc]$")
        self.assertEqual(sync2cd.globToRegexp("[a!bc]"),
            "[a!bc]$")
        self.assertEqual(sync2cd.globToRegexp("[^abc]"),
            "[^abc]$")
        self.assertEqual(sync2cd.globToRegexp("[]abc]"),
            "[]abc]$")
        self.assertEqual(sync2cd.globToRegexp("[!]abc]"),
            "[^]abc]$")
        self.assertEqual(sync2cd.globToRegexp("[^]abc]"),
            "[^]abc]$")
        self.assertEqual(sync2cd.globToRegexp("[abc"),
            "\\[abc$")
        self.assertEqual(sync2cd.globToRegexp("[ab\\s]"),
            "[ab\\\\s]$")
