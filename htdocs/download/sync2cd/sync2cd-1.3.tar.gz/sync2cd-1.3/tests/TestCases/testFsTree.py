# -*- coding: iso-8859-1 -*-
"""\
Tests for filesystem tree
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

import StringIO

from Vfs import VfsTestCase
import sync2cd


class FsTreeTest(VfsTestCase):
    def testEmptyList(self):
        "Loading an empty list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO("")
        tree.parse(input)
        self.assertEqual({}, tree.items)

    def testSingleDir(self):
        "Loading a single-dir list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
D('home/test', 0700, 500, 600, 1067336294)
''')
        tree.parse(input)
        ent = tree.items["home/test"]
        self.assertEqual(ent.mode, 0700)
        self.assertEqual(ent.owner, 500)
        self.assertEqual(ent.group, 600)
        self.assertEqual(ent.mtime, 1067336294)

    def testSingleFile(self):
        "Loading a single-file list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 42)
''')
        tree.parse(input)
        ent = tree.items["home/test/file1.mp3"]
        self.assertEqual(ent.mode, 0770)
        self.assertEqual(ent.owner, 500)
        self.assertEqual(ent.group, 600)
        self.assertEqual(ent.mtime, 1063048395)
        self.assertEqual(ent.size, 1280)
        self.assertEqual(ent.hash(), sync2cd.fromHex("01234567890123456789012345678901"))
        self.assertEqual(ent.archive, 42)

    def testSingleLink(self):
        "Loading a single-link list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
''')
        tree.parse(input)
        ent = tree.items["home/test/link1.mp3"]
        self.assertEqual(ent.mode, 0777)
        self.assertEqual(ent.owner, 0)
        self.assertEqual(ent.group, 0)
        self.assertEqual(ent.mtime, 1034546253)
        self.assertEqual(ent.target, "home/test/file1.mp3")

    def testSinglePipe(self):
        "Loading a single-pipe list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
P('special/gpmdata', 0664, 0, 0, 1007419555)
''')
        tree.parse(input)
        ent = tree.items["special/gpmdata"]
        self.assertEqual(ent.mode, 0664)
        self.assertEqual(ent.owner, 0)
        self.assertEqual(ent.group, 0)
        self.assertEqual(ent.mtime, 1007419555)

    def testSingleSocket(self):
        "Loading a single-socket list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
S('special/lircd', 0664, 0, 500, 992657524)
''')
        tree.parse(input)
        ent = tree.items["special/lircd"]
        self.assertEqual(ent.mode, 0664)
        self.assertEqual(ent.owner, 0)
        self.assertEqual(ent.group, 500)
        self.assertEqual(ent.mtime, 992657524)

    def testSingleBlockDev(self):
        "Loading a single-block-device list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
B('special/hda1', 0660, 0, 6, 1018535114, 769)
''')
        tree.parse(input)
        ent = tree.items["special/hda1"]
        self.assertEqual(ent.mode, 0660)
        self.assertEqual(ent.owner, 0)
        self.assertEqual(ent.group, 6)
        self.assertEqual(ent.mtime, 1018535114)
        self.assertEqual(ent.rdev, 769)

    def testSingleCharDev(self):
        "Loading a single-char-device list"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
        tree.parse(input)
        ent = tree.items["special/random"]
        self.assertEqual(ent.mode, 0644)
        self.assertEqual(ent.owner, 0)
        self.assertEqual(ent.group, 0)
        self.assertEqual(ent.mtime, 1018535114)
        self.assertEqual(ent.rdev, 264)

    def testOneOfEach(self):
        "Loading one item of each type"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
Sync2cd(Archive = 3, Time = 12345678, Version = 1)
D('home/test', 0700, 500, 600, 1067336294)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280L, '01234567890123456789012345678901', 42)
P('special/gpmdata', 0664, 0, 0, 1007419555)
B('special/hda1', 0660, 0, 6, 1018535114, 769)
S('special/lircd', 0664, 0, 500, 992657524)
C('special/random', 0644, 0, 0, 1018535114, 264)
''')
        tree.parse(input)
        self.assertEqual(tree.archive, 3)
        self.assertEqual(tree.time, 12345678)
        self.assert_("home/test" in tree.items)
        self.assert_("home/test/file1.mp3" in tree.items)
        self.assert_("home/test/link1.mp3" in tree.items)
        self.assert_("special/gpmdata" in tree.items)
        self.assert_("special/lircd" in tree.items)
        self.assert_("special/hda1" in tree.items)
        self.assert_("special/random" in tree.items)

    def testLinkWithSpecialChars(self):
        "Loading a link with special chars in the filenames"
        tree = sync2cd.FsTree()
        input = StringIO.StringIO('''\
L('home/link"with"quotes', 0777, 0, 0, 1034546253, 'home/target"with"quotes')
L("home/link'with'quotes", 0777, 0, 0, 1034546253, "home/target'with'quotes")
L('home/link"with\\'quotes', 0777, 0, 0, 1034546253, 'home/target"with\\'quotes')
L('home/link_\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4', 0777, 0, 0, 1034546253, 'home/target_\\xe8\\xe9\\xe0\\\\\\xfc\\xf6\\xe4')
''')
        tree.parse(input)
        self.assertEqual(tree.items['home/link"with"quotes'].target, 'home/target"with"quotes')
        self.assertEqual(tree.items["home/link'with'quotes"].target, "home/target'with'quotes")
        self.assertEqual(tree.items['home/link"with\'quotes'].target, 'home/target"with\'quotes')
        self.assertEqual(tree.items['home/link_���\\���'].target, 'home/target_���\\���')

    def testBadDescriptor(self):
        "Error in descriptor"
        config = sync2cd.ConfigParser(["", "/bad_descriptor"])
        try:
            tree = sync2cd.readArchiveDescriptor(1, config)
            self.fail()
        except sync2cd.ParseError, e:
            self.assert_(str(e).startswith("bad_descriptor.0001:5: NameError: "))

    def testBackupMerge(self):
        "Merge two trees for backup purposes"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        oldTree = sync2cd.readArchiveDescriptor(2, config)
        physicalTree = sync2cd.walkPaths(["home/test"])
        newTree = sync2cd.backupTreeMerge(oldTree, physicalTree, 3, [1, 2])

        out = StringIO.StringIO()
        newTree.makeDescriptor(out)
        self.assertEqual(out.getvalue(), """\
D('home/test', 0700, 500, 600, 1067336294)
D('home/test/dir1', 0700, 500, 600, 1067336294)
D('home/test/dir1/dir1.1', 0700, 500, 600, 1067336294)
F('home/test/dir1/dir1.1/file5.mp3', 0644, 0, 0, 991209287, 1463, 'f6ced8d61e9545503165d9233eb68db3', 3)
F('home/test/dir1/file4.mp3', 0664, 500, 505, 1056059953, 542594, '22216af3e014b443aab3c68fde453d68', 1)
D('home/test/dir2', 0700, 500, 600, 1067336294)
F('home/test/dir2/file6.mp3', 0600, 500, 12, 1021222945, 0, 'c69f52e90182b1188582799b9ab95195', 1)
F('home/test/dir2/file7.mp3', 0444, 1, 1, 1018928518, 124, '433b7d897d3113a4f05f3ce50ad40faa', 2)
D('home/test/dir3', 0700, 500, 600, 1067336294)
D('home/test/dir3/dir3.1', 0700, 500, 600, 1067336294)
F('home/test/dir3/dir3.1/file9.mp3', 0644, 0, 0, 1018927583, 492, 'b514a213066bbd126c9c6f51fc2f852f', 2)
F('home/test/dir3/file8.mp3', 0444, 1, 1, 1018928511, 111, 'af4b9fc3b9cb11019293c3a697368e5d', 2)
F('home/test/file1.mp3', 0770, 500, 600, 1063048395, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 2)
F('home/test/file2.mp3', 0766, 500, 600, 1063048300, 1280, '81d6a1501eaff685ab50c7ff7d29d396', 3)
F('home/test/file3.mp3', 0770, 500, 600, 990000000, 1280, 'e514979236a3b13cd9a4e81c43595f04', 3)
L('home/test/link1.mp3', 0777, 0, 0, 1034546253, 'home/test/file1.mp3')
""")

    def testSizedBackupMerge(self):
        "Merge two trees for backup purposes, with limited medium size"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        oldTree = sync2cd.readArchiveDescriptor(2, config)
        physicalTree = sync2cd.walkPaths(["home/test"])
        newTree = sync2cd.backupTreeMerge(oldTree, physicalTree, 3, [1, 2], 4096)
        totalSize = 0
        for item in newTree.items.itervalues():
            if not isinstance(item, sync2cd.FileInfo):
                continue
            if item.archive == 3:
                totalSize += item.paddedSize(sync2cd.blockSize)

        # Only file5.mp3 and file3.mp3 should be in archive 3
        self.assert_(totalSize <= 4096)
        self.assert_("home/test/dir1/dir1.1/file5.mp3" in newTree.items)
        self.assert_("home/test/file2.mp3" not in newTree.items)
        self.assert_("home/test/file3.mp3" in newTree.items)
        self.assertEqual(3, newTree.items["home/test/dir1/dir1.1/file5.mp3"].archive)
        self.assertEqual(3, newTree.items["home/test/file3.mp3"].archive)
            
    def testSizedBackupMerge2(self):
        "Merge two trees for backup purposes, with small medium size"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        oldTree = sync2cd.readArchiveDescriptor(2, config)
        physicalTree = sync2cd.walkPaths(["home/test"])
        newTree = sync2cd.backupTreeMerge(oldTree, physicalTree, 3, [1, 2], 2048)
        totalSize = 0
        for item in newTree.items.itervalues():
            if not isinstance(item, sync2cd.FileInfo):
                continue
            if item.archive == 3:
                totalSize += item.paddedSize(sync2cd.blockSize)

        # Only file3.mp3 should be in archive 3, and file5.mp3 should be present with old data
        self.assert_(totalSize <= 2048)
        self.assert_("home/test/dir1/dir1.1/file5.mp3" in newTree.items)
        self.assert_("home/test/file2.mp3" not in newTree.items)
        self.assert_("home/test/file3.mp3" in newTree.items)
        self.assertNotEqual(3, newTree.items["home/test/dir1/dir1.1/file5.mp3"].archive)
        self.assertEqual(991200000, newTree.items["home/test/dir1/dir1.1/file5.mp3"].mtime)
        self.assertEqual(3, newTree.items["home/test/file3.mp3"].archive)
