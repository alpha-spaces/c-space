"""\
Tests for archive descriptors
Copyright (C) 2007 Remy Blank
"""
# This file is part of sync2cd.
# 
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the 
# Free Software Foundation, version 2. A copy of the license is provided 
# in the file COPYING.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General 
# Public License for more details.

from Vfs import VfsTestCase
import sync2cd


class ArchiveDescriptorTest(VfsTestCase):
    def testListArchives(self):
        "Find archive description files"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        archives = sync2cd.listArchives(config)
        self.assertEqual(archives, [1, 2])

    def testArchiveName(self):
        "Make an archive descriptor file name"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        config.Compressed = False
        name = sync2cd.archiveDescriptorName(123, config)
        self.assertEqual(name, "/test_backup.0123")
            
    def testReadArchive(self):
        "Read an archive descriptor"
        config = sync2cd.ConfigParser(["", "/test_backup"])
        tree = sync2cd.readArchiveDescriptor(1, config)
        self.assertEqual(8, len(tree.items))

        tree = sync2cd.readArchiveDescriptor(2, config)
        self.assertEqual(15, len(tree.items))
