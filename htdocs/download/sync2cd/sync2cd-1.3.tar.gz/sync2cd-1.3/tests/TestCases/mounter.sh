#!/bin/bash

echo "$1/$2"
exit 0
